@echo off
echo Starting RestoMaster POS System...
cd /d "%~dp0"
npm start
