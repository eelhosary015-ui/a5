@echo off
echo ===================================================
echo Stopping RestoMaster Pro Server...
echo ===================================================
echo.
taskkill /F /IM node.exe
echo.
echo Server stopped successfully!
pause
