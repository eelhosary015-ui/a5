import { api } from "./api";

export const PRODUCTION_DB_KEYS = [
  "restomaster_production_products",
  "restomaster_production_boms",
  "restomaster_production_orders",
  "restomaster_production_workcenters",
  "restomaster_production_shopfloor",
  "restomaster_production_mrp",
  "restomaster_production_maintenance",
  "restomaster_quality_control_points",
  "restomaster_quality_checks",
  "restomaster_quality_alerts",
  "restomaster_quality_teams",
  "restomaster_quality_final_certs",
  "restomaster_inventory_capitalized_posts"
];

const productionKeySet = new Set(PRODUCTION_DB_KEYS);

async function loadDbValue(key: string) {
  const res = await api.get(`/api/system/settings/${key}`);
  if (!res.ok) return null;
  return await res.json();
}

async function saveDbValue(key: string, value: string | null) {
  if (value === null) return;
  let parsed: any = value;
  try {
    parsed = JSON.parse(value);
  } catch {
    parsed = value;
  }
  await api.post("/api/system/settings", { key, value: parsed });
}

/**
 * Hydrates production/MRP/quality data from PostgreSQL-backed system_settings
 * into localStorage so legacy production screens continue to work while data
 * is shared between devices and users.
 */
export async function syncProductionStorageFromDatabase() {
  if (!localStorage.getItem('token')) return;
  const originalSetItem = (window as any).__restomasterOriginalSetItem || localStorage.setItem.bind(localStorage);
  await Promise.all(PRODUCTION_DB_KEYS.map(async (key) => {
    try {
      if (!localStorage.getItem('token')) return;
      const dbValue = await loadDbValue(key);
      if (dbValue !== null && dbValue !== undefined) {
        originalSetItem(key, JSON.stringify(dbValue));
      }
    } catch (_error) {
      // Ignore background sync errors when unauthorized
    }
  }));
}

/**
 * Automatically mirrors legacy localStorage writes into PostgreSQL for all
 * production-related keys.
 */
export function installProductionStorageSync() {
  if (typeof window === "undefined") return;
  if ((window as any).__restomasterProductionStorageSyncInstalled) return;

  const originalSetItem = localStorage.setItem.bind(localStorage);
  const originalRemoveItem = localStorage.removeItem.bind(localStorage);
  (window as any).__restomasterOriginalSetItem = originalSetItem;

  localStorage.setItem = (key: string, value: string) => {
    originalSetItem(key, value);
    if (productionKeySet.has(key)) {
      saveDbValue(key, value).catch((error) => {
        console.warn(`Failed to mirror production storage key ${key} to database`, error);
      });
    }
  };

  localStorage.removeItem = (key: string) => {
    originalRemoveItem(key);
    if (productionKeySet.has(key)) {
      api.post("/api/system/settings", { key, value: [] }).catch((error) => {
        console.warn(`Failed to clear production storage key ${key} in database`, error);
      });
    }
  };

  (window as any).__restomasterProductionStorageSyncInstalled = true;
}
