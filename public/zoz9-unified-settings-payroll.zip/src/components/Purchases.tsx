import React, { useState, useEffect } from "react";
import {
  ShoppingCart,
  Plus,
  XCircle,
  FileText,
  Search,
  Printer,
  DollarSign,
  Settings,
  Trash2,
  Sparkles,
  Check,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Filter,
  Download,
  Calendar,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";
import { api } from "../utils/api";
import { SearchableSelect } from "./SearchableSelect";
import { ReturnModal } from "./ReturnModal";
import { downloadDataAsWord } from "../utils/wordExport";
import { InvoiceOCRModal } from "./InvoiceOCRModal";

interface Purchase {
  id: number;
  supplier_id: number;
  warehouse_id: number;
  supplier_name: string;
  warehouse_name: string;
  invoice_number: string;
  total_amount: number;
  paid_amount: number;
  status: string;
  notes: string;
  date: string;
  item_names?: string;
  items?: PurchaseItem[];
}

interface PurchaseItem {
  id: number;
  ingredient_id: number;
  ingredient_name: string;
  unit: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

type PurchaseTab =
  | "receipts"
  | "orders"
  | "requests"
  | "invoices"
  | "returns"
  | "expenses"
  | "quotations"
  | "reports";

interface PurchasesProps {
  onBack: () => void;
  initialTab?: PurchaseTab;
}

export function Purchases({ onBack, initialTab }: PurchasesProps) {
  const [activeTab, setActiveTab] = useState<PurchaseTab>(
    initialTab || "receipts",
  );

  const tabNames: Record<string, string> = {
    orders: "أوامر الشراء (Purchase Orders)",
    receipts: "استلام المشتريات (Purchase Receipts)",
    requests: "طلبات الشراء",
    invoices: "فواتير المشتريات",
    returns: "مرتجعات المشتريات",
    expenses: "مصاريف إضافية",
    quotations: "عروض أسعار",
    reports: "التحليلات والتقارير 📊",
  };

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  // Receipts State
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showQuotationModal, setShowQuotationModal] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [linkedRequestId, setLinkedRequestId] = useState<string>("");
  const [selectedInvoice, setSelectedInvoice] = useState<any | null>(null);
  const [selectedPurchase, setSelectedPurchase] = useState<Purchase | null>(
    null,
  );
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const handleVoiceSearch = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        setSearchQuery(customEvent.detail);
      }
    };
    window.addEventListener("voice_search", handleVoiceSearch);
    return () => window.removeEventListener("voice_search", handleVoiceSearch);
  }, []);

  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [warehouses, setWarehouses] = useState<any[]>([]);
  const [ingredients, setIngredients] = useState<any[]>([]);

  const [formData, setFormData] = useState({
    supplier_id: "",
    warehouse_id: "",
    invoice_number: "",
    paid_amount: "",
    notes: "",
    order_id: "",
  });

  const [purchaseItems, setPurchaseItems] = useState<
    {
      ingredient_id: number;
      name: string;
      unit: string;
      quantity: number;
      unit_price: number;
      accepted_quantity?: number;
      rejected_quantity?: number;
    }[]
  >([]);

  // Generic purchase lists based on current state
  const [requests, setRequests] = useState<any[]>([]);
  const [quotations, setQuotations] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([
    {
      id: 1,
      invoice_number: "INV-20231110-01",
      date: "2023-11-10T00:00:00Z",
      supplier: "شركة السلام للتجارة",
      order_id: "20231015-01",
      total_amount: 150000,
      paid_amount: 150000,
      status: "Paid",
      due_date: "2023-12-10T00:00:00Z",
    },
    {
      id: 2,
      invoice_number: "INV-20231111-02",
      date: "2023-11-11T00:00:00Z",
      supplier: "المصنع الحديث",
      order_id: "20231020-03",
      total_amount: 220000,
      paid_amount: 0,
      status: "Draft",
      due_date: "2023-12-11T00:00:00Z",
    },
    {
      id: 3,
      invoice_number: "INV-20231109-03",
      date: "2023-11-09T00:00:00Z",
      supplier: "الأجهزة المتقدمة",
      order_id: "20231018-02",
      total_amount: 85000,
      paid_amount: 85000,
      status: "Paid",
      due_date: "2023-12-09T00:00:00Z",
    },
  ]);
  const [returns, setReturns] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [costCenters, setCostCenters] = useState<any[]>([]);
  const [costItems, setCostItems] = useState<any[]>([]);
  const [expenseFormData, setExpenseFormData] = useState({
    voucher_no: "",
    amount: "",
    supplier_id: "",
    cost_center_id: "",
    cost_item_id: "",
    payment_method: "نقدي",
    safe: "خزينة فرع القاهرة",
    notes: "",
    branch: "القاهرة",
    department: "المشتريات",
  });

  // Orders State
  const [orders, setOrders] = useState<any[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [isOcrModalOpen, setIsOcrModalOpen] = useState(false);
  const [orderFormData, setOrderFormData] = useState({
    supplier_id: "",
    delivery_date: "",
    notes: "",
  });

  const [requestFormData, setRequestFormData] = useState({
    requested_by: "",
    notes: "",
  });

  // Quotations State
  const [quotationFormData, setQuotationFormData] = useState({
    quotation_number: "",
    request_id: "",
    supplier_id: "",
    delivery_date: "",
    notes: "",
  });
  const [quotationItems, setQuotationItems] = useState<any[]>([]);
  const [quotationItemInput, setQuotationItemInput] = useState({
    ingredient_id: "",
    name: "",
    unit: "كيلو",
    quantity: "1",
    unit_price: "0",
  });

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (purchaseItems.length === 0) return;
    try {
      const res = await api.post("/api/purchase-requests", {
        requested_by: requestFormData.requested_by || "غير محدد",
        notes: requestFormData.notes || "",
        items: purchaseItems,
      });
      if (res.ok) {
        setShowRequestModal(false);
        setRequestFormData({ requested_by: "", notes: "" });
        setPurchaseItems([]);
        fetchRequests();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchRequests = async () => {
    try {
      const res = await api.get("/api/purchase-requests");
      if (res.ok) {
        const data = await res.json();
        setRequests(Array.isArray(data) ? data : []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchRequestDetails = async (id: number) => {
    try {
      const res = await api.get(`/api/purchase-requests/${id}`);
      if (res.ok) {
        const data = await res.json();
        return data;
      }
    } catch (e) {
      console.error(e);
    }
    return null;
  };

  useEffect(() => {
    fetchPurchases();
    fetchReturns();
    fetchOrders();
    fetchRequests();
    fetchQuotations();
    fetchSuppliers();
    fetchWarehouses();
    fetchIngredients();
    fetchExpenses();
    fetchCostCenters();
    fetchCostItems();
  }, []);

  const fetchQuotations = async () => {
    try {
      const res = await api.get("/api/purchase-quotations");
      if (res.ok) {
        const data = await res.json();
        setQuotations(Array.isArray(data) ? data : []);
      }
    } catch (e) {
      console.error("Failed to fetch purchase quotations", e);
      setQuotations([]);
    }
  };

  const handleCreateQuotation = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const selectedSup = suppliers.find(
        (s) => String(s.id) === String(quotationFormData.supplier_id)
      );
      const estimated_value = quotationItems.reduce(
        (acc, item) => acc + (Number(item.quantity) * Number(item.unit_price) || 0),
        0
      );
      const payload = {
        quotation_number: quotationFormData.quotation_number || `RFQ-${Date.now().toString().slice(-6)}`,
        request_id: quotationFormData.request_id ? Number(quotationFormData.request_id) : null,
        supplier_id: quotationFormData.supplier_id ? Number(quotationFormData.supplier_id) : null,
        supplier: selectedSup ? selectedSup.name : "مورد عام",
        delivery_date: quotationFormData.delivery_date || null,
        estimated_value,
        status: "جديد",
        notes: quotationFormData.notes,
        items: quotationItems,
      };
      const res = await api.post("/api/purchase-quotations", payload);
      if (res.ok) {
        setShowQuotationModal(false);
        setQuotationFormData({
          quotation_number: "",
          request_id: "",
          supplier_id: "",
          delivery_date: "",
          notes: "",
        });
        setQuotationItems([]);
        fetchQuotations();
      }
    } catch (err) {
      console.error("Error creating purchase quotation:", err);
    }
  };

  const handleDeleteQuotation = async (id: number) => {
    if (!confirm("هل أنت تأكد من حذف عرض السعر؟")) return;
    try {
      const res = await api.delete(`/api/purchase-quotations/${id}`);
      if (res.ok) {
        fetchQuotations();
      }
    } catch (err) {
      console.error("Error deleting quotation:", err);
    }
  };

  const handleApproveQuotationToOrder = async (quot: any) => {
    try {
      const username = localStorage.getItem("username") || "أدمن";
      const orderPayload = {
        supplier_id: quot.supplier_id || null,
        delivery_date: quot.delivery_date || null,
        notes: `اعتماد بناءً على عرض السعر #${quot.quotation_number || quot.id}. ${quot.notes || ""}`,
        items: (quot.items && quot.items.length > 0) ? quot.items : [
          {
            ingredient_id: 1,
            quantity: 1,
            unit_price: quot.estimated_value || 0,
            total_price: quot.estimated_value || 0
          }
        ],
        requested_by: username,
      };
      const res = await api.post("/api/purchase-orders", orderPayload);
      if (res.ok) {
        await api.put(`/api/purchase-quotations/${quot.id}`, { status: "معتمد" });
        alert("تم اعتماد عرض السعر وتحويله إلى أمر شراء بنجاح!");
        fetchQuotations();
        fetchOrders();
        setActiveTab("orders");
      }
    } catch (err) {
      console.error("Error converting quotation to order:", err);
    }
  };

  const fetchOrders = async () => {
    try {
      const res = await api.get("/api/purchase-orders");
      if (res.ok) setOrders(await res.json());
    } catch (e) {
      console.error(e);
    }
  };

  const fetchOrderDetails = async (id: number) => {
    try {
      const res = await api.get(`/api/purchase-orders/${id}`);
      if (res.ok) setSelectedOrder(await res.json());
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (purchaseItems.length === 0) return;
    try {
      const username = localStorage.getItem("username") || "admin";
      const res = await api.post("/api/purchase-orders", {
        ...orderFormData,
        items: purchaseItems,
        requested_by: username,
      });
      if (res.ok) {
        const data = await res.json();
        setShowOrderModal(false);
        setOrderFormData({ supplier_id: "", delivery_date: "", notes: "" });
        setPurchaseItems([]);
        setLinkedRequestId("");
        fetchOrders();
        // Show notification if approval is required
        if (data.requires_approval) {
          alert("تم إنشاء أمر الشراء بنجاح وهو بانتظار الموافقة");
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchPurchases = async () => {
    try {
      const res = await api.get("/api/purchases");
      const data = await res.json();
      setPurchases(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch purchases", error);
      setPurchases([]);
    }
  };

  const fetchReturns = async () => {
    try {
      const res = await api.get("/api/returns");
      if (!res.ok) {
        setReturns([]);
        return;
      }
      const data = await res.json();
      setReturns(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch purchase returns", error);
      setReturns([]);
    }
  };

  const fetchExpenses = async () => {
    try {
      const res = await api.get("/api/costs");
      if (res.ok) {
        const payload = await res.json();
        setExpenses(payload.data || (Array.isArray(payload) ? payload : []));
      }
    } catch (error) {
      console.error("Failed to fetch expenses", error);
      setExpenses([]);
    }
  };

  const fetchCostCenters = async () => {
    try {
      const res = await api.get("/api/costs/centers");
      if (res.ok) {
        const payload = await res.json();
        setCostCenters(payload.data || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchCostItems = async () => {
    try {
      const res = await api.get("/api/costs/items");
      if (res.ok) {
        const payload = await res.json();
        setCostItems(payload.data || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const selectedSup = suppliers.find(
        (s) => String(s.id) === String(expenseFormData.supplier_id)
      );
      const username = localStorage.getItem("username") || "أدمن";
      const payload = {
        voucher_no: expenseFormData.voucher_no || `EXP-${Date.now().toString().slice(-6)}`,
        date: new Date().toISOString(),
        branch: expenseFormData.branch || "القاهرة",
        department: expenseFormData.department || "المشتريات",
        cost_center_id: expenseFormData.cost_center_id ? Number(expenseFormData.cost_center_id) : null,
        cost_item_id: expenseFormData.cost_item_id ? Number(expenseFormData.cost_item_id) : null,
        payment_method: expenseFormData.payment_method,
        safe: expenseFormData.safe,
        notes: expenseFormData.notes,
        amount: Number(expenseFormData.amount) || 0,
        status: "معتمد",
        created_by: username,
        link_ledger: true,
        supplier: selectedSup ? selectedSup.name : "",
        supplier_id: expenseFormData.supplier_id ? Number(expenseFormData.supplier_id) : null,
        category: "مشتريات",
      };
      const res = await api.post("/api/costs", payload);
      if (res.ok) {
        setShowExpenseModal(false);
        setExpenseFormData({
          voucher_no: "",
          amount: "",
          supplier_id: "",
          cost_center_id: "",
          cost_item_id: "",
          payment_method: "نقدي",
          safe: "خزينة فرع القاهرة",
          notes: "",
          branch: "القاهرة",
          department: "المشتريات",
        });
        fetchExpenses();
      }
    } catch (err) {
      console.error("Error creating expense:", err);
    }
  };

  const handleDeleteExpense = async (id: number) => {
    if (!confirm("هل أنت تأكد من حذف هذا المصروف؟")) return;
    try {
      const res = await api.delete(`/api/costs/${id}`);
      if (res.ok) {
        fetchExpenses();
      }
    } catch (err) {
      console.error("Error deleting expense:", err);
    }
  };

  const fetchSuppliers = async () => {
    try {
      const res = await api.get("/api/suppliers");
      const data = await res.json();
      setSuppliers(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch suppliers", error);
      setSuppliers([]);
    }
  };

  const fetchWarehouses = async () => {
    try {
      const res = await api.get("/api/inventory/warehouses");
      const data = await res.json();
      setWarehouses(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch warehouses", error);
      setWarehouses([]);
    }
  };

  const fetchIngredients = async () => {
    try {
      const [ingRes, prodRes] = await Promise.all([
        api.get("/api/ingredients").catch(() => ({ ok: false })),
        api.get("/api/products").catch(() => ({ ok: false })),
      ]);

      let ingData = [];
      let prodData = [];

      try {
        if (ingRes.ok) ingData = await (ingRes as any).json();
      } catch (e) {}
      try {
        if (prodRes.ok) prodData = await (prodRes as any).json();
      } catch (e) {}

      const combined = [
        ...(Array.isArray(ingData) ? ingData : []),
        ...(Array.isArray(prodData)
          ? prodData.map((p: any) => ({
              id: `p_${p.id}`,
              name: p.name,
              item_code: p.barcode || "-",
              unit: "قطعة",
              cost: p.cost || p.price || 0,
              is_product: true,
            }))
          : []),
      ];

      setIngredients(combined);
    } catch (error) {
      console.error("Failed to fetch items", error);
      setIngredients([]);
    }
  };

  const fetchPurchaseDetails = async (id: number) => {
    try {
      const res = await api.get(`/api/purchases/${id}`);
      const data = await res.json();
      setSelectedPurchase(data);
    } catch (error) {
      console.error("Failed to fetch purchase details", error);
    }
  };

  const calculateTotal = () => {
    if (activeTab === "orders") {
      return purchaseItems.reduce(
        (sum, item) => sum + (item.quantity || 0) * (item.unit_price || 0),
        0,
      );
    } else {
      return purchaseItems.reduce(
        (sum, item) =>
          sum +
          ((item.accepted_quantity ?? item.quantity) || 0) *
            (item.unit_price || 0),
        0,
      );
    }
  };

  const exportInvoiceToWord = (inv: any) => {
    const headers = ["البيان", "القيمة / التفاصيل"];
    const rows = [
      ["رقم الفاتورة", inv.invoice_number || `INV-${inv.id}`],
      ["المورد", inv.supplier || inv.supplier_name],
      ["تاريخ الفاتورة", new Date(inv.date).toLocaleDateString("ar-EG")],
      [
        "استحقاق الدفع",
        inv.due_date ? new Date(inv.due_date).toLocaleDateString("ar-EG") : "-",
      ],
      [
        "الحالة",
        inv.status === "Paid"
          ? "تم دفعها"
          : inv.status === "Draft"
            ? "مسودة"
            : "متأخرة",
      ],
      ["مرتبط بأمر شراء", inv.order_id ? `PO-${inv.order_id}` : "-"],
      [
        "إجمالي الفاتورة المطلوب",
        `${Number(inv.total_amount || 0 || 0).toLocaleString()} ج.م`,
      ],
    ];

    downloadDataAsWord(
      headers,
      rows,
      `فاتورة_مشتريات_${inv.invoice_number || inv.id}`,
      `فاتورة مشتريات رقم ${inv.invoice_number || inv.id}`,
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (purchaseItems.length === 0) return;
    if (!formData.warehouse_id) {
      alert("الرجاء اختيار المخزن المستلم");
      return;
    }
    if (!formData.supplier_id) {
      alert("الرجاء اختيار المورد");
      return;
    }

    const total_amount = calculateTotal();
    const paid_amount = Number(formData.paid_amount) || 0;

    try {
      const res = await api.post("/api/purchases", {
        supplier_id: Number(formData.supplier_id),
        warehouse_id: Number(formData.warehouse_id),
        order_id: formData.order_id ? Number(formData.order_id) : undefined,
        invoice_number: formData.invoice_number,
        total_amount,
        paid_amount,
        notes: formData.notes,
        items: purchaseItems.map((item) => ({
          ingredient_id: item.ingredient_id,
          quantity: item.accepted_quantity ?? item.quantity,
          unit_price: item.unit_price,
          total_price:
            (item.accepted_quantity ?? item.quantity) * item.unit_price,
        })),
      });

      if (res.ok) {
        if (formData.invoice_number) {
          const supplierObj = suppliers.find(
            (s) => s.id === Number(formData.supplier_id),
          );
          const newInvoice = {
            id: Math.floor(Math.random() * 1000) + 10,
            invoice_number: formData.invoice_number,
            date: new Date().toISOString(),
            supplier: supplierObj ? supplierObj.name : "Unknown",
            order_id: formData.order_id ? Number(formData.order_id) : null,
            total_amount: total_amount,
            paid_amount: paid_amount,
            status: paid_amount >= total_amount ? "Paid" : "Draft",
            due_date: new Date(
              Date.now() + 30 * 24 * 60 * 60 * 1000,
            ).toISOString(),
          };
          setInvoices((prev) => [newInvoice, ...prev]);
        }
        setShowModal(false);
        setFormData({
          supplier_id: "",
          warehouse_id: "",
          invoice_number: "",
          paid_amount: "",
          notes: "",
          order_id: "",
        });
        setPurchaseItems([]);
        fetchPurchases();
        fetchOrders();
      } else {
        const errorData = await res.json().catch(() => null);
        throw new Error(errorData?.error || `فشل الحفظ. كود الخطأ: ${res.status}`);
      }
    } catch (error: any) {
      console.error(error);
      alert(`فشل الحفظ: ${error.message || "تأكد من اختيار المورد والمخزن وتعبئة كافة البيانات بشكل صحيح"}`);
    }
  };

  const filteredPurchases = purchases.filter(
    (p) =>
      (p.supplier_name && p.supplier_name.includes(searchQuery)) ||
      (p.invoice_number && p.invoice_number.includes(searchQuery)),
  );

  const filteredOrders = orders.filter(
    (o) =>
      (o.supplier_name && o.supplier_name.includes(searchQuery)) ||
      (o.id && o.id.toString().includes(searchQuery)) ||
      (o.items &&
        o.items.some(
          (item: any) =>
            item.ingredient_name && item.ingredient_name.includes(searchQuery),
        )),
  );

  const filteredRequests = requests.filter(
    (r) => r.requested_by && r.requested_by.includes(searchQuery),
  );

  const filteredQuotations = quotations.filter(
    (q) =>
      !searchQuery ||
      (q.supplier && q.supplier.includes(searchQuery)) ||
      (q.quotation_number && q.quotation_number.includes(searchQuery)) ||
      (q.notes && q.notes.includes(searchQuery))
  );

  const filteredInvoices = invoices.filter(
    (i) => i.supplier && i.supplier.includes(searchQuery),
  );

  const filteredReturns = returns.filter(
    (r) => r.supplier && r.supplier.includes(searchQuery),
  );

  const filteredExpenses = expenses.filter(
    (e) =>
      !searchQuery ||
      (e.supplier && e.supplier.includes(searchQuery)) ||
      (e.voucher_no && e.voucher_no.includes(searchQuery)) ||
      (e.notes && e.notes.includes(searchQuery)) ||
      (e.cost_center_name && e.cost_center_name.includes(searchQuery)) ||
      (e.cost_item_name && e.cost_item_name.includes(searchQuery))
  );

  // Reports States
  const [reportSupplierId, setReportSupplierId] = useState<string>("");
  const [reportStartDate, setReportStartDate] = useState<string>("");
  const [reportEndDate, setReportEndDate] = useState<string>("");
  const [reportSubTab, setReportSubTab] = useState<"summary" | "suppliers" | "items" | "expenses">("summary");

  const renderReports = () => {
    let filteredP = [...purchases];
    let filteredE = [...expenses];
    let filteredR = [...returns];

    if (reportSupplierId) {
      filteredP = filteredP.filter(p => String(p.supplier_id) === reportSupplierId);
      filteredE = filteredE.filter(e => String(e.supplier_id) === reportSupplierId);
      filteredR = filteredR.filter(r => String(r.supplier_id) === reportSupplierId || (r.supplier_name && suppliers.find(s => s.id === Number(reportSupplierId))?.name === r.supplier_name));
    }

    if (reportStartDate) {
      const start = new Date(reportStartDate);
      filteredP = filteredP.filter(p => new Date(p.date) >= start);
      filteredE = filteredE.filter(e => new Date(e.date) >= start);
      filteredR = filteredR.filter(r => new Date(r.date) >= start);
    }

    if (reportEndDate) {
      const end = new Date(reportEndDate);
      end.setHours(23, 59, 59, 999);
      filteredP = filteredP.filter(p => new Date(p.date) <= end);
      filteredE = filteredE.filter(e => new Date(e.date) <= end);
      filteredR = filteredR.filter(r => new Date(r.date) <= end);
    }

    // Metrics
    const totalSpend = filteredP.reduce((sum, p) => sum + (p.total_amount || 0), 0);
    const totalPaid = filteredP.reduce((sum, p) => sum + (p.paid_amount || 0), 0);
    const totalUnpaid = totalSpend - totalPaid;
    const totalReturnVal = filteredR.reduce((sum, r) => sum + (Number(r.total_amount) || 0), 0);
    const totalExpenseVal = filteredE.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const netSpendVal = totalSpend + totalExpenseVal - totalReturnVal;

    // Chart 1: Spend by Supplier (Top 6)
    const supplierSpend: Record<string, number> = {};
    filteredP.forEach(p => {
      const name = p.supplier_name || "مورد غير محدد";
      supplierSpend[name] = (supplierSpend[name] || 0) + (p.total_amount || 0);
    });
    const sChartData = Object.entries(supplierSpend)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);

    // Chart 2: Daily Spend Trend
    const dailySpend: Record<string, number> = {};
    filteredP.forEach(p => {
      const day = p.date ? p.date.split("T")[0] : "تاريخ غير محدد";
      dailySpend[day] = (dailySpend[day] || 0) + (p.total_amount || 0);
    });
    const tChartData = Object.entries(dailySpend)
      .map(([date, amount]) => ({ date, amount }))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-10);

    // Chart 3: Expense by Center
    const centerSpend: Record<string, number> = {};
    filteredE.forEach(e => {
      const center = e.cost_center_name || e.category || "غير مصنف";
      centerSpend[center] = (centerSpend[center] || 0) + Number(e.amount || 0);
    });
    const eChartData = Object.entries(centerSpend).map(([name, value]) => ({ name, value }));

    // Items group
    const itemGroup: Record<string, { qty: number, total: number, unit: string }> = {};
    filteredP.forEach(p => {
      if (p.items) {
        p.items.forEach(item => {
          const name = item.ingredient_name || "صنف غير محدد";
          if (!itemGroup[name]) {
            itemGroup[name] = { qty: 0, total: 0, unit: item.unit || "كجم" };
          }
          itemGroup[name].qty += Number(item.quantity || 0);
          itemGroup[name].total += Number(item.total_price || 0);
        });
      }
    });
    const itemStats = Object.entries(itemGroup)
      .map(([name, details]) => ({ name, ...details }))
      .sort((a, b) => b.total - a.total);

    // Supplier stats
    const supStats: Record<string, { count: number, total: number, paid: number, unpaid: number }> = {};
    filteredP.forEach(p => {
      const name = p.supplier_name || "مورد غير محدد";
      if (!supStats[name]) {
        supStats[name] = { count: 0, total: 0, paid: 0, unpaid: 0 };
      }
      supStats[name].count += 1;
      supStats[name].total += p.total_amount || 0;
      supStats[name].paid += p.paid_amount || 0;
      supStats[name].unpaid += (p.total_amount || 0) - (p.paid_amount || 0);
    });
    const supplierStatsList = Object.entries(supStats).map(([name, d]) => ({ name, ...d }));

    const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#14b8a6"];

    const handlePrint = () => {
      window.print();
    };

    const handleExportCSV = () => {
      let csvContent = "data:text/csv;charset=utf-8,\uFEFF";
      if (reportSubTab === "summary") {
        csvContent += "المؤشر,القيمة (ج.م)\n";
        csvContent += `إجمالي المشتريات,${totalSpend}\n`;
        csvContent += `صافي الإنفاق,${netSpendVal}\n`;
        csvContent += `المبالغ المدفوعة,${totalPaid}\n`;
        csvContent += `المبالغ الآجلة (ديون الموردين),${totalUnpaid}\n`;
        csvContent += `قيمة المرتجعات,${totalReturnVal}\n`;
        csvContent += `المصروفات الإضافية,${totalExpenseVal}\n`;
      } else if (reportSubTab === "suppliers") {
        csvContent += "اسم المورد,عدد المعاملات,إجمالي المشتريات (ج.م),المدفوع (ج.م),الآجل (ج.م)\n";
        supplierStatsList.forEach(s => {
          csvContent += `"${s.name}",${s.count},${s.total},${s.paid},${s.unpaid}\n`;
        });
      } else if (reportSubTab === "items") {
        csvContent += "اسم المادة الخام / الصنف,الكمية المشتراة,الوحدة,إجمالي التكلفة (ج.م)\n";
        itemStats.forEach(i => {
          csvContent += `"${i.name}",${i.qty},"${i.unit}",${i.total}\n`;
        });
      } else if (reportSubTab === "expenses") {
        csvContent += "بند المصروف / مركز التكلفة,إجمالي المصروف (ج.م)\n";
        eChartData.forEach(e => {
          csvContent += `"${e.name}",${e.value}\n`;
        });
      }
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `تقرير_مشتريات_${reportSubTab}_${new Date().toISOString().split("T")[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

    return (
      <div className="space-y-6">
        {/* Filters and Control bar */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 flex flex-col lg:flex-row lg:items-center justify-between gap-4 print:hidden">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-emerald-600" />
              <span className="text-xs font-black text-slate-700">تصفية التقارير:</span>
            </div>

            {/* Supplier Filter */}
            <select
              value={reportSupplierId}
              onChange={(e) => setReportSupplierId(e.target.value)}
              className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-xs font-bold focus:border-emerald-500"
            >
              <option value="">كل الموردين</option>
              {suppliers.map((s) => (
                <option key={s.id} value={String(s.id)}>{s.name}</option>
              ))}
            </select>

            {/* Start Date */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] font-bold text-slate-400">من</span>
              <input
                type="date"
                value={reportStartDate}
                onChange={(e) => setReportStartDate(e.target.value)}
                className="bg-transparent border-none outline-none text-xs font-bold text-slate-700 cursor-pointer"
              />
            </div>

            {/* End Date */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] font-bold text-slate-400">إلى</span>
              <input
                type="date"
                value={reportEndDate}
                onChange={(e) => setReportEndDate(e.target.value)}
                className="bg-transparent border-none outline-none text-xs font-bold text-slate-700 cursor-pointer"
              />
            </div>

            {(reportSupplierId || reportStartDate || reportEndDate) && (
              <button
                onClick={() => {
                  setReportSupplierId("");
                  setReportStartDate("");
                  setReportEndDate("");
                }}
                className="text-xs text-rose-600 font-bold hover:underline"
              >
                إعادة تعيين
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 self-end lg:self-auto">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors"
            >
              <Printer className="w-4 h-4" /> طباعة التقارير
            </button>
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl font-bold text-xs transition-colors"
            >
              <Download className="w-4 h-4" /> تصدير تقرير ({reportSubTab === "summary" ? "ملخص" : reportSubTab === "suppliers" ? "موردين" : reportSubTab === "items" ? "أصناف" : "مصاريف"})
            </button>
          </div>
        </div>

        {/* Dashboard KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div className="space-y-1 text-right w-full">
              <span className="text-[10px] text-slate-400 font-black">إجمالي مشتريات التوريد</span>
              <h3 className="text-xl font-black text-slate-800">{Number(totalSpend || 0).toLocaleString()} ج.م</h3>
              <p className="text-[9px] text-slate-400 font-medium">قيمة الفواتير المسجلة بالمخازن</p>
            </div>
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl shrink-0">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div className="space-y-1 text-right w-full">
              <span className="text-[10px] text-slate-400 font-black">صافي الإنفاق الشامل</span>
              <h3 className="text-xl font-black text-blue-600">{Number(netSpendVal || 0).toLocaleString()} ج.م</h3>
              <p className="text-[9px] text-blue-500 font-medium">المشتريات + المصاريف - المرتجعات</p>
            </div>
            <div className="p-3 bg-blue-50 text-blue-600 rounded-xl shrink-0">
              <BarChart3 className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div className="space-y-1 text-right w-full">
              <span className="text-[10px] text-slate-400 font-black">المبالغ الآجلة (ديون الموردين)</span>
              <h3 className="text-xl font-black text-rose-600">{Number(totalUnpaid || 0).toLocaleString()} ج.م</h3>
              <p className="text-[9px] text-rose-500 font-medium">الأرصدة المستحقة للدفع لاحقاً</p>
            </div>
            <div className="p-3 bg-rose-50 text-rose-600 rounded-xl shrink-0">
              <TrendingDown className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div className="space-y-1 text-right w-full">
              <span className="text-[10px] text-slate-400 font-black">مرتجع ومصاريف إضافية</span>
              <h3 className="text-xl font-black text-amber-600">{Number(totalExpenseVal || 0).toLocaleString()} / {Number(totalReturnVal || 0).toLocaleString()} ج.م</h3>
              <p className="text-[9px] text-slate-400 font-medium">إجمالي المصروفات مقابل البضاعة المرتجعة</p>
            </div>
            <div className="p-3 bg-amber-50 text-amber-600 rounded-xl shrink-0">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Sub-tabs Selection */}
        <div className="flex border-b border-slate-200 print:hidden overflow-x-auto">
          <button
            onClick={() => setReportSubTab("summary")}
            className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px whitespace-nowrap ${reportSubTab === "summary" ? "border-emerald-500 text-emerald-600 font-black" : "border-transparent text-slate-500 hover:text-slate-700"}`}
          >
            ملخص التحليل البياني
          </button>
          <button
            onClick={() => setReportSubTab("suppliers")}
            className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px whitespace-nowrap ${reportSubTab === "suppliers" ? "border-emerald-500 text-emerald-600 font-black" : "border-transparent text-slate-500 hover:text-slate-700"}`}
          >
            تحليل الموردين والأداء
          </button>
          <button
            onClick={() => setReportSubTab("items")}
            className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px whitespace-nowrap ${reportSubTab === "items" ? "border-emerald-500 text-emerald-600 font-black" : "border-transparent text-slate-500 hover:text-slate-700"}`}
          >
            تحليل استهلاك المواد الخام والأصناف
          </button>
          <button
            onClick={() => setReportSubTab("expenses")}
            className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px whitespace-nowrap ${reportSubTab === "expenses" ? "border-emerald-500 text-emerald-600 font-black" : "border-transparent text-slate-500 hover:text-slate-700"}`}
          >
            تقرير تكاليف المصاريف الإضافية
          </button>
        </div>

        {/* Tab content rendering */}
        {reportSubTab === "summary" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Chart 1 */}
              <div className="bg-white p-5 border border-slate-200/80 rounded-2xl shadow-sm">
                <h4 className="text-xs font-black text-slate-700 mb-4 flex items-center gap-1.5">
                  <span className="w-1.5 h-3 bg-emerald-500 rounded-full"></span>
                  توزيع حجم الشراء حسب الموردين (أعلى 6 موردين)
                </h4>
                <div className="h-64">
                  {sChartData.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-slate-400 text-xs">لا يوجد بيانات شراء كافية للرسم البياني</div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={sChartData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis fontSize={10} tickLine={false} axisLine={false} />
                        <Tooltip formatter={(value) => [`${Number(value || 0).toLocaleString()} ج.م`, "إجمالي الشراء"]} />
                        <Bar dataKey="value" fill="#10b981" radius={[6, 6, 0, 0]} barSize={35} />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>

              {/* Chart 2 */}
              <div className="bg-white p-5 border border-slate-200/80 rounded-2xl shadow-sm">
                <h4 className="text-xs font-black text-slate-700 mb-4 flex items-center gap-1.5">
                  <span className="w-1.5 h-3 bg-blue-500 rounded-full"></span>
                  منحنى الإنفاق والطلب اليومي للمشتريات
                </h4>
                <div className="h-64">
                  {tChartData.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-slate-400 text-xs">لا يوجد بيانات شراء كافية للرسم البياني</div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={tChartData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="date" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis fontSize={10} tickLine={false} axisLine={false} />
                        <Tooltip formatter={(value) => [`${Number(value || 0).toLocaleString()} ج.م`, "مشتريات"]} />
                        <Line type="monotone" dataKey="amount" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>
            </div>

            {/* Audit Logs summary inside summary */}
            <div className="bg-white p-5 border border-slate-200/80 rounded-2xl shadow-sm">
              <h4 className="text-xs font-black text-slate-700 mb-3">سجل المراجعة والتحركات الأخيرة للتوريد والمشتريات</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="p-3 font-bold text-slate-600">التاريخ</th>
                      <th className="p-3 font-bold text-slate-600">رقم المستند</th>
                      <th className="p-3 font-bold text-slate-600">المورد</th>
                      <th className="p-3 font-bold text-slate-600">النوع</th>
                      <th className="p-3 font-bold text-slate-600">القيمة المالية</th>
                      <th className="p-3 font-bold text-slate-600">المدفوع</th>
                      <th className="p-3 font-bold text-slate-600">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredP.slice(0, 5).map(p => (
                      <tr key={`p-log-${p.id}`} className="hover:bg-slate-50/50">
                        <td className="p-3 text-slate-600">{new Date(p.date).toLocaleDateString("ar-EG")}</td>
                        <td className="p-3 font-mono font-bold text-slate-700">{p.invoice_number || `PO-REC-${p.id}`}</td>
                        <td className="p-3 font-bold text-slate-800">{p.supplier_name}</td>
                        <td className="p-3"><span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-lg text-[10px] font-bold">فاتورة توريد</span></td>
                        <td className="p-3 font-bold text-slate-800">{Number(p.total_amount || 0 || 0).toLocaleString()} ج.م</td>
                        <td className="p-3 text-emerald-600">{Number(p.paid_amount || 0 || 0).toLocaleString()} ج.م</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${p.paid_amount >= p.total_amount ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}>
                            {p.paid_amount >= p.total_amount ? "مسدد بالكامل" : "آجل / متبقي"}
                          </span>
                        </td>
                      </tr>
                    ))}
                    {filteredP.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-4 text-center text-slate-400">لا يوجد حركات مشتريات مطابقة للتصفية</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {reportSubTab === "suppliers" && (
          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
              <h4 className="text-xs font-black text-slate-700">جدول كشف أداء الموردين ومستحقات الديون والمسحوبات</h4>
              <span className="text-[10px] text-slate-400 font-bold">محدث بالربط المالي والدفعات</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    <th className="p-4 font-bold text-slate-600">اسم المورد</th>
                    <th className="p-4 font-bold text-slate-600 text-center">عدد الفواتير المسحوبة</th>
                    <th className="p-4 font-bold text-slate-600">إجمالي قيمة المسحوبات</th>
                    <th className="p-4 font-bold text-slate-600">المبلغ المسدد نقداً</th>
                    <th className="p-4 font-bold text-slate-600 text-rose-600">المتبقي الآجل (ديون المورد)</th>
                    <th className="p-4 font-bold text-slate-600">معدل الالتزام المحاسبي</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {supplierStatsList.map(s => {
                    const pct = s.total > 0 ? Math.round((s.paid / s.total) * 100) : 100;
                    return (
                      <tr key={`sup-stat-${s.name}`} className="hover:bg-slate-50/50">
                        <td className="p-4 font-bold text-slate-800">{s.name}</td>
                        <td className="p-4 text-center font-semibold text-slate-700">{s.count} فواتير</td>
                        <td className="p-4 font-bold text-slate-800">{Number(s.total || 0).toLocaleString()} ج.م</td>
                        <td className="p-4 text-emerald-600 font-bold">{Number(s.paid || 0).toLocaleString()} ج.م</td>
                        <td className="p-4 text-rose-600 font-bold">{Number(s.unpaid || 0).toLocaleString()} ج.م</td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                              <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${pct}%` }}></div>
                            </div>
                            <span className="text-[10px] font-black text-slate-600">{pct}% مسدد</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {supplierStatsList.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400">لا يوجد بيانات موردين مسجلة</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {reportSubTab === "items" && (
          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200">
              <h4 className="text-xs font-black text-slate-700">تقرير استهلاك ومشتريات المواد الخام والسلع بالمخازن</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    <th className="p-4 font-bold text-slate-600">اسم المادة الخام / الصنف</th>
                    <th className="p-4 font-bold text-slate-600">إجمالي الكمية المشتراة</th>
                    <th className="p-4 font-bold text-slate-600">الوحدة القياسية</th>
                    <th className="p-4 font-bold text-slate-600">إجمالي التكلفة الشاملة</th>
                    <th className="p-4 font-bold text-slate-600">متوسط سعر الشراء للوحدة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {itemStats.map(item => (
                    <tr key={`item-stat-${item.name}`} className="hover:bg-slate-50/50">
                      <td className="p-4 font-bold text-slate-800">{item.name}</td>
                      <td className="p-4 font-black text-slate-700">{Number(item.qty || 0).toLocaleString()}</td>
                      <td className="p-4 text-slate-500 font-bold">{item.unit}</td>
                      <td className="p-4 font-black text-emerald-700">{Number(item.total || 0).toLocaleString()} ج.م</td>
                      <td className="p-4 text-slate-600 font-bold">
                        {item.qty > 0 ? Math.round(item.total / item.qty || 0).toLocaleString() : 0} ج.م
                      </td>
                    </tr>
                  ))}
                  {itemStats.length === 0 && (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400">لا يوجد أصناف أو مواد خام تم شراؤها في الفترة المحددة</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {reportSubTab === "expenses" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-5 border border-slate-200/80 rounded-2xl shadow-sm lg:col-span-1">
              <h4 className="text-xs font-black text-slate-700 mb-4">هيكل المصاريف الإضافية وتكاليف التوريد</h4>
              <div className="h-64 flex justify-center">
                {eChartData.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-slate-400 text-xs">لا يوجد بيانات مصاريف إضافية</div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={eChartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={75}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {eChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${Number(value || 0).toLocaleString()} ج.م`, "المبلغ"]} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
              <div className="mt-4 flex flex-wrap gap-2 justify-center">
                {eChartData.map((e, index) => (
                  <div key={`legend-${index}`} className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                    <span className="text-[10px] font-bold text-slate-600">{e.name}: {Number(e.value || 0).toLocaleString()} ج.م</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden lg:col-span-2">
              <div className="p-4 bg-slate-50 border-b border-slate-200">
                <h4 className="text-xs font-black text-slate-700">تفاصيل السندات والمصروفات الإضافية المدفوعة</h4>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 border-b border-slate-100">
                    <tr>
                      <th className="p-4 font-bold text-slate-600">رقم السند</th>
                      <th className="p-4 font-bold text-slate-600">المركز المالي / البند</th>
                      <th className="p-4 font-bold text-slate-600">طريقة الدفع</th>
                      <th className="p-4 font-bold text-slate-600 text-rose-600">المبلغ المصروف</th>
                      <th className="p-4 font-bold text-slate-600">ملاحظات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredE.slice(0, 10).map(exp => (
                      <tr key={`exp-rep-${exp.id}`} className="hover:bg-slate-50/50">
                        <td className="p-4 font-mono font-bold text-slate-700">{exp.voucher_no || `#${exp.id}`}</td>
                        <td className="p-4">
                          <span className="font-bold text-slate-800">{exp.cost_center_name || "مركز عام"}</span>
                          <span className="block text-[10px] text-slate-400">{exp.cost_item_name || "مصروف إضافي"}</span>
                        </td>
                        <td className="p-4"><span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-bold">{exp.payment_method || "نقدي"}</span></td>
                        <td className="p-4 font-bold text-rose-600">{Number(exp.amount || 0 || 0).toLocaleString()} ج.م</td>
                        <td className="p-4 text-slate-500 max-w-[150px] truncate">{exp.notes || "-"}</td>
                      </tr>
                    ))}
                    {filteredE.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-6 text-center text-slate-400">لا يوجد مصاريف إضافية متوافقة مع التصفية الحالية</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-xl transition-colors"
          >
            <XCircle className="w-6 h-6 text-slate-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <ShoppingCart className="w-8 h-8 text-emerald-500" />
              {initialTab
                ? tabNames[activeTab] || "أوامر واستلام المشتريات"
                : "أوامر واستلام المشتريات"}
            </h1>
            <p className="text-slate-500 mt-1">
              {initialTab
                ? `القسم الفرعي: ${tabNames[activeTab] || ""}`
                : "إدارة أوامر الشراء واستلام المخزون"}
            </p>
          </div>
        </div>

        {!initialTab && (
          <div className="flex flex-wrap bg-slate-100 p-1 rounded-xl gap-1">
            {(Object.keys(tabNames) as PurchaseTab[]).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg font-bold text-sm transition-all ${activeTab === tab ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
              >
                {tabNames[tab]}
              </button>
            ))}
          </div>
        )}

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsOcrModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700 text-white rounded-xl hover:from-blue-800 hover:to-purple-800 transition-colors font-bold shadow-sm"
          >
            <Sparkles className="w-5 h-5 text-blue-300 animate-pulse" />
            مسح فاتورة 📸 OCR
          </button>
          <button
            onClick={() => {
              if (activeTab === "requests") setShowRequestModal(true);
              else if (activeTab === "quotations") setShowQuotationModal(true);
              else if (activeTab === "orders") {
                setPurchaseItems([]);
                setLinkedRequestId("");
                setShowOrderModal(true);
              }
              else if (activeTab === "receipts") setShowModal(true);
              else if (activeTab === "invoices") {
                setSelectedInvoice(null);
                setShowInvoiceModal(true);
              } else if (activeTab === "returns") setShowReturnModal(true);
              else if (activeTab === "expenses") setShowExpenseModal(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-500 text-white rounded-xl hover:bg-emerald-600 transition-colors font-bold"
          >
            <Plus className="w-5 h-5" />
            {activeTab === "requests"
              ? "إنشاء طلب شراء"
              : activeTab === "quotations"
                ? "إضافة عرض سعر"
                : activeTab === "orders"
                  ? "إنشاء أمر شراء"
                  : activeTab === "receipts"
                    ? "إستلام مشتريات جديد"
                    : activeTab === "invoices"
                      ? "إنشاء فاتورة مشتريات"
                      : activeTab === "returns"
                        ? "إنشاء مرتجع مشتريات"
                        : activeTab === "expenses"
                          ? "إضافة مروف إضافي"
                          : "جديد"}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 print:hidden">
        <div className="relative max-w-xl text-right">
          <Search className="w-5 h-5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث بالاسم، الرقم، أو المورد..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-4 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold"
          />
        </div>
      </div>

      {activeTab === "receipts" && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-auto max-h-[calc(100vh-270px)] print:hidden relative">
          <table className="w-full text-right min-w-[800px]">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-4 font-bold text-slate-600">رقم الفاتورة</th>
                <th className="p-4 font-bold text-slate-600">التاريخ</th>
                <th className="p-4 font-bold text-slate-600">المورد</th>
                <th className="p-4 font-bold text-slate-600">المخزن المستلم</th>
                <th className="p-4 font-bold text-slate-600">الأصناف</th>
                <th className="p-4 font-bold text-slate-600">الإجمالي</th>
                <th className="p-4 font-bold text-slate-600">المدفوع</th>
                <th className="p-4 font-bold text-slate-600">المتبقي</th>
                <th className="p-4 font-bold text-slate-600">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPurchases.map((purchase) => (
                <tr key={purchase.id} className="hover:bg-slate-50">
                  <td className="p-4 font-mono font-bold text-slate-700">
                    {purchase.invoice_number || `#${purchase.id}`}
                  </td>
                  <td className="p-4 text-slate-600">
                    {new Date(purchase.date).toLocaleDateString("ar-EG")}
                  </td>
                  <td className="p-4 font-bold text-slate-800">
                    {purchase.supplier_name}
                  </td>
                  <td className="p-4 text-slate-600">
                    {purchase.warehouse_name}
                  </td>
                  <td className="p-4 text-slate-600 truncate max-w-[200px]" title={purchase.item_names || "لا يوجد أصناف مسجلة"}>
                    {purchase.item_names || "لا يوجد أصناف مسجلة"}
                  </td>
                  <td className="p-4 font-bold text-slate-800">
                    {Number(purchase.total_amount || 0 || 0).toLocaleString()} ج.م
                  </td>
                  <td className="p-4 text-emerald-600 font-bold">
                    {Number(purchase.paid_amount || 0 || 0).toLocaleString()} ج.م
                  </td>
                  <td className="p-4 text-rose-600 font-bold">
                    {(
                      (purchase.total_amount || 0) - (purchase.paid_amount || 0)
                    ).toLocaleString()}{" "}
                    ج.م
                  </td>
                  <td className="p-4 flex gap-2">
                    <button
                      onClick={() => fetchPurchaseDetails(purchase.id)}
                      className="text-blue-600 hover:text-blue-800 font-bold text-sm bg-blue-50 px-2 py-1 rounded-lg"
                    >
                      التفاصيل
                    </button>
                    {(purchase.total_amount || 0) >
                      (purchase.paid_amount || 0) && (
                      <button
                        onClick={() => {
                          setActiveTab("invoices");
                          alert("إنشاء فاتورة مشتريات أو تسجيل الدفعة...");
                        }}
                        className="text-emerald-600 hover:text-emerald-800 font-bold text-sm bg-emerald-50 px-2 py-1 rounded-lg"
                      >
                        إصدار فاتورة
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setActiveTab("returns");
                        setShowReturnModal(true);
                      }}
                      className="text-rose-600 hover:text-rose-800 font-bold text-sm bg-rose-50 px-2 py-1 rounded-lg"
                    >
                      مرتجع
                    </button>
                  </td>
                </tr>
              ))}
              {filteredPurchases.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    لا توجد فواتير مشتريات
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "orders" && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-auto max-h-[calc(100vh-270px)] print:hidden relative">
          <table className="w-full text-right min-w-[800px]">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-4 font-bold text-slate-600">رقم الأمر</th>
                <th className="p-4 font-bold text-slate-600">التاريخ</th>
                <th className="p-4 font-bold text-slate-600">
                  تاريخ الاستلام المتوقع
                </th>
                <th className="p-4 font-bold text-slate-600">المورد</th>
                <th className="p-4 font-bold text-slate-600">الإجمالي</th>
                <th className="p-4 font-bold text-slate-600">الحالة</th>
                <th className="p-4 font-bold text-slate-600">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-slate-50">
                  <td className="p-4 font-mono font-bold text-slate-700">
                    ORD-{order.id.toString().padStart(4, "0")}
                  </td>
                  <td className="p-4 text-slate-600">
                    {new Date(order.date).toLocaleDateString("ar-EG")}
                  </td>
                  <td className="p-4 text-slate-600">
                    {order.delivery_date
                      ? new Date(order.delivery_date).toLocaleDateString(
                          "ar-EG",
                        )
                      : "-"}
                  </td>
                  <td className="p-4 font-bold text-slate-800">
                    {order.supplier_name}
                  </td>
                  <td className="p-4 font-bold text-slate-800">
                    {Number(order.total_amount || 0 || 0).toLocaleString()} ج.م
                  </td>
                  <td className="p-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-bold ${
                        order.status === "completed" || order.status === "approved"
                          ? "bg-emerald-100 text-emerald-800"
                          : order.status === "pending_approval"
                            ? "bg-violet-100 text-violet-800"
                            : order.status === "rejected"
                              ? "bg-red-100 text-red-800"
                              : "bg-amber-100 text-amber-800"
                      }`}
                    >
                      {order.status === "completed" || order.status === "approved"
                        ? "معتمد"
                        : order.status === "pending_approval"
                          ? "بانتظار الموافقة"
                          : order.status === "rejected"
                            ? "مرفوض"
                            : "قيد الانتظار"}
                    </span>
                  </td>
                  <td className="p-4 flex gap-2">
                    <button
                      onClick={() => fetchOrderDetails(order.id)}
                      className="text-blue-600 hover:text-blue-800 font-bold text-sm bg-blue-50 px-3 py-1 rounded-lg"
                    >
                      التفاصيل
                    </button>
                    {(order.status !== "completed" && order.status !== "pending_approval" && order.status !== "rejected") && (
                      <button
                        onClick={() => {
                          setActiveTab("receipts");
                          setShowModal(true);
                          // Ideally, pre-fill form data here
                        }}
                        className="text-emerald-600 hover:text-emerald-800 font-bold text-sm bg-emerald-50 px-3 py-1 rounded-lg"
                      >
                        إستلام
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500">
                    لا يوجد أوامر شراء
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "requests" && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-auto max-h-[calc(100vh-270px)] print:hidden relative">
          <table className="w-full text-right min-w-[800px]">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-4 font-bold text-slate-600">رقم الطلب</th>
                <th className="p-4 font-bold text-slate-600">التاريخ</th>
                <th className="p-4 font-bold text-slate-600">الجهة الطالبة</th>
                <th className="p-4 font-bold text-slate-600">عدد الأصناف</th>
                <th className="p-4 font-bold text-slate-600">الحالة</th>
                <th className="p-4 font-bold text-slate-600">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {requests.map((req) => (
                <tr
                  key={req.id}
                  className="border-b border-slate-100 hover:bg-slate-50"
                >
                  <td className="p-4 font-bold text-emerald-600">#{req.id}</td>
                  <td className="p-4 text-slate-600">
                    {new Date(req.date).toLocaleDateString("ar-EG")}
                  </td>
                  <td className="p-4 text-slate-600">{req.requested_by}</td>
                  <td className="p-4 text-slate-600">{req.items_count}</td>
                  <td className="p-4">
                    <span className="px-3 py-1 rounded-full text-sm font-bold bg-amber-100 text-amber-700">
                      {req.status === "Pending" ? "قيد الانتظار" : req.status}
                    </span>
                  </td>
                  <td className="p-4">
                    <button
                      onClick={() => {
                        setActiveTab("quotations");
                        setQuotations([
                          ...quotations,
                          {
                            id: quotations.length + 1,
                            request_id: req.id,
                            supplier: "مورد محدد",
                            estimated_value: 0,
                            status: "Draft",
                            date: new Date().toISOString(),
                          },
                        ]);
                      }}
                      className="text-emerald-600 hover:text-emerald-800 font-bold text-sm bg-emerald-50 px-3 py-1 rounded-lg"
                    >
                      إنشاء عرض سعر
                    </button>
                  </td>
                </tr>
              ))}
              {requests.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">
                    لا يوجد طلبات شراء
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "quotations" && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-auto max-h-[calc(100vh-270px)] print:hidden relative">
          <table className="w-full text-right min-w-[800px]">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-4 font-bold text-slate-600">رقم العرض</th>
                <th className="p-4 font-bold text-slate-600">التاريخ</th>
                <th className="p-4 font-bold text-slate-600">مرتبط بطلب</th>
                <th className="p-4 font-bold text-slate-600">المورد</th>
                <th className="p-4 font-bold text-slate-600">القيمة المقدرة</th>
                <th className="p-4 font-bold text-slate-600">الحالة</th>
                <th className="p-4 font-bold text-slate-600 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredQuotations.map((quot) => (
                <tr
                  key={quot.id}
                  className="border-b border-slate-100 hover:bg-slate-50 transition-colors"
                >
                  <td className="p-4 font-bold text-emerald-600 font-mono">
                    {quot.quotation_number || `#${quot.id}`}
                  </td>
                  <td className="p-4 text-slate-600 text-sm">
                    {quot.date ? new Date(quot.date).toLocaleDateString("ar-EG") : "-"}
                  </td>
                  <td className="p-4 text-slate-600 text-sm font-medium">
                    {quot.request_id ? `#${quot.request_id}` : "غير مرتبط"}
                  </td>
                  <td className="p-4 font-semibold text-slate-800">
                    {quot.supplier || "غير محدد"}
                  </td>
                  <td className="p-4 text-slate-800 font-bold">
                    {Number(quot.estimated_value || 0 || 0).toLocaleString()} ج.م
                  </td>
                  <td className="p-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      quot.status === "معتمد"
                        ? "bg-emerald-100 text-emerald-700"
                        : quot.status === "Draft" || quot.status === "مسودة"
                        ? "bg-slate-100 text-slate-700"
                        : "bg-blue-100 text-blue-700"
                    }`}>
                      {quot.status === "Draft" ? "مسودة" : quot.status || "جديد"}
                    </span>
                  </td>
                  <td className="p-4 flex items-center justify-center gap-2">
                    {quot.status !== "معتمد" && (
                      <button
                        onClick={() => handleApproveQuotationToOrder(quot)}
                        className="text-emerald-700 hover:text-emerald-900 font-bold text-xs bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        اعتماد كأمر شراء
                      </button>
                    )}
                    <button
                      onClick={() => handleDeleteQuotation(quot.id)}
                      className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                      title="حذف عرض السعر"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
              {filteredQuotations.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500">
                    لا يوجد عروض أسعار مسجلة
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "invoices" && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden print:hidden flex flex-col">
          <div className="overflow-auto w-full max-h-[calc(100vh-320px)] relative">
            <table className="w-full text-right min-w-max">
              <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10 shadow-sm">
                <tr>
                  <th className="p-4 font-bold text-slate-600">#</th>
                  <th className="p-4 font-bold text-slate-600">رقم الفاتورة</th>
                  <th className="p-4 font-bold text-slate-600">
                    تاريخ الفاتورة
                  </th>
                  <th className="p-4 font-bold text-slate-600">المورد</th>
                  <th className="p-4 font-bold text-slate-600">
                    أمر الشراء المرتبط
                  </th>
                  <th className="p-4 font-bold text-slate-600">
                    إجمالي المبلغ
                  </th>
                  <th className="p-4 font-bold text-slate-600">
                    حالة الفاتورة
                  </th>
                  <th className="p-4 font-bold text-slate-600">
                    تاريخ الاستحقاق
                  </th>
                  <th className="p-4 font-bold text-slate-600 text-center">
                    الإجراءات
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredInvoices.map((inv, idx) => (
                  <tr
                    key={inv.id}
                    className="border-b border-slate-100 hover:bg-slate-50"
                  >
                    <td className="p-4 text-slate-500">{idx + 1}</td>
                    <td
                      className="p-4 font-bold text-emerald-600 text-left"
                      dir="ltr"
                    >
                      {inv.invoice_number || `INV-${inv.id}`}
                    </td>
                    <td className="p-4 text-slate-600">
                      {new Date(inv.date).toLocaleDateString("ar-EG")}
                    </td>
                    <td className="p-4 font-bold text-slate-800">
                      {inv.supplier}
                    </td>
                    <td className="p-4 text-slate-600" dir="ltr">
                      {inv.order_id ? `PO-${inv.order_id}` : "-"}
                    </td>
                    <td className="p-4 font-bold text-slate-800">
                      {Number(inv.total_amount || 0 || 0).toLocaleString()} ج.م
                    </td>
                    <td className="p-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-bold ${
                          inv.status === "Paid"
                            ? "bg-emerald-100 text-emerald-700"
                            : inv.status === "Draft"
                              ? "bg-amber-100 text-amber-700"
                              : "bg-rose-100 text-rose-700"
                        }`}
                      >
                        {inv.status === "Paid"
                          ? "تم دفعها"
                          : inv.status === "Draft"
                            ? "مسودة"
                            : "متأخرة"}
                      </span>
                    </td>
                    <td className="p-4 text-slate-600">
                      {inv.due_date
                        ? new Date(inv.due_date).toLocaleDateString("ar-EG")
                        : "-"}
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2 justify-center">
                        <button className="p-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600">
                          <Search className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedInvoice(inv);
                            setShowInvoiceModal(true);
                          }}
                          className="p-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600"
                        >
                          <Settings className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => window.print()}
                          className="p-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600"
                          title="طباعة"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => exportInvoiceToWord(inv)}
                          className="p-2 bg-white border border-slate-200 rounded-lg hover:bg-blue-50 text-blue-600"
                          title="تصدير وورد"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredInvoices.length === 0 && (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-500">
                      لا يوجد فواتير مشتريات (يمكن إنشاؤها من الاستلامات)
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-between items-center text-sm font-bold text-slate-700">
            <div className="flex gap-8">
              <span>إجمالي الفواتير: {filteredInvoices.length}</span>
              <span>
                إجمالي المبلغ المستحق:{" "}
                {filteredInvoices
                  .filter((i) => i.status !== "Paid")
                  .reduce((sum, i) => sum + (i.total_amount || 0), 0)
                  .toLocaleString()}{" "}
                ج.م
              </span>
              <span>
                إجمالي المبلغ المدفوع:{" "}
                {filteredInvoices
                  .filter((i) => i.status === "Paid")
                  .reduce((sum, i) => sum + (i.paid_amount || 0), 0)
                  .toLocaleString()}{" "}
                ج.م
              </span>
            </div>
            <div className="flex gap-2">
              <button className="px-4 py-2 border border-slate-200 bg-white rounded-lg hover:bg-slate-50">
                تصدير إلى Excel
              </button>
              <button
                onClick={() => {
                  setSelectedInvoice(null);
                  setShowInvoiceModal(true);
                }}
                className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700"
              >
                إنشاء فاتورة جديدة
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === "returns" && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-auto max-h-[calc(100vh-270px)] print:hidden relative">
          <table className="w-full text-right min-w-[800px]">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-4 font-bold text-slate-600">رقم المرتجع</th>
                <th className="p-4 font-bold text-slate-600">رقم الفاتورة</th>
                <th className="p-4 font-bold text-slate-600">المورد</th>
                <th className="p-4 font-bold text-slate-600">قيمة المرتجع</th>
                <th className="p-4 font-bold text-slate-600">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {returns.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500">
                    لا يوجد مرتجعات
                  </td>
                </tr>
              )}
              {returns.map((ret) => (
                <tr key={ret.id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="p-4 font-mono font-bold text-slate-700">
                    {ret.return_number}
                  </td>
                  <td className="p-4 text-slate-600">
                    {ret.invoice_number || `#${ret.purchase_id || "-"}`}
                  </td>
                  <td className="p-4 font-bold text-slate-800">
                    {ret.supplier_name || "غير محدد"}
                  </td>
                  <td className="p-4 font-bold text-rose-600">
                    {Number(ret.total_amount || 0 || 0).toLocaleString()} ج.م
                  </td>
                  <td className="p-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      ret.status === "approved"
                        ? "bg-emerald-50 text-emerald-700"
                        : ret.status === "pending"
                          ? "bg-amber-50 text-amber-700"
                          : "bg-slate-100 text-slate-600"
                    }`}>
                      {ret.status === "approved" ? "معتمد" : ret.status === "pending" ? "قيد المراجعة" : "مسودة"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "expenses" && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-auto max-h-[calc(100vh-270px)] print:hidden relative">
          <table className="w-full text-right min-w-[800px]">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-4 font-bold text-slate-600">رقم السند</th>
                <th className="p-4 font-bold text-slate-600">التاريخ</th>
                <th className="p-4 font-bold text-slate-600">مركز الكلفة / البند</th>
                <th className="p-4 font-bold text-slate-600">الجهة / المورد</th>
                <th className="p-4 font-bold text-slate-600">طريقة الدفع</th>
                <th className="p-4 font-bold text-slate-600">المبلغ</th>
                <th className="p-4 font-bold text-slate-600">ملاحظات</th>
                <th className="p-4 font-bold text-slate-600 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredExpenses.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    لا يوجد مصاريف إضافية مسجلة
                  </td>
                </tr>
              ) : (
                filteredExpenses.map((exp: any) => (
                  <tr key={exp.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-mono font-bold text-slate-700">
                      {exp.voucher_no || `#${exp.id}`}
                    </td>
                    <td className="p-4 text-slate-600 text-sm">
                      {exp.date ? new Date(exp.date).toLocaleDateString("ar-EG") : "-"}
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-slate-800 text-sm">
                        {exp.cost_center_name || "مركز عام"}
                      </div>
                      <div className="text-xs text-slate-500">
                        {exp.cost_item_name || exp.category || "مصروف عام"}
                      </div>
                    </td>
                    <td className="p-4 font-medium text-slate-700 text-sm">
                      {exp.supplier || exp.department || "غير محدد"}
                    </td>
                    <td className="p-4 text-sm">
                      <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-bold">
                        {exp.payment_method || "نقدي"}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-emerald-600">
                      {Number(exp.amount || 0 || 0).toLocaleString()} ج.م
                    </td>
                    <td className="p-4 text-xs text-slate-500 max-w-[200px] truncate">
                      {exp.notes || "-"}
                    </td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => handleDeleteExpense(exp.id)}
                        className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                        title="حذف المصروف"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "reports" && renderReports()}

      {showReturnModal && (
        <ReturnModal
          onClose={() => setShowReturnModal(false)}
          onConfirm={async () => {
            setShowReturnModal(false);
            await Promise.all([fetchPurchases(), fetchReturns()]);
          }}
        />
      )}

      {/* Purchase Details Modal */}
      {selectedPurchase && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 print:p-0 print:bg-white print:block">
          <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-xl print:shadow-none print:max-h-none">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center print:border-b-2 print:border-black">
              <div>
                <h2 className="text-xl font-bold text-slate-800">
                  تفاصيل فاتورة المشتريات
                </h2>
                <p className="text-slate-500 text-sm mt-1">
                  رقم الفاتورة:{" "}
                  {selectedPurchase.invoice_number || `#${selectedPurchase.id}`}
                </p>
              </div>
              <div className="flex gap-2 print:hidden">
                <button
                  onClick={() => window.print()}
                  className="p-2 text-slate-400 hover:text-slate-600 bg-slate-100 rounded-lg"
                  title="طباعة"
                >
                  <Printer className="w-5 h-5" />
                </button>
                <button
                  onClick={() => exportInvoiceToWord(selectedPurchase)}
                  className="p-2 text-blue-500 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                  title="تصدير وورد"
                >
                  <FileText className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setSelectedPurchase(null)}
                  className="p-2 text-slate-400 hover:text-rose-600 bg-slate-100 rounded-lg"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 flex-1 overflow-y-auto print:overflow-visible">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-slate-50 p-4 rounded-xl print:bg-transparent print:border print:border-slate-300">
                  <p className="text-sm text-slate-500 mb-1">المورد</p>
                  <p className="font-bold text-slate-800">
                    {selectedPurchase.supplier_name}
                  </p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl print:bg-transparent print:border print:border-slate-300">
                  <p className="text-sm text-slate-500 mb-1">المخزن المستلم</p>
                  <p className="font-bold text-slate-800">
                    {selectedPurchase.warehouse_name}
                  </p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl print:bg-transparent print:border print:border-slate-300">
                  <p className="text-sm text-slate-500 mb-1">التاريخ</p>
                  <p className="font-bold text-slate-800">
                    {new Date(selectedPurchase.date).toLocaleDateString(
                      "ar-EG",
                    )}
                  </p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl print:bg-transparent print:border print:border-slate-300">
                  <p className="text-sm text-slate-500 mb-1">إجمالي الفاتورة</p>
                  <p className="font-bold text-slate-800">
                    {Number(selectedPurchase.total_amount || 0 || 0).toLocaleString()} ج.م
                  </p>
                </div>
              </div>

              <table className="w-full text-right border-collapse mb-6">
                <thead className="bg-slate-50 print:bg-slate-100">
                  <tr>
                    <th className="p-3 border border-slate-200 font-bold text-slate-700">
                      الصنف
                    </th>
                    <th className="p-3 border border-slate-200 font-bold text-slate-700">
                      الكمية
                    </th>
                    <th className="p-3 border border-slate-200 font-bold text-slate-700">
                      سعر الوحدة
                    </th>
                    <th className="p-3 border border-slate-200 font-bold text-slate-700">
                      الإجمالي
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {selectedPurchase.items?.map((item) => (
                    <tr key={item.id}>
                      <td className="p-3 border border-slate-200 font-bold text-slate-800">
                        {item.ingredient_name}
                      </td>
                      <td className="p-3 border border-slate-200 text-slate-600">
                        {item.quantity}{" "}
                        <span className="text-xs text-slate-400">
                          {item.unit}
                        </span>
                      </td>
                      <td className="p-3 border border-slate-200 text-slate-600">
                        {Number(item.unit_price || 0 || 0).toLocaleString()} ج.م
                      </td>
                      <td className="p-3 border border-slate-200 font-bold text-slate-800">
                        {Number(item.total_price || 0 || 0).toLocaleString()} ج.م
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="flex justify-end print:justify-start">
                <div className="w-64 space-y-3">
                  <div className="flex justify-between text-slate-600">
                    <span>الإجمالي:</span>
                    <span className="font-bold text-slate-800">
                      {Number(selectedPurchase.total_amount || 0 || 0).toLocaleString()}{" "}
                      ج.م
                    </span>
                  </div>
                  <div className="flex justify-between text-emerald-600">
                    <span>المدفوع:</span>
                    <span className="font-bold">
                      {Number(selectedPurchase.paid_amount || 0 || 0).toLocaleString()} ج.م
                    </span>
                  </div>
                  <div className="flex justify-between text-rose-600 border-t border-slate-200 pt-3">
                    <span>المتبقي:</span>
                    <span className="font-bold">
                      {(
                        (selectedPurchase.total_amount || 0) -
                        (selectedPurchase.paid_amount || 0)
                      ).toLocaleString()}{" "}
                      ج.م
                    </span>
                  </div>
                </div>
              </div>

              {selectedPurchase.notes && (
                <div className="mt-8 p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="text-sm font-bold text-slate-700 mb-1">
                    ملاحظات:
                  </p>
                  <p className="text-slate-600">{selectedPurchase.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Purchase Order Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">
                أمر شراء جديد
              </h2>
              <button
                onClick={() => setShowOrderModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <form
              onSubmit={handleCreateOrder}
              className="flex-1 overflow-y-auto"
            >
              <div className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      المورد
                    </label>
                    <SearchableSelect
                      options={suppliers.map((s) => ({
                        id: s.id,
                        label: s.name,
                      }))}
                      value={orderFormData.supplier_id}
                      onChange={(value) =>
                        setOrderFormData({
                          ...orderFormData,
                          supplier_id: value as string,
                        })
                      }
                      placeholder="اختر المورد..."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      تاريخ الاستلام المتوقع
                    </label>
                    <input
                      type="date"
                      value={orderFormData.delivery_date}
                      onChange={(e) =>
                        setOrderFormData({
                          ...orderFormData,
                          delivery_date: e.target.value,
                        })
                      }
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-emerald-700 mb-2">
                      ربط بطلب شراء (اختياري)
                    </label>
                    <SearchableSelect
                      options={requests.map((r) => ({
                        id: r.id.toString(),
                        label: `طلب #${r.id} - ${r.requested_by} (${new Date(r.date).toLocaleDateString("ar-EG")})`,
                      }))}
                      value={linkedRequestId}
                      onChange={(value) => {
                        setLinkedRequestId(value as string);
                        if (value) {
                          const req = requests.find((r) => r.id.toString() === value.toString());
                          if (req) {
                            if (req.items) {
                              setPurchaseItems(
                                req.items.map((item: any) => ({
                                  ingredient_id: item.ingredient_id,
                                  name: item.name,
                                  unit: item.unit,
                                  quantity: item.quantity,
                                  unit_price: item.unit_price || 0,
                                }))
                              );
                            } else if (Number(req.id) === 1) {
                              setPurchaseItems([
                                { ingredient_id: 2, name: "كاسات بلاستيك مطبوع 16 أونص", unit: "Nos", quantity: 50, unit_price: 2.2 },
                                { ingredient_id: 5, name: "قطع غيار سخانات إيطالي", unit: "قطعة", quantity: 5, unit_price: 120 }
                              ]);
                            }
                          }
                        } else {
                          setPurchaseItems([]);
                        }
                      }}
                      placeholder="اختر طلب الشراء لربطه..."
                    />
                  </div>
                </div>

                {/* Items Selection */}
                <div className="border border-slate-200 rounded-xl">
                  <div className="bg-slate-50 p-4 border-b border-slate-200">
                    <h3 className="font-bold text-slate-800">الأصناف</h3>
                  </div>
                  <div className="p-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="md:col-span-4">
                        <SearchableSelect
                          options={ingredients.map((ing) => ({
                            id: ing.id,
                            label: ing.name,
                            item_code: ing.item_code || "-",
                            unit: ing.unit,
                            cost: ing.cost,
                          }))}
                          value=""
                          onChange={(value) => {
                            if (value) {
                              const ing = ingredients.find(
                                (i) => i.id.toString() === value.toString(),
                              );
                              if (
                                ing &&
                                !purchaseItems.find(
                                  (i) =>
                                    i.ingredient_id?.toString() ===
                                    ing.id.toString(),
                                )
                              ) {
                                setPurchaseItems([
                                  ...purchaseItems,
                                  {
                                    ingredient_id: ing.id,
                                    name: ing.name,
                                    unit: ing.unit,
                                    quantity: 1,
                                    unit_price: ing.cost || 0,
                                  },
                                ]);
                              }
                            }
                          }}
                          placeholder="إضافة صنف (ابحث بالاسم أو الباركود)..."
                          searchKeys={["label", "item_code"]}
                          labelKey="label"
                          columns={[
                            { key: "item_code", title: "كود / باركود" },
                            { key: "label", title: "الاسم" },
                            { key: "unit", title: "الوحدة" },
                          ]}
                        />
                      </div>
                    </div>

                    {purchaseItems.length > 0 && (
                      <table className="w-full text-right text-sm">
                        <thead className="text-slate-500 border-b border-slate-100">
                          <tr>
                            <th className="pb-2 font-bold">الصنف</th>
                            <th className="pb-2 font-bold">الكمية</th>
                            <th className="pb-2 font-bold">الوحدة</th>
                            <th className="pb-2 font-bold">سعر الوحدة</th>
                            <th className="pb-2 font-bold">الإجمالي</th>
                            <th className="pb-2 font-bold"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          {purchaseItems.map((item, idx) => (
                            <tr key={idx}>
                              <td className="py-2 text-slate-800 font-bold w-1/3">
                                {item.name}
                              </td>
                              <td className="py-2 w-24">
                                <input
                                  type="number"
                                  min="1"
                                  step="any"
                                  value={item.quantity || ""}
                                  onChange={(e) => {
                                    const newItems = [...purchaseItems];
                                    newItems[idx].quantity =
                                      parseFloat(e.target.value) || 0;
                                    setPurchaseItems(newItems);
                                  }}
                                  className="w-20 p-2 bg-slate-50 border border-slate-200 rounded-lg text-center outline-none"
                                />
                              </td>
                              <td className="py-2 text-slate-500">
                                {item.unit}
                              </td>
                              <td className="py-2 w-28">
                                <input
                                  type="number"
                                  min="0"
                                  step="any"
                                  value={item.unit_price || ""}
                                  onChange={(e) => {
                                    const newItems = [...purchaseItems];
                                    newItems[idx].unit_price =
                                      parseFloat(e.target.value) || 0;
                                    setPurchaseItems(newItems);
                                  }}
                                  className="w-24 p-2 bg-slate-50 border border-slate-200 rounded-lg text-center outline-none"
                                />
                              </td>
                              <td className="py-2 text-emerald-600 font-bold">
                                {(
                                  item.quantity * item.unit_price
                                ).toLocaleString()}{" "}
                                ج.م
                              </td>
                              <td className="py-2">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setPurchaseItems(
                                      purchaseItems.filter((_, i) => i !== idx),
                                    )
                                  }
                                  className="p-1 hover:bg-rose-50 text-rose-500 rounded"
                                >
                                  <XCircle className="w-5 h-5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      الإجمالي الكلي
                    </label>
                    <div className="p-3 bg-emerald-50 text-emerald-700 font-bold rounded-xl text-xl">
                      {Number(calculateTotal() || 0).toLocaleString()} ج.م
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    ملاحظات والتوجيهات التشغيلية
                  </label>
                  <textarea
                    value={orderFormData.notes}
                    onChange={(e) =>
                      setOrderFormData({
                        ...orderFormData,
                        notes: e.target.value,
                      })
                    }
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                    rows={3}
                  />
                </div>
              </div>

              <div className="p-6 border-t border-slate-100 flex justify-end gap-3 sticky bottom-0 bg-white rounded-b-2xl">
                <button
                  type="button"
                  onClick={() => setShowOrderModal(false)}
                  className="px-6 py-2.5 bg-slate-100 text-slate-700 hover:bg-slate-200 font-bold rounded-xl transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={
                    purchaseItems.length === 0 || !orderFormData.supplier_id
                  }
                  className="flex items-center gap-2 px-8 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl transition-colors disabled:opacity-50"
                >
                  حفظ الأمر
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Purchase Invoice Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-slate-50">
              <div>
                <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
                  صفحة استلام المشتريات (Goods Receipt)
                </h2>
                <p className="text-slate-500 mt-1">
                  تفاصيل إيصال الاستلام:{" "}
                  <span
                    className="font-mono font-bold text-slate-800"
                    dir="ltr"
                  >
                    #GR-{new Date().getFullYear()}
                    {String(new Date().getMonth() + 1).padStart(2, "0")}
                    {String(new Date().getDate()).padStart(2, "0")}-001
                  </span>
                </p>
              </div>
              <div className="flex items-center gap-4 relative">
                <div className="w-64">
                  <SearchableSelect
                    options={orders
                      .filter((o) => o.status !== "completed")
                      .map((o) => ({
                        id: o.id,
                        label: `أمر شراء #${o.id} - ${o.supplier_name}`,
                        items_str:
                          o.items
                            ?.map((i: any) => i.ingredient_name)
                            .join(" ") || "",
                      }))}
                    searchKeys={["label", "items_str"]}
                    value=""
                    onChange={async (value) => {
                      if (value) {
                        try {
                          const res = await api.get(
                            `/api/purchase-orders/${value}`,
                          );
                          if (res.ok) {
                            const orderData = await res.json();
                            setFormData({
                              ...formData,
                              supplier_id: orderData.supplier_id.toString(),
                              order_id: value.toString(),
                            });
                            setPurchaseItems(
                              orderData.items.map((i: any) => ({
                                ingredient_id: i.ingredient_id,
                                name: i.ingredient_name,
                                unit: i.unit,
                                quantity: i.quantity,
                                unit_price: i.unit_price,
                                total_price: i.quantity * i.unit_price,
                                accepted_quantity: i.quantity,
                                rejected_quantity: 0,
                              })),
                            );
                          }
                        } catch (e) {}
                      }
                    }}
                    placeholder="الحصول على البنود من أمر شراء..."
                  />
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-slate-400 hover:text-slate-600 ml-2"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>
            </div>

            <form
              onSubmit={handleSubmit}
              className="p-6 flex-1 overflow-y-auto space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    المورد
                  </label>
                  <SearchableSelect
                    options={suppliers.map((s) => ({
                      id: s.id,
                      label: s.name,
                    }))}
                    value={Number(formData.supplier_id)}
                    onChange={(value) =>
                      setFormData({
                        ...formData,
                        supplier_id: value.toString(),
                      })
                    }
                    placeholder="اختر المورد..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    المخزن المستلم
                  </label>
                  <SearchableSelect
                    options={warehouses.map((w) => ({
                      id: w.id,
                      label:
                        w.type === "main"
                          ? "المخزن الرئيسي (Central Warehouse)"
                          : w.is_kitchen
                            ? `${w.name} (Kitchen Store)`
                            : `${w.name} (Branch Store)`,
                    }))}
                    value={Number(formData.warehouse_id)}
                    onChange={(value) =>
                      setFormData({
                        ...formData,
                        warehouse_id: value.toString(),
                      })
                    }
                    placeholder="اختر المخزن..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    رقم الفاتورة (اختياري)
                  </label>
                  <input
                    type="text"
                    value={formData.invoice_number}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        invoice_number: e.target.value,
                      })
                    }
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    placeholder="رقم فاتورة المورد"
                  />
                </div>
              </div>

              <div className="border-t border-slate-200 pt-6">
                <h3 className="font-bold text-slate-800 mb-4">
                  أصناف الفاتورة
                </h3>

                <div className="flex gap-2 mb-4">
                  <div className="flex-1">
                    <SearchableSelect
                      options={ingredients.map((ing) => ({
                        id: ing.id,
                        label: ing.name,
                        item_code: ing.item_code || "-",
                        unit: ing.unit,
                        cost: ing.cost,
                      }))}
                      value=""
                      onChange={(value) => {
                        if (value) {
                          const ing = ingredients.find(
                            (i) => i.id.toString() === value.toString(),
                          );
                          if (
                            ing &&
                            !purchaseItems.find(
                              (i) =>
                                i.ingredient_id?.toString() ===
                                ing.id.toString(),
                            )
                          ) {
                            setPurchaseItems([
                              ...purchaseItems,
                              {
                                ingredient_id: ing.id,
                                name: ing.name,
                                unit: ing.unit,
                                quantity: 1,
                                unit_price: ing.cost || 0,
                              },
                            ]);
                          }
                        }
                      }}
                      placeholder="إضافة صنف للفاتورة (ابحث بالاسم أو الباركود)..."
                      searchKeys={["label", "item_code"]}
                      labelKey="label"
                      columns={[
                        { key: "item_code", title: "كود / باركود" },
                        { key: "label", title: "الاسم" },
                        { key: "unit", title: "الوحدة" },
                      ]}
                    />
                  </div>
                </div>

                {purchaseItems.length > 0 && (
                  <div className="border border-slate-200 rounded-xl overflow-x-auto mb-6">
                    <table className="w-full text-right min-w-max text-sm">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="p-3 font-bold text-slate-600">#</th>
                          <th className="p-3 font-bold text-slate-600">
                            كود الصنف
                          </th>
                          <th className="p-3 font-bold text-slate-600">
                            اسم الصنف
                          </th>
                          <th className="p-3 font-bold text-slate-600">
                            وصف الصنف
                          </th>
                          <th className="p-3 font-bold text-slate-600 text-center">
                            الكمية المطلوبة
                          </th>
                          <th className="p-3 font-bold text-slate-600 text-center">
                            المستلم سابقا
                          </th>
                          <th className="p-3 font-bold text-slate-600 text-center">
                            الكمية الحالية
                          </th>
                          <th className="p-3 font-bold text-slate-600 text-center">
                            حالة الاستلام
                          </th>
                          <th className="p-3 font-bold text-slate-600">
                            المخزن / الموقع
                          </th>
                          <th className="p-3 font-bold text-slate-600">
                            رقم التشغيلة / المسلسل
                          </th>
                          <th className="p-3 font-bold text-slate-600">
                            تاريخ الانتهاء
                          </th>
                          <th className="p-3"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {purchaseItems.map((item, idx) => (
                          <tr
                            key={item.ingredient_id}
                            className="hover:bg-slate-50"
                          >
                            <td className="p-3 text-slate-500">{idx + 1}</td>
                            <td className="p-3 font-mono font-bold text-slate-700">
                              PRD-0{idx + 1}
                            </td>
                            <td className="p-3 font-bold text-slate-800">
                              {item.name}
                            </td>
                            <td className="p-3 text-slate-500 truncate max-w-[150px]">
                              مواصفات الصنف...
                            </td>
                            <td className="p-3 text-center font-bold text-slate-700">
                              {item.quantity}
                            </td>
                            <td className="p-3 text-center text-slate-500">
                              {Math.floor(item.quantity * 0.2)}
                            </td>
                            <td className="p-3">
                              <div className="flex justify-center">
                                <input
                                  type="number"
                                  min="0"
                                  step="any"
                                  value={
                                    item.accepted_quantity ?? item.quantity
                                  }
                                  onChange={(e) => {
                                    const newItems = [...purchaseItems];
                                    newItems[idx].accepted_quantity = Number(
                                      e.target.value,
                                    );
                                    setPurchaseItems(newItems);
                                  }}
                                  className="w-20 p-2 border border-slate-200 rounded-lg text-center font-bold text-emerald-700 focus:ring-2 focus:ring-emerald-500 outline-none"
                                />
                              </div>
                            </td>
                            <td className="p-3 text-center">
                              <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 mx-auto">
                                <svg
                                  className="w-5 h-5"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth="2"
                                    d="M5 13l4 4L19 7"
                                  ></path>
                                </svg>
                              </div>
                            </td>
                            <td className="p-3 text-slate-600">
                              مخزن A1 <br />{" "}
                              <span className="text-xs text-slate-400">
                                (طابق 2)
                              </span>
                            </td>
                            <td className="p-3 font-mono text-slate-600">
                              L2310-01A
                            </td>
                            <td className="p-3 text-slate-600">25-10-2024</td>
                            <td className="p-3 text-left">
                              <button
                                type="button"
                                onClick={() =>
                                  setPurchaseItems(
                                    purchaseItems.filter((_, i) => i !== idx),
                                  )
                                }
                                className="text-rose-500 hover:bg-rose-50 p-2 rounded-lg"
                              >
                                <XCircle className="w-5 h-5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between font-bold text-slate-700">
                      <div>
                        إجمالي الكميات:{" "}
                        {purchaseItems.reduce(
                          (acc, curr) => acc + (curr.quantity || 0),
                          0,
                        )}
                      </div>
                      <div>
                        إجمالي المستلم:{" "}
                        {purchaseItems.reduce(
                          (acc, curr) => acc + (curr.accepted_quantity || 0),
                          0,
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-slate-200 pt-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    ملاحظات الفاتورة
                  </label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) =>
                      setFormData({ ...formData, notes: e.target.value })
                    }
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none h-24 resize-none"
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-600">
                      إجمالي الفاتورة:
                    </span>
                    <span className="text-xl font-bold text-slate-900">
                      {(calculateTotal() || 0).toLocaleString()} ج.م
                    </span>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      المبلغ المدفوع الآن
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        max={calculateTotal()}
                        value={formData.paid_amount}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            paid_amount: e.target.value,
                          })
                        }
                        className="w-full p-3 pl-12 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold">
                        ج.م
                      </span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                    <span className="font-bold text-rose-600">
                      المتبقي (يضاف لحساب المورد):
                    </span>
                    <span className="font-bold text-rose-600">
                      {(
                        (calculateTotal() || 0) -
                        (Number(formData.paid_amount) || 0)
                      ).toLocaleString()}{" "}
                      ج.م
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-3 bg-slate-100 text-slate-700 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={
                    purchaseItems.length === 0 ||
                    !formData.supplier_id ||
                    !formData.warehouse_id
                  }
                  className="flex-1 px-4 py-3 bg-emerald-500 text-white rounded-xl font-bold hover:bg-emerald-600 transition-colors disabled:opacity-50"
                >
                  حفظ الفاتورة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}



      {showInvoiceModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-slate-50">
              <div>
                <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
                  {selectedInvoice
                    ? "تعديل فاتورة مشتريات"
                    : "إنشاء فاتورة مشتريات جديدة"}
                </h2>
                <p className="text-slate-500 mt-1">
                  رقم الفاتورة:{" "}
                  <span
                    className="font-mono font-bold text-slate-800"
                    dir="ltr"
                  >
                    {selectedInvoice
                      ? selectedInvoice.invoice_number
                      : `INV-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, "0")}${String(new Date().getDate()).padStart(2, "0")}-00${Math.floor(Math.random() * 90) + 10}`}
                  </span>
                </p>
              </div>
              <button
                onClick={() => setShowInvoiceModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 flex-1 overflow-y-auto space-y-6 text-right">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    المورد
                  </label>
                  <SearchableSelect
                    options={suppliers.map((s) => ({
                      id: s.id.toString(),
                      label: s.name,
                    }))}
                    value={selectedInvoice ? selectedInvoice.supplier : ""}
                    onChange={(val) => {}}
                    placeholder="اختر المورد..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    أمر الشراء المرتبط
                  </label>
                  <select
                    className="flex-1 p-2 w-full border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                    defaultValue={selectedInvoice?.order_id || ""}
                  >
                    <option value="">لا يوجد أمر شراء</option>
                    <option value="20231015-01">PO-20231015-01</option>
                    <option value="20231020-03">PO-20231020-03</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    تاريخ الفاتورة
                  </label>
                  <input
                    type="date"
                    className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                    defaultValue={
                      selectedInvoice
                        ? new Date(selectedInvoice.date)
                            .toISOString()
                            .split("T")[0]
                        : new Date().toISOString().split("T")[0]
                    }
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    تاريخ الاستحقاق
                  </label>
                  <input
                    type="date"
                    className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                    defaultValue={
                      selectedInvoice?.due_date
                        ? new Date(selectedInvoice.due_date)
                            .toISOString()
                            .split("T")[0]
                        : ""
                    }
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    إجمالي المبلغ (للضريبة + الشحن)
                  </label>
                  <input
                    type="number"
                    className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                    defaultValue={selectedInvoice?.total_amount || 0}
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    ما تم دفعه
                  </label>
                  <input
                    type="number"
                    className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                    defaultValue={selectedInvoice?.paid_amount || 0}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  ملاحظات / شروط الدفع
                </label>
                <textarea
                  className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none h-24"
                  placeholder="إضافة ملاحظات..."
                ></textarea>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-x-auto mb-6">
                <table className="w-full text-right min-w-max text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="p-3 font-bold text-slate-600">
                        كود الصنف
                      </th>
                      <th className="p-3 font-bold text-slate-600">
                        اسم الصنف
                      </th>
                      <th className="p-3 font-bold text-slate-600 text-center">
                        الكمية
                      </th>
                      <th className="p-3 font-bold text-slate-600 text-center">
                        سعر الوحدة
                      </th>
                      <th className="p-3 font-bold text-slate-600">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-mono font-bold text-slate-700">
                        PRD-001
                      </td>
                      <td className="p-3 font-bold text-slate-800">
                        لابتوب ديل XPS 15
                      </td>
                      <td className="p-3 text-center text-slate-700">
                        <input
                          type="number"
                          defaultValue="5"
                          className="w-20 p-2 border border-slate-200 rounded-lg text-center"
                        />
                      </td>
                      <td className="p-3">
                        <input
                          type="number"
                          defaultValue="30000"
                          className="w-24 mx-auto p-2 border border-slate-200 rounded-lg text-center"
                        />
                      </td>
                      <td className="p-3 text-emerald-600 font-bold">
                        150,000 ج.م
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex items-center justify-between">
              <div className="flex gap-4 items-center">
                <div className="flex flex-col justify-center text-right ml-2">
                  <span className="font-bold text-sm text-slate-700">
                    إرفاق صورة الفاتورة الأصلية
                  </span>
                  <span className="text-xs text-slate-500">(اختياري)</span>
                </div>
                <div className="flex gap-2">
                  <button className="flex flex-col items-center justify-center w-12 h-14 border border-blue-200 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors">
                    <span className="text-[10px] font-bold mt-1">PDF</span>
                  </button>
                  <button className="flex flex-col items-center justify-center w-12 h-14 border border-emerald-200 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-100 transition-colors">
                    <span className="text-[10px] font-bold mt-1">صورة</span>
                  </button>
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowInvoiceModal(false)}
                  className="px-6 py-2.5 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 font-bold transition-all bg-white"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={() => setShowInvoiceModal(false)}
                  className="px-6 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 font-bold transition-all shadow-sm"
                >
                  حفظ كمسودة
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const newInvoice = {
                      id: selectedInvoice
                        ? selectedInvoice.id
                        : Math.floor(Math.random() * 1000) + 10,
                      invoice_number: selectedInvoice
                        ? selectedInvoice.invoice_number
                        : `INV-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, "0")}${String(new Date().getDate()).padStart(2, "0")}-00${Math.floor(Math.random() * 90) + 10}`,
                      date: new Date().toISOString(),
                      supplier: selectedInvoice
                        ? selectedInvoice.supplier
                        : "شركة السلام للتجارة",
                      order_id: "20231015-01",
                      total_amount: 150000,
                      paid_amount: 150000,
                      status: "Paid",
                      due_date: new Date(
                        Date.now() + 30 * 24 * 60 * 60 * 1000,
                      ).toISOString(),
                    };
                    if (selectedInvoice) {
                      setInvoices(
                        invoices.map((i) =>
                          i.id === selectedInvoice.id ? newInvoice : i,
                        ),
                      );
                    } else {
                      setInvoices([newInvoice, ...invoices]);
                    }
                    setShowInvoiceModal(false);
                  }}
                  className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 font-bold shadow-lg shadow-emerald-200 transition-all"
                >
                  {selectedInvoice ? "تحديث الفاتورة" : "إنشاء وتأكيد الفاتورة"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Purchase Request Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">
                إنشاء طلب شراء
              </h2>
              <button
                onClick={() => setShowRequestModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <form
              onSubmit={handleCreateRequest}
              className="flex-1 overflow-y-auto"
            >
              <div className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      الجهة الطالبة
                    </label>
                    <input
                      type="text"
                      value={requestFormData.requested_by}
                      onChange={(e) =>
                        setRequestFormData({
                          ...requestFormData,
                          requested_by: e.target.value,
                        })
                      }
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                      placeholder="مثال: مدير المخزن، قسم المطبخ..."
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">
                      ملاحظات (اختياري)
                    </label>
                    <input
                      type="text"
                      value={requestFormData.notes}
                      onChange={(e) =>
                        setRequestFormData({
                          ...requestFormData,
                          notes: e.target.value,
                        })
                      }
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                {/* Items Selection */}
                <div className="border border-slate-200 rounded-xl">
                  <div className="bg-slate-50 p-4 border-b border-slate-200">
                    <h3 className="font-bold text-slate-800">
                      الأصناف المطلوبة
                    </h3>
                  </div>
                  <div className="p-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="md:col-span-4">
                        <SearchableSelect
                          options={ingredients.map((ing) => ({
                            id: ing.id,
                            label: ing.name,
                            item_code: ing.item_code || "-",
                            unit: ing.unit,
                            cost: ing.cost,
                          }))}
                          value=""
                          onChange={(value) => {
                            if (value) {
                              const ing = ingredients.find(
                                (i) => i.id.toString() === value.toString(),
                              );
                              if (
                                ing &&
                                !purchaseItems.find(
                                  (i) =>
                                    i.ingredient_id?.toString() ===
                                    ing.id.toString(),
                                )
                              ) {
                                setPurchaseItems([
                                  ...purchaseItems,
                                  {
                                    ingredient_id: ing.id,
                                    name: ing.name,
                                    unit: ing.unit,
                                    quantity: 1,
                                    unit_price: ing.cost || 0,
                                  },
                                ]);
                              }
                            }
                          }}
                          placeholder="إضافة صنف (ابحث بالاسم أو الباركود)..."
                          searchKeys={["label", "item_code"]}
                          labelKey="label"
                          columns={[
                            { key: "item_code", title: "كود / باركود" },
                            { key: "label", title: "الاسم" },
                            { key: "unit", title: "الوحدة" },
                          ]}
                        />
                      </div>
                    </div>

                    {purchaseItems.length > 0 && (
                      <table className="w-full text-right text-sm">
                        <thead className="text-slate-500 border-b border-slate-100">
                          <tr>
                            <th className="pb-2 font-bold">الصنف</th>
                            <th className="pb-2 font-bold">الكمية المطلوبة</th>
                            <th className="pb-2 font-bold">الوحدة</th>
                            <th className="pb-2 font-bold"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          {purchaseItems.map((item, idx) => (
                            <tr key={idx}>
                              <td className="py-2 text-slate-800 font-bold w-1/3">
                                {item.name}
                              </td>
                              <td className="py-2 w-24">
                                <input
                                  type="number"
                                  min="1"
                                  step="any"
                                  value={item.quantity || ""}
                                  onChange={(e) => {
                                    const newItems = [...purchaseItems];
                                    newItems[idx].quantity =
                                      parseFloat(e.target.value) || 0;
                                    setPurchaseItems(newItems);
                                  }}
                                  className="w-20 p-2 bg-slate-50 border border-slate-200 rounded-lg text-center outline-none"
                                />
                              </td>
                              <td className="py-2 text-slate-500">
                                {item.unit}
                              </td>
                              <td className="py-2 text-left">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setPurchaseItems(
                                      purchaseItems.filter((_, i) => i !== idx),
                                    )
                                  }
                                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowRequestModal(false)}
                  className="px-6 py-2.5 text-slate-600 font-bold hover:bg-slate-200 rounded-xl transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={purchaseItems.length === 0}
                  className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 font-bold disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-emerald-200 transition-all"
                >
                  إنشاء طلب الشراء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quotation Modal */}
      {showQuotationModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl p-6 shadow-xl flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="text-xl font-bold text-slate-800">
                تسجيل عرض سعر جديد (RFQ)
              </h2>
              <button
                onClick={() => setShowQuotationModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateQuotation} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    رقم عرض السعر
                  </label>
                  <input
                    type="text"
                    value={quotationFormData.quotation_number}
                    onChange={(e) =>
                      setQuotationFormData({
                        ...quotationFormData,
                        quotation_number: e.target.value,
                      })
                    }
                    placeholder="تلقائي (مثال: RFQ-12345)"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    المورد *
                  </label>
                  <select
                    required
                    value={quotationFormData.supplier_id}
                    onChange={(e) =>
                      setQuotationFormData({
                        ...quotationFormData,
                        supplier_id: e.target.value,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm font-medium"
                  >
                    <option value="">-- اختر المورد --</option>
                    {suppliers.map((sup: any) => (
                      <option key={sup.id} value={sup.id}>
                        {sup.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    مرتبط بطلب شراء (اختياري)
                  </label>
                  <select
                    value={quotationFormData.request_id}
                    onChange={(e) =>
                      setQuotationFormData({
                        ...quotationFormData,
                        request_id: e.target.value,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm font-medium"
                  >
                    <option value="">-- غير مرتبط بطلب --</option>
                    {requests.map((req: any) => (
                      <option key={req.id} value={req.id}>
                        طلب رقم #{req.id} ({req.requested_by || "مستخدم"})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    تاريخ التوريد المتوقع
                  </label>
                  <input
                    type="date"
                    value={quotationFormData.delivery_date}
                    onChange={(e) =>
                      setQuotationFormData({
                        ...quotationFormData,
                        delivery_date: e.target.value,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm"
                  />
                </div>
              </div>

              {/* Items Section */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 space-y-3">
                <h3 className="font-bold text-slate-800 text-sm flex items-center justify-between">
                  <span>جدول أصناف عرض السعر</span>
                  <span className="text-xs text-slate-500 font-normal">
                    إجمالي الاصناف: {quotationItems.length}
                  </span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-2 items-end">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-600 mb-1">
                      اختيار الصنف
                    </label>
                    <select
                      value={quotationItemInput.ingredient_id}
                      onChange={(e) => {
                        const ing = ingredients.find((i: any) => String(i.id) === e.target.value);
                        setQuotationItemInput({
                          ...quotationItemInput,
                          ingredient_id: e.target.value,
                          name: ing ? ing.name : "",
                          unit: ing ? ing.unit || "كيلو" : "كيلو",
                          unit_price: ing ? String(ing.cost || ing.price || 0) : "0",
                        });
                      }}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-medium outline-none"
                    >
                      <option value="">-- اختر صنف/مكون --</option>
                      {ingredients.map((ing: any) => (
                        <option key={ing.id} value={ing.id}>
                          {ing.name} ({ing.unit || "وحدة"})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">
                      الكمية
                    </label>
                    <input
                      type="number"
                      step="any"
                      min="0.01"
                      value={quotationItemInput.quantity}
                      onChange={(e) =>
                        setQuotationItemInput({
                          ...quotationItemInput,
                          quantity: e.target.value,
                        })
                      }
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-center"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">
                      السعر (ج.م)
                    </label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={quotationItemInput.unit_price}
                      onChange={(e) =>
                        setQuotationItemInput({
                          ...quotationItemInput,
                          unit_price: e.target.value,
                        })
                      }
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-center"
                    />
                  </div>

                  <div>
                    <button
                      type="button"
                      onClick={() => {
                        if (!quotationItemInput.name) return;
                        setQuotationItems([
                          ...quotationItems,
                          {
                            ingredient_id: quotationItemInput.ingredient_id,
                            name: quotationItemInput.name,
                            unit: quotationItemInput.unit,
                            quantity: Number(quotationItemInput.quantity) || 1,
                            unit_price: Number(quotationItemInput.unit_price) || 0,
                            total_price: (Number(quotationItemInput.quantity) || 1) * (Number(quotationItemInput.unit_price) || 0),
                          },
                        ]);
                        setQuotationItemInput({
                          ingredient_id: "",
                          name: "",
                          unit: "كيلو",
                          quantity: "1",
                          unit_price: "0",
                        });
                      }}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-colors"
                    >
                      + إضافة
                    </button>
                  </div>
                </div>

                {quotationItems.length > 0 && (
                  <div className="bg-white rounded-xl border border-slate-200 overflow-hidden mt-3">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-100 text-slate-700">
                        <tr>
                          <th className="p-2 font-bold">الصنف</th>
                          <th className="p-2 font-bold">الكمية</th>
                          <th className="p-2 font-bold">السعر</th>
                          <th className="p-2 font-bold">الإجمالي</th>
                          <th className="p-2 font-bold text-center">حذف</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {quotationItems.map((item, idx) => (
                          <tr key={idx}>
                            <td className="p-2 font-semibold text-slate-800">
                              {item.name}
                            </td>
                            <td className="p-2 text-slate-600">
                              {item.quantity} {item.unit}
                            </td>
                            <td className="p-2 text-slate-600 font-mono">
                              {Number(item.unit_price || 0).toLocaleString()} ج.م
                            </td>
                            <td className="p-2 font-bold text-emerald-600 font-mono">
                              {(Number(item.quantity) * Number(item.unit_price)).toLocaleString()} ج.م
                            </td>
                            <td className="p-2 text-center">
                              <button
                                type="button"
                                onClick={() =>
                                  setQuotationItems(
                                    quotationItems.filter((_, i) => i !== idx)
                                  )
                                }
                                className="text-rose-500 hover:text-rose-700 p-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                <div className="flex justify-between items-center pt-2 font-bold text-sm text-slate-800">
                  <span>إجمالي قيمة عرض السعر:</span>
                  <span className="text-emerald-600 font-mono text-base">
                    {quotationItems
                      .reduce(
                        (acc, item) =>
                          acc + (Number(item.quantity) * Number(item.unit_price) || 0),
                        0
                      )
                      .toLocaleString()}{" "}
                    ج.م
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">
                  ملاحظات وشروط التوريد
                </label>
                <textarea
                  rows={2}
                  value={quotationFormData.notes}
                  onChange={(e) =>
                    setQuotationFormData({
                      ...quotationFormData,
                      notes: e.target.value,
                    })
                  }
                  placeholder="شروط الدفع والتسليم، مدة صلاحية العرض، أية ملاحظات إضافية..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowQuotationModal(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold transition-colors text-sm"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold transition-colors text-sm shadow-sm"
                >
                  حفظ عرض السعر
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-xl p-6 shadow-xl flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="text-xl font-bold text-slate-800">
                تسجيل مصروف مشتريات جديد
              </h2>
              <button
                onClick={() => setShowExpenseModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    رقم السند / الفاتورة
                  </label>
                  <input
                    type="text"
                    value={expenseFormData.voucher_no}
                    onChange={(e) =>
                      setExpenseFormData({
                        ...expenseFormData,
                        voucher_no: e.target.value,
                      })
                    }
                    placeholder="تلقائي إن تُرك فارغاً"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    المبلغ (ج.م) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={expenseFormData.amount}
                    onChange={(e) =>
                      setExpenseFormData({
                        ...expenseFormData,
                        amount: e.target.value,
                      })
                    }
                    placeholder="0.00"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    المورد / الجهة
                  </label>
                  <select
                    value={expenseFormData.supplier_id}
                    onChange={(e) =>
                      setExpenseFormData({
                        ...expenseFormData,
                        supplier_id: e.target.value,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm font-medium"
                  >
                    <option value="">-- اختر المورد (اختياري) --</option>
                    {suppliers.map((sup: any) => (
                      <option key={sup.id} value={sup.id}>
                        {sup.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    مركز التكلفة
                  </label>
                  <select
                    value={expenseFormData.cost_center_id}
                    onChange={(e) =>
                      setExpenseFormData({
                        ...expenseFormData,
                        cost_center_id: e.target.value,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm font-medium"
                  >
                    <option value="">-- اختر مركز التكلفة --</option>
                    {costCenters.map((cc: any) => (
                      <option key={cc.id} value={cc.id}>
                        {cc.name} ({cc.branch || "عام"})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    بند المصروف
                  </label>
                  <select
                    value={expenseFormData.cost_item_id}
                    onChange={(e) =>
                      setExpenseFormData({
                        ...expenseFormData,
                        cost_item_id: e.target.value,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm font-medium"
                  >
                    <option value="">-- اختر بند المصروف --</option>
                    {costItems.map((ci: any) => (
                      <option key={ci.id} value={ci.id}>
                        {ci.name} ({ci.cost_type || "تشغيل"})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">
                    طريقة الدفع
                  </label>
                  <select
                    value={expenseFormData.payment_method}
                    onChange={(e) =>
                      setExpenseFormData({
                        ...expenseFormData,
                        payment_method: e.target.value,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm font-medium"
                  >
                    <option value="نقدي">نقدي (كاش)</option>
                    <option value="تحويل بنكي">تحويل بنكي</option>
                    <option value="شيك">شيك بنكي</option>
                    <option value="آجل">آجل / على الحساب</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">
                  الخزينة / الحساب البنكي
                </label>
                <input
                  type="text"
                  value={expenseFormData.safe}
                  onChange={(e) =>
                    setExpenseFormData({
                      ...expenseFormData,
                      safe: e.target.value,
                    })
                  }
                  placeholder="اسم الخزينة أو البنك"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">
                  ملاحظات / وصف المصروف
                </label>
                <textarea
                  rows={2}
                  value={expenseFormData.notes}
                  onChange={(e) =>
                    setExpenseFormData({
                      ...expenseFormData,
                      notes: e.target.value,
                    })
                  }
                  placeholder="أدخل أي تفاصيل إضافية عن المصروف..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 text-sm"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowExpenseModal(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold transition-colors text-sm"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold transition-colors text-sm shadow-sm"
                >
                  حفظ المصروف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <InvoiceOCRModal
        isOpen={isOcrModalOpen}
        onClose={() => setIsOcrModalOpen(false)}
        onJournalPosted={() => {
          fetchPurchases();
        }}
      />
    </div>
  );
}
