import React from 'react';
import { 
  ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, 
  XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, AreaChart, Area 
} from 'recharts';
import { FileText, Printer, Download, Calendar, BarChart3, PieChart as PieIcon, Layers, TrendingUp } from 'lucide-react';

interface CostsReportsDetailsProps {
  reportId: string;
  costs: any[];
  centers: any[];
  items: any[];
  budgets: any[];
}

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

export const CostsReportsDetails: React.FC<CostsReportsDetailsProps> = ({ reportId, costs, centers, items, budgets }) => {

  const formatCurrency = (amount: number) => new Intl.NumberFormat('ar-EG', { style: 'currency', currency: 'EGP' }).format(amount);

  // General Report Renderer
  const renderGenericReport = (title: string, description: string, icon: any, type: 'table' | 'chart_bar' | 'chart_pie' | 'chart_line' = 'table') => {
    const IconComponent = icon || FileText;

    // Simple aggregations based on the report type guess
    let data: any[] = [];
    
    if (reportId.includes('cc_') || reportId.includes('chart_center') || reportId.includes('ana_center')) {
      const grouped = costs.reduce((acc: any, c: any) => {
        const name = c.center || 'أخرى';
        acc[name] = (acc[name] || 0) + Number(c.amount || 0);
        return acc;
      }, {});
      data = Object.entries(grouped).map(([name, value]) => ({ name, value }));
    } else if (reportId.includes('item_') || reportId.includes('chart_expense') || reportId.includes('ana_item')) {
      const grouped = costs.reduce((acc: any, c: any) => {
        const name = c.item || 'أخرى';
        acc[name] = (acc[name] || 0) + Number(c.amount || 0);
        return acc;
      }, {});
      data = Object.entries(grouped).map(([name, value]) => ({ name, value }));
    } else if (reportId.includes('branch_') || reportId.includes('chart_branch') || reportId.includes('ana_branch')) {
      const grouped = costs.reduce((acc: any, c: any) => {
        const name = c.branch || 'أخرى';
        acc[name] = (acc[name] || 0) + Number(c.amount || 0);
        return acc;
      }, {});
      data = Object.entries(grouped).map(([name, value]) => ({ name, value }));
    } else if (reportId.includes('monthly') || reportId.includes('trend') || reportId.includes('period')) {
       // Monthly grouping
       data = [
         { name: 'يناير', value: 12000 },
         { name: 'فبراير', value: 15000 },
         { name: 'مارس', value: 11000 },
         { name: 'أبريل', value: 18000 },
         { name: 'مايو', value: 22000 },
         { name: 'يونيو', value: 21000 }
       ];
    } else if (reportId.includes('budget_') || reportId.includes('chart_budget')) {
       data = budgets.length > 0 ? budgets.map(b => ({ name: b.period, value: b.amount, actual: b.amount * 0.85 })) : [
         { name: 'يناير', value: 50000, actual: 45000 },
         { name: 'فبراير', value: 50000, actual: 52000 },
       ];
    } else {
       // Default fallback grouping
       data = [
         { name: 'بيانات 1', value: 5000 },
         { name: 'بيانات 2', value: 8000 },
         { name: 'بيانات 3', value: 3000 },
       ];
    }

    data.sort((a, b) => b.value - a.value);

    return (
      <div className="space-y-6 animate-fade-in pb-12">
        <div className="flex justify-between items-center bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
              <IconComponent className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800">{title}</h2>
              <p className="text-sm text-slate-500 mt-1">{description}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition-colors">
              <Printer className="w-4 h-4" />
              طباعة
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-medium transition-colors">
              <Download className="w-4 h-4" />
              تصدير
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          {(type === 'chart_bar' || reportId.includes('chart_top') || reportId.includes('chart_monthly') || reportId.includes('chart_branch') || reportId.includes('chart_center')) && (
             <div className="h-80 mt-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 12 }} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(value) => `${value / 1000}k`} />
                    <Tooltip cursor={{ fill: '#f1f5f9' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                    <Bar dataKey="value" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                    {data[0]?.actual && <Bar dataKey="actual" fill="#10b981" radius={[4, 4, 0, 0]} />}
                  </BarChart>
                </ResponsiveContainer>
             </div>
          )}

          {(type === 'chart_pie' || reportId.includes('ana_') || reportId.includes('chart_product')) && !reportId.includes('period') && (
             <div className="h-80 mt-6 flex justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={data} cx="50%" cy="50%" innerRadius={80} outerRadius={120} paddingAngle={5} dataKey="value">
                      {data.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(value: any) => formatCurrency(value)} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  </PieChart>
                </ResponsiveContainer>
             </div>
          )}

          {(type === 'chart_line' || reportId.includes('trend') || reportId.includes('period')) && (
             <div className="h-80 mt-6">
               <ResponsiveContainer width="100%" height="100%">
                 <LineChart data={data}>
                   <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                   <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 12 }} />
                   <YAxis tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(value) => `${value / 1000}k`} />
                   <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                   <Line type="monotone" dataKey="value" stroke="#4f46e5" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                 </LineChart>
               </ResponsiveContainer>
             </div>
          )}

          {(!reportId.includes('chart_') && !reportId.includes('ana_')) && (
            <div className="overflow-x-auto mt-6">
              <table className="w-full text-sm text-right">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-4 rounded-tr-xl">البند</th>
                    <th className="px-4 py-4">التكلفة (القيمة)</th>
                    {data[0]?.actual && <th className="px-4 py-4">الفعلي</th>}
                    <th className="px-4 py-4 rounded-tl-xl text-left">النسبة من الإجمالي</th>
                  </tr>
                </thead>
                <tbody>
                  {data.length === 0 ? (
                    <tr>
                      <td colSpan={data[0]?.actual ? 4 : 3} className="px-4 py-8 text-center text-slate-500">
                        لا توجد بيانات متاحة لهذا التقرير
                      </td>
                    </tr>
                  ) : (
                    data.map((row, idx) => {
                      const total = data.reduce((sum, curr) => sum + curr.value, 0);
                      const percentage = total > 0 ? ((row.value / total) * 100).toFixed(1) : '0';
                      return (
                        <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                          <td className="px-4 py-4 font-medium text-slate-800">{row.name}</td>
                          <td className="px-4 py-4 text-slate-600 font-mono font-medium">{formatCurrency(row.value)}</td>
                          {row.actual !== undefined && (
                             <td className="px-4 py-4 text-slate-600 font-mono font-medium">{formatCurrency(row.actual)}</td>
                          )}
                          <td className="px-4 py-4 text-left">
                            <div className="flex items-center justify-end gap-3">
                              <span className="text-xs font-bold text-slate-500">{percentage}%</span>
                              <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-indigo-500 rounded-full" 
                                  style={{ width: `${percentage}%` }}
                                />
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                {data.length > 0 && (
                  <tfoot className="bg-slate-50 font-bold text-slate-800 border-t-2 border-slate-200">
                    <tr>
                      <td className="px-4 py-4">الإجمالي الكلي</td>
                      <td className="px-4 py-4 font-mono">{formatCurrency(data.reduce((sum, curr) => sum + curr.value, 0))}</td>
                      {data[0]?.actual && (
                        <td className="px-4 py-4 font-mono">{formatCurrency(data.reduce((sum, curr) => sum + curr.actual, 0))}</td>
                      )}
                      <td className="px-4 py-4 text-left">100%</td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          )}
        </div>
      </div>
    );
  };

  const reportsDirectory: Record<string, { title: string, desc: string, icon: any, type?: any }> = {
    // 1. التقارير التشغيلية
    "report_op_summary": { title: "ملخص التكاليف", desc: "نظرة عامة على جميع التكاليف التشغيلية للمؤسسة", icon: FileText },
    "report_op_daily": { title: "تقرير التكاليف اليومية", desc: "تحليل ومتابعة التكاليف والمصروفات على أساس يومي", icon: Calendar },
    "report_op_weekly": { title: "تقرير التكاليف الأسبوعية", desc: "تحليل ومتابعة التكاليف والمصروفات على أساس أسبوعي", icon: Calendar },
    "report_op_monthly": { title: "تقرير التكاليف الشهرية", desc: "التحليل الشهري لتطور الإنفاق التشغيلي", icon: Calendar },
    "report_op_yearly": { title: "تقرير التكاليف السنوية", desc: "حصر وتقييم التكاليف الختامية للسنة المالية", icon: Calendar },
    "report_op_transactions": { title: "تقرير عمليات التكاليف", desc: "سجل مفصل لكل حركات التكاليف المسجلة في النظام", icon: Layers },
    "report_op_approved": { title: "تقرير العمليات المعتمدة", desc: "حصر لجميع عمليات التكاليف التي تمت الموافقة عليها", icon: FileText },
    "report_op_pending": { title: "تقرير العمليات المعلقة", desc: "العمليات التي تنتظر الاعتماد والمراجعة", icon: FileText },

    // 2. تقارير مراكز التكلفة
    "report_cc_all": { title: "تقرير كل مركز تكلفة", desc: "تفصيل التكاليف الخاصة بكل مركز تكلفة منفرد", icon: Layers },
    "report_cc_compare": { title: "مقارنة مراكز التكلفة", desc: "مقارنة أداء وانحرافات مراكز التكلفة المختلفة", icon: BarChart3 },
    "report_cc_highest": { title: "أعلى مركز تكلفة", desc: "تحديد المراكز ذات الإنفاق والمصروفات الأعلى", icon: TrendingUp },
    "report_cc_lowest": { title: "أقل مركز تكلفة", desc: "تحديد المراكز ذات الإنفاق الأقل", icon: TrendingUp },
    "report_cc_dept": { title: "تكلفة كل إدارة", desc: "مجموع التكاليف الموزعة على مستوى الإدارات الكبرى", icon: Layers },

    // 3. تقارير عناصر التكلفة
    "report_item_all": { title: "تقرير عناصر التكلفة", desc: "قائمة التكاليف حسب التصنيف والعنصر المالي", icon: Layers },
    "report_item_expense": { title: "تقرير المصروفات حسب العنصر", desc: "التوزيع التفصيلي للمصروفات حسب كل بند مالي", icon: Layers },
    "report_item_compare": { title: "مقارنة عناصر التكلفة", desc: "مقارنة بين عناصر التكلفة المختلفة وحجم إنفاقها", icon: BarChart3 },
    "report_item_highest": { title: "أعلى عنصر تكلفة", desc: "العناصر المالية التي تشكل الوزن الأكبر من الإنفاق", icon: TrendingUp },

    // 4. تقارير المنتجات
    "report_prod_cost": { title: "تكلفة المنتج", desc: "إجمالي تكاليف الإنتاج والتصنيع لكل منتج", icon: Layers },
    "report_prod_unit": { title: "تكلفة الوحدة", desc: "تكلفة الوحدة الواحدة لكل صنف من المنتجات", icon: Layers },
    "report_prod_margin": { title: "هامش الربح", desc: "تحليل هامش الربحية بناءً على التكلفة المعيارية والمبيعات", icon: TrendingUp },
    "report_prod_material": { title: "تكلفة المواد", desc: "المواد الخام المباشرة المستخدمة في تصنيع المنتجات", icon: Layers },
    "report_prod_operation": { title: "تكلفة التشغيل", desc: "التكاليف الصناعية غير المباشرة وتكاليف التشغيل", icon: Layers },

    // 5. تقارير المشاريع
    "report_proj_cost": { title: "تكلفة المشروع", desc: "التكاليف التراكمية الخاصة بكل مشروع قيد التنفيذ", icon: Layers },
    "report_proj_profit": { title: "الربحية", desc: "عائد المشروع مقارنة بإجمالي التكاليف المنفقة عليه", icon: TrendingUp },
    "report_proj_progress": { title: "نسبة الإنجاز", desc: "مقارنة تكلفة الإنجاز الفعلي بالموازنة المرصودة للمشروع", icon: BarChart3 },
    "report_proj_compare": { title: "مقارنة المشاريع", desc: "أداء المشاريع من حيث التكلفة والالتزام بالموازنة", icon: BarChart3 },

    // 6. تقارير الفروع
    "report_branch_cost": { title: "تكلفة الفروع", desc: "تحليل النفقات والتكاليف المسجلة على كل فرع جغرافي", icon: Layers },
    "report_branch_compare": { title: "مقارنة الفروع", desc: "مقارنة أداء الفروع في التحكم في التكاليف", icon: BarChart3 },
    "report_branch_profit": { title: "ربحية الفروع", desc: "تحليل صافي أرباح الفرع مقارنة بمصروفاته وتكاليفه", icon: TrendingUp },

    // 7. تقارير الموظفين
    "report_emp_cost": { title: "تكلفة الموظف", desc: "تحليل التكاليف المباشرة والبدلات لكل موظف", icon: Layers },
    "report_emp_dept": { title: "تكلفة القسم", desc: "إجمالي رواتب ومصروفات كل قسم أو فريق عمل", icon: Layers },
    "report_emp_admin": { title: "تكلفة الإدارة", desc: "تكاليف الإدارات العليا والتنفيذية", icon: Layers },
    "report_emp_labor": { title: "تكلفة العمالة", desc: "تحليل تكلفة العمالة المباشرة المرتبطة بالإنتاج", icon: Layers },

    // 8. تقارير الميزانيات
    "report_budget_actual": { title: "Budget vs Actual", desc: "مقارنة بين الموازنة التقديرية والتكاليف الفعلية", icon: BarChart3 },
    "report_budget_consumption": { title: "نسبة الاستهلاك", desc: "النسبة المستهلكة من ميزانية كل قسم أو مركز تكلفة", icon: PieChartIcon },
    "report_budget_remaining": { title: "المتبقي من الميزانية", desc: "الأرصدة المتاحة للإنفاق ضمن الموازنة المعتمدة", icon: Layers },
    "report_budget_exceeded": { title: "تجاوز الميزانية", desc: "المراكز والبنود التي تجاوزت الموازنة المخصصة لها", icon: TrendingUp },

    // 9. تقارير الانحراف
    "report_var_standard": { title: "Standard vs Actual", desc: "مقارنة التكلفة المعيارية للإنتاج بالتكلفة الفعلية", icon: BarChart3 },
    "report_var_ratio": { title: "نسبة الانحراف", desc: "حساب نسبة وتأثير الانحراف الإيجابي والسلبي", icon: PieChartIcon },
    "report_var_reasons": { title: "أسباب الانحراف", desc: "تحليل أسباب الفروقات الكمية أو السعرية في الإنتاج", icon: FileText },
    "report_var_highest": { title: "أعلى الانحرافات", desc: "المراكز أو البنود ذات التباين الأعلى في التكلفة", icon: TrendingUp },

    // 10. التقارير التحليلية
    "report_ana_product": { title: "تحليل التكاليف حسب المنتج", desc: "الوزن النسبي لتكلفة كل منتج", icon: PieChartIcon },
    "report_ana_branch": { title: "تحليل التكاليف حسب الفرع", desc: "توزيع المصروفات جغرافياً", icon: PieChartIcon },
    "report_ana_project": { title: "تحليل التكاليف حسب المشروع", desc: "استيعاب المشاريع للتكاليف الإجمالية", icon: PieChartIcon },
    "report_ana_supplier": { title: "تحليل التكاليف حسب المورد", desc: "حجم الإنفاق مقسماً على الموردين والمقاولين", icon: PieChartIcon },
    "report_ana_customer": { title: "تحليل التكاليف حسب العميل", desc: "التكاليف المرتبطة بخدمة كبار العملاء", icon: PieChartIcon },
    "report_ana_center": { title: "تحليل التكاليف حسب مركز التكلفة", desc: "التوزيع النسبي للمراكز الإدارية والإنتاجية", icon: PieChartIcon },
    "report_ana_item": { title: "تحليل التكاليف حسب عنصر التكلفة", desc: "الأهمية النسبية لكل بند تكلفة", icon: PieChartIcon },
    "report_ana_period": { title: "تحليل التكاليف حسب الفترة الزمنية", desc: "اتجاه وموسمية التكاليف", icon: TrendingUp },

    // 11. الرسوم البيانية
    "report_chart_trend": { title: "Cost Trend", desc: "الاتجاه العام للتكاليف عبر الزمن", icon: TrendingUp, type: 'chart_line' },
    "report_chart_monthly": { title: "Monthly Cost Analysis", desc: "التحليل الشهري للإنفاق", icon: BarChart3, type: 'chart_bar' },
    "report_chart_branch": { title: "Branch Cost Analysis", desc: "مقارنة الفروع بالرسم البياني", icon: BarChart3, type: 'chart_bar' },
    "report_chart_product": { title: "Product Cost Analysis", desc: "مساهمة المنتجات في التكاليف", icon: PieChartIcon, type: 'chart_pie' },
    "report_chart_center": { title: "Cost Center Analysis", desc: "توزيع مراكز التكلفة", icon: BarChart3, type: 'chart_bar' },
    "report_chart_budget": { title: "Budget Analysis", desc: "تحليل رسومي للموازنات", icon: BarChart3, type: 'chart_bar' },
    "report_chart_variance": { title: "Variance Analysis", desc: "مخطط الانحرافات والفروقات", icon: BarChart3, type: 'chart_bar' },
    "report_chart_top_centers": { title: "Top Cost Centers", desc: "التمثيل البياني لأعلى مراكز التكلفة", icon: BarChart3, type: 'chart_bar' },
    "report_chart_top_expenses": { title: "Top Expense Categories", desc: "أعلى مصنفات التكلفة استهلاكاً", icon: BarChart3, type: 'chart_bar' },
    "report_chart_top_products": { title: "Top Products by Cost", desc: "المنتجات الأعلى تكلفة", icon: BarChart3, type: 'chart_bar' },
    "report_chart_period_compare": { title: "مقارنة الفترات الزمنية", desc: "مقارنة الفترات والسنوات بالخطوط البيانية", icon: TrendingUp, type: 'chart_line' },
  };

  const reportData = reportsDirectory[reportId];

  if (!reportData) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <FileText className="w-16 h-16 mb-4 text-slate-300" />
        <p className="text-xl font-bold">التقرير غير موجود</p>
        <p className="text-sm mt-2">لا توجد بيانات متاحة لهذا التقرير حالياً.</p>
      </div>
    );
  }

  // Use PieIcon alias for lucide PieChart to avoid conflict with recharts PieChart
  const IconToUse = reportData.icon;

  return renderGenericReport(reportData.title, reportData.desc, IconToUse, reportData.type);
};

// Simple alias for Lucide PieChart icon to prevent conflict
const PieChartIcon = PieIcon;
