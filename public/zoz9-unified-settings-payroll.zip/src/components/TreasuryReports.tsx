import React, { useState } from "react";
import { motion } from "motion/react";
import {
  ChevronLeft,
  Download,
  Printer,
  Filter,
  Search,
  Wallet,
  Landmark,
  Coins,
  History,
  Calendar,
  RefreshCcw,
  FileText,
  ShieldCheck,
  Users,
  ArrowRightLeft,
} from "lucide-react";
import useSWR from "swr";
import { fetcher } from "../utils/fetcher";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface TreasuryReportsProps {
  onBack: () => void;
  initialTab?: "detailed" | "closings" | "custodies" | "transfers";
}

const safeFormat = (dateVal: any, formatStr: string, options?: any) => {
  if (!dateVal) return "---";
  const d = new Date(dateVal);
  if (isNaN(d.getTime())) return "---";
  try {
    return format(d, formatStr, options);
  } catch (err) {
    return "---";
  }
};

export const TreasuryReports: React.FC<TreasuryReportsProps> = ({ onBack, initialTab }) => {
  const [activeReportType, setActiveReportType] = useState<"detailed" | "closings" | "custodies" | "transfers">(initialTab || "detailed");

  React.useEffect(() => {
    if (initialTab) {
      setActiveReportType(initialTab);
    }
  }, [initialTab]);
  const [startDate, setStartDate] = useState(
    new Date().toISOString().split("T")[0],
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split("T")[0],
  );
  const [selectedAccountId, setSelectedAccountId] = useState<string>("all");
  const [selectedType, setSelectedType] = useState<string>("all");

  const { data: accountsRaw } = useSWR("/api/treasury/accounts", fetcher);
  const accounts: any[] = Array.isArray(accountsRaw) ? accountsRaw : [];

  // 1. Detailed and Transfers Reports Fetching
  const reportUrl = `/api/treasury/reports/detailed?accountId=${selectedAccountId === "all" ? "" : selectedAccountId}&startDate=${startDate}T00:00:00Z&endDate=${endDate}T23:59:59Z&transactionType=${activeReportType === "transfers" ? "transfer" : selectedType}`;
  const { data: reportDataRaw, isLoading: isDetailedLoading, mutate: mutateDetailed } = useSWR(
    (activeReportType === "detailed" || activeReportType === "transfers") ? reportUrl : null,
    fetcher
  );
  const reportData: any[] = Array.isArray(reportDataRaw) ? reportDataRaw : [];

  // 2. Closings Report Fetching
  const { data: closingsRaw, isLoading: isClosingsLoading, mutate: mutateClosings } = useSWR(
    activeReportType === "closings" ? "/api/treasury/closings" : null,
    fetcher
  );

  // 3. Custodies Report Fetching
  const { data: custodiesRaw, isLoading: isCustodiesLoading, mutate: mutateCustodies } = useSWR(
    activeReportType === "custodies" ? "/api/treasury/custodies" : null,
    fetcher
  );

  const getFilteredData = () => {
    if (activeReportType === "detailed") {
      return reportData;
    }
    if (activeReportType === "transfers") {
      return reportData.filter((t) => t.transaction_type === "transfer");
    }
    if (activeReportType === "closings") {
      const list = Array.isArray(closingsRaw) ? closingsRaw : [];
      return list.filter((item: any) => {
        const itemDate = item.closing_date ? item.closing_date.split("T")[0] : item.created_at.split("T")[0];
        const inDateRange = itemDate >= startDate && itemDate <= endDate;
        const matchesAccount = selectedAccountId === "all" || String(item.account_id) === String(selectedAccountId);
        return inDateRange && matchesAccount;
      });
    }
    if (activeReportType === "custodies") {
      const list = Array.isArray(custodiesRaw) ? custodiesRaw : [];
      return list.filter((item: any) => {
        const itemDate = item.created_at.split("T")[0];
        const inDateRange = itemDate >= startDate && itemDate <= endDate;
        const matchesAccount = selectedAccountId === "all" || String(item.account_id) === String(selectedAccountId);
        return inDateRange && matchesAccount;
      });
    }
    return [];
  };

  const filteredData = getFilteredData();
  const isLoading =
    activeReportType === "detailed" || activeReportType === "transfers"
      ? isDetailedLoading
      : activeReportType === "closings"
        ? isClosingsLoading
        : isCustodiesLoading;

  const handlePrint = () => {
    window.print();
  };

  const handleExport = () => {
    let headers: string[] = [];
    let rows: any[][] = [];
    let filename = "";

    if (activeReportType === "detailed" || activeReportType === "transfers") {
      headers = ["التاريخ", "الخزينة", "النوع", "القيمة", "المستخدم", "الملاحظات"];
      rows = filteredData.map((t) => [
        safeFormat(t.created_at, "yyyy-MM-dd HH:mm", { locale: ar }),
        t.account_name,
        t.transaction_type === "cash_in"
          ? "إيداع"
          : t.transaction_type === "cash_out"
            ? "صرف"
            : t.transaction_type === "transfer"
              ? "تحويل"
              : "تعديل",
        t.amount,
        t.user_name,
        t.notes || "",
      ]);
      filename = `تقرير_${activeReportType === "detailed" ? "حركة_الخزينة" : "التحويلات_البينية"}_${startDate}_إلى_${endDate}.csv`;
    } else if (activeReportType === "closings") {
      headers = [
        "التاريخ",
        "الحساب/الخزينة",
        "الرصيد الدفتري",
        "الرصيد الفعلي",
        "العجز والزيادة",
        "الحالة",
        "المسؤول",
        "المعتمد",
      ];
      rows = filteredData.map((c) => [
        safeFormat(c.closing_date || c.created_at, "yyyy-MM-dd", { locale: ar }),
        c.account_name,
        c.system_balance,
        c.actual_balance,
        c.difference,
        c.status === "approved" ? "معتمد" : "معلق",
        c.creator_name || "",
        c.approver_name || "---",
      ]);
      filename = `تقرير_تقفيلات_الخزينة_${startDate}_إلى_${endDate}.csv`;
    } else if (activeReportType === "custodies") {
      headers = [
        "التاريخ",
        "الموظف المستلم",
        "الخزينة/الحساب",
        "مبلغ العهدة",
        "المبلغ المسوى",
        "المبلغ المسترد",
        "الحالة",
      ];
      rows = filteredData.map((c) => [
        safeFormat(c.created_at, "yyyy-MM-dd", { locale: ar }),
        c.employee_name,
        c.account_name,
        c.amount,
        c.cleared_amount,
        c.returned_amount,
        c.status === "fully_cleared"
          ? "مسواة بالكامل"
          : c.status === "partially_cleared"
            ? "مسواة جزئياً"
            : "تحت التسوية",
      ]);
      filename = `تقرير_العهد_والأمانات_${startDate}_إلى_${endDate}.csv`;
    }

    const csvContent =
      "data:text/csv;charset=utf-8,\uFEFF" +
      [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "cash":
        return <Coins className="w-4 h-4" />;
      case "bank":
        return <Landmark className="w-4 h-4" />;
      case "petty_cash":
        return <Wallet className="w-4 h-4" />;
      default:
        return <History className="w-4 h-4" />;
    }
  };

  return (
    <div className="h-full flex flex-col font-cairo bg-slate-50 overflow-hidden">
      {/* Header - Hidden on Print */}
      <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 print:hidden shrink-0">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-xl transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-slate-500" />
          </button>
          <div className="flex flex-col">
            <h1 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <FileText className="w-6 h-6 text-indigo-600" />
              {activeReportType === "detailed" && "كشف حساب حركات الخزائن التفصيلي"}
              {activeReportType === "closings" && "تقرير التقفيلات والمطابقات اليومية"}
              {activeReportType === "custodies" && "تقرير حركة العهد والأمانات"}
              {activeReportType === "transfers" && "تقرير التحويلات المالية البينية"}
            </h1>
            <p className="text-xs text-slate-500 font-bold">
              تقارير الخزينة بمستوى الأنظمة الاحترافية المتكاملة
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl font-bold hover:bg-emerald-100 transition-all border border-emerald-100 text-sm"
          >
            <Download className="w-4 h-4" />
            تصدير CSV
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 text-sm"
          >
            <Printer className="w-4 h-4" />
            طباعة
          </button>
        </div>
      </div>

      {/* Report Type Selector Tabs - Hidden on Print */}
      <div className="bg-white border-b border-slate-200 px-6 flex print:hidden shrink-0 overflow-x-auto gap-1">
        <button
          onClick={() => setActiveReportType("detailed")}
          className={`px-4 py-3 border-b-2 font-bold text-sm transition-all whitespace-nowrap ${activeReportType === "detailed" ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-800"}`}
        >
          كشف حساب الحركة التفصيلي
        </button>
        <button
          onClick={() => setActiveReportType("closings")}
          className={`px-4 py-3 border-b-2 font-bold text-sm transition-all whitespace-nowrap ${activeReportType === "closings" ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-800"}`}
        >
          تقرير التقفيلات والمطابقات اليومية
        </button>
        <button
          onClick={() => setActiveReportType("custodies")}
          className={`px-4 py-3 border-b-2 font-bold text-sm transition-all whitespace-nowrap ${activeReportType === "custodies" ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-800"}`}
        >
          تقرير حركة العهد والأمانات
        </button>
        <button
          onClick={() => setActiveReportType("transfers")}
          className={`px-4 py-3 border-b-2 font-bold text-sm transition-all whitespace-nowrap ${activeReportType === "transfers" ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-800"}`}
        >
          تقرير التحويلات المالية البينية
        </button>
      </div>

      {/* Filters - Hidden on Print */}
      <div className="p-6 bg-white border-b border-slate-200 print:hidden shrink-0">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              تاريخ البداية
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all font-bold text-slate-700"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              تاريخ النهاية
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all font-bold text-slate-700"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Landmark className="w-3.5 h-3.5" />
              اختر الخزينة / الحساب
            </label>
            <select
              value={selectedAccountId}
              onChange={(e) => setSelectedAccountId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all font-bold text-slate-700"
            >
              <option value="all">جميع الخزائن</option>
              {accounts.map((acc) => (
                <option key={acc.id} value={acc.id}>
                  {acc.name}
                </option>
              ))}
            </select>
          </div>

          {(activeReportType === "detailed" || activeReportType === "transfers") && (
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5" />
                نوع الحركة
              </label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                disabled={activeReportType === "transfers"}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all font-bold text-slate-700 disabled:opacity-55"
              >
                {activeReportType === "transfers" ? (
                  <option value="transfer">تحويل</option>
                ) : (
                  <>
                    <option value="all">الكل</option>
                    <option value="cash_in">إيداع</option>
                    <option value="cash_out">صرف</option>
                    <option value="transfer">تحويل</option>
                    <option value="adjustment">تعديل</option>
                  </>
                )}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50 print:bg-white print:p-0">
        <div className="w-full bg-white border border-slate-200 rounded-[2rem] overflow-hidden shadow-sm print:border-none print:shadow-none print:rounded-none">
          {/* Print Header */}
          <div className="hidden print:block p-8 border-b-2 border-slate-900 border-dashed mb-6 text-center">
            <h1 className="text-3xl font-black mb-2">
              {activeReportType === "detailed" && "تقرير كشف حساب الخزينة التفصيلي"}
              {activeReportType === "closings" && "تقرير تقفيلات وتسويات الخزينة"}
              {activeReportType === "custodies" && "تقرير حركة العهد والأمانات"}
              {activeReportType === "transfers" && "تقرير التحويلات البينية للموجات النقدية"}
            </h1>
            <div className="flex justify-center gap-8 text-sm font-bold">
              <span>تاريخ الطباعة: {safeFormat(new Date(), "yyyy/MM/dd")}</span>
              <span>
                الفترة: من {startDate} إلى {endDate}
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            {activeReportType === "detailed" || activeReportType === "transfers" ? (
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      تاريخ الحركة
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">
                      الخزينة / الحساب
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      نوع الحركة
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">
                      الملاحظات
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">
                      المستخدم
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      القيمة
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {isLoading ? (
                    Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <tr key={i} className="animate-pulse">
                          <td colSpan={6} className="h-16 bg-slate-50/50"></td>
                        </tr>
                      ))
                  ) : filteredData.length === 0 ? (
                    <tr>
                      <td
                        colSpan={6}
                        className="px-6 py-12 text-center text-slate-400 font-bold italic"
                      >
                        لا توجد حركات مطابقة للفلترة المختارة
                      </td>
                    </tr>
                  ) : (
                    filteredData.map((t) => (
                      <tr
                        key={t.id}
                        className="hover:bg-slate-50/50 transition-colors"
                      >
                        <td className="px-6 py-4 whitespace-nowrap text-xs font-mono font-bold text-slate-600 text-center">
                          {safeFormat(t.created_at, "yyyy-MM-dd HH:mm", {
                            locale: ar,
                          })}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600">
                              {getTypeIcon(t.account_type)}
                            </div>
                            <span className="font-bold text-slate-900">
                              {t.account_name}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <span
                            className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tight ${
                              t.transaction_type === "cash_in"
                                ? "bg-emerald-50 text-emerald-600 border border-emerald-100"
                                : t.transaction_type === "cash_out"
                                  ? "bg-rose-50 text-rose-600 border border-rose-100"
                                  : t.transaction_type === "transfer"
                                    ? "bg-indigo-50 text-indigo-600 border border-indigo-100"
                                    : "bg-slate-50 text-slate-600 border border-slate-100"
                            }`}
                          >
                            {t.transaction_type === "cash_in"
                              ? "إيداع"
                              : t.transaction_type === "cash_out"
                                ? "صرف"
                                : t.transaction_type === "transfer"
                                  ? "تحويل"
                                  : "تعديل"}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-xs font-bold text-slate-500 max-w-xs">
                          {t.notes || "---"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-xs font-bold text-slate-600">
                          {t.user_name}
                        </td>
                        <td
                          className={`px-6 py-4 whitespace-nowrap text-center font-black ${
                            t.amount > 0 ? "text-emerald-600" : "text-rose-600"
                          }`}
                        >
                          {t.amount > 0 ? "+" : ""}
                          {Number(t.amount || 0).toLocaleString()} EGP
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot className="bg-slate-900 text-white">
                  <tr>
                    <td
                      colSpan={5}
                      className="px-6 py-4 text-sm font-black text-right uppercase tracking-[0.2em] opacity-80"
                    >
                      إجمالي الرصيد الصافي للفترة المختارة
                    </td>
                    <td className="px-6 py-4 text-center font-black text-lg border-l border-white/10">
                      {filteredData
                        .reduce((acc, t) => acc + Number(t.amount), 0)
                        .toLocaleString()}{" "}
                      EGP
                    </td>
                  </tr>
                </tfoot>
              </table>
            ) : activeReportType === "closings" ? (
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      تاريخ التقفيل
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">
                      الخزينة / الحساب
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      الرصيد الدفتري
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      الرصيد الفعلي
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      العجز / الزيادة
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      الحالة
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">
                      المسؤول
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {isLoading ? (
                    Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <tr key={i} className="animate-pulse">
                          <td colSpan={7} className="h-16 bg-slate-50/50"></td>
                        </tr>
                      ))
                  ) : filteredData.length === 0 ? (
                    <tr>
                      <td
                        colSpan={7}
                        className="px-6 py-12 text-center text-slate-400 font-bold italic"
                      >
                        لا توجد تقفيلات مطابقة للفترة المختارة
                      </td>
                    </tr>
                  ) : (
                    filteredData.map((c) => (
                      <tr
                        key={c.id}
                        className="hover:bg-slate-50/50 transition-colors text-sm"
                      >
                        <td className="px-6 py-4 whitespace-nowrap text-xs font-mono font-bold text-slate-600 text-center">
                          {safeFormat(c.closing_date || c.created_at, "yyyy-MM-dd", {
                            locale: ar,
                          })}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap font-bold text-slate-900">
                          {c.account_name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center font-bold text-slate-700">
                          {Number(c.system_balance || 0).toLocaleString()} ج.م
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center font-bold text-slate-800">
                          {Number(c.actual_balance || 0).toLocaleString()} ج.م
                        </td>
                        <td
                          className={`px-6 py-4 whitespace-nowrap text-center font-black ${
                            Number(c.difference) < 0
                              ? "text-rose-600"
                              : Number(c.difference) > 0
                                ? "text-emerald-600"
                                : "text-slate-500"
                          }`}
                        >
                          {Number(c.difference) > 0 ? "+" : ""}
                          {Number(c.difference || 0).toLocaleString()} ج.م
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <span
                            className={`px-2.5 py-1 rounded-full text-xs font-black ${
                              c.status === "approved"
                                ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
                                : "bg-amber-50 text-amber-700 border border-amber-100"
                            }`}
                          >
                            {c.status === "approved" ? "معتمد" : "مسودة معلقة"}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-600 font-bold">
                          {c.creator_name || "---"}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            ) : (
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      تاريخ الحركة
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">
                      الموظف المستلم
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">
                      الخزينة / الحساب
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      مبلغ العهدة
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      المبلغ المسوى
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      المبلغ المسترد
                    </th>
                    <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">
                      الحالة
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {isLoading ? (
                    Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <tr key={i} className="animate-pulse">
                          <td colSpan={7} className="h-16 bg-slate-50/50"></td>
                        </tr>
                      ))
                  ) : filteredData.length === 0 ? (
                    <tr>
                      <td
                        colSpan={7}
                        className="px-6 py-12 text-center text-slate-400 font-bold italic"
                      >
                        لا توجد عهد وأمانات مطابقة للفترة المختارة
                      </td>
                    </tr>
                  ) : (
                    filteredData.map((c) => (
                      <tr
                        key={c.id}
                        className="hover:bg-slate-50/50 transition-colors text-sm"
                      >
                        <td className="px-6 py-4 whitespace-nowrap text-xs font-mono font-bold text-slate-600 text-center">
                          {safeFormat(c.created_at, "yyyy-MM-dd", {
                            locale: ar,
                          })}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap font-bold text-slate-900">
                          {c.employee_name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-slate-500 font-bold">
                          {c.account_name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center font-bold text-slate-800">
                          {Number(c.amount || 0).toLocaleString()} ج.م
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center font-bold text-indigo-600">
                          {Number(c.cleared_amount || 0 || 0).toLocaleString()} ج.م
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center font-bold text-emerald-600">
                          {Number(c.returned_amount || 0 || 0).toLocaleString()} ج.م
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <span
                            className={`px-2.5 py-1 rounded-full text-xs font-black ${
                              c.status === "fully_cleared"
                                ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
                                : c.status === "partially_cleared"
                                  ? "bg-indigo-50 text-indigo-700 border border-indigo-100"
                                  : "bg-amber-50 text-amber-700 border border-amber-100"
                            }`}
                          >
                            {c.status === "fully_cleared"
                              ? "مسواة بالكامل"
                              : c.status === "partially_cleared"
                                ? "مسواة جزئياً"
                                : "تحت التسوية"}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
