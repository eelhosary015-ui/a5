import React, { useState, useEffect, useRef } from "react";
import { Globe, Check, Search, ChevronDown, Sparkles } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

interface LanguageOption {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

const LANGUAGES: LanguageOption[] = [
  { code: "ar", name: "Arabic", nativeName: "العربية", flag: "🇸🇦" },
  { code: "en", name: "English", nativeName: "English", flag: "🇺🇸" },
  { code: "es", name: "Spanish", nativeName: "Español", flag: "🇪🇸" },
  { code: "fr", name: "French", nativeName: "Français", flag: "🇫🇷" },
  { code: "de", name: "German", nativeName: "Deutsch", flag: "🇩🇪" },
  { code: "it", name: "Italian", nativeName: "Italiano", flag: "🇮🇹" },
  { code: "tr", name: "Turkish", nativeName: "Türkçe", flag: "🇹🇷" },
  { code: "ru", name: "Russian", nativeName: "Русский", flag: "🇷🇺" },
  { code: "zh-CN", name: "Chinese (Simplified)", nativeName: "简体中文", flag: "🇨🇳" },
  { code: "ur", name: "Urdu", nativeName: "اردو", flag: "🇵🇰" },
  { code: "hi", name: "Hindi", nativeName: "हिन्दी", flag: "🇮🇳" },
  { code: "fa", name: "Persian", nativeName: "فارسي", flag: "🇮🇷" },
  { code: "pt", name: "Portuguese", nativeName: "Português", flag: "🇵🇹" },
  { code: "ja", name: "Japanese", nativeName: "日本語", flag: "🇯🇵" },
  { code: "ko", name: "Korean", nativeName: "한국어", flag: "🇰🇷" },
  { code: "id", name: "Indonesian", nativeName: "Bahasa Indonesia", flag: "🇮🇩" },
  { code: "vi", name: "Vietnamese", nativeName: "Tiếng Việt", flag: "🇻🇳" },
  { code: "th", name: "Thai", nativeName: "ไทย", flag: "🇹🇭" },
  { code: "nl", name: "Dutch", nativeName: "Nederlands", flag: "🇳🇱" },
];

const writeTranslateCookie = (langCode: string) => {
  const isSecure = window.location.protocol === 'https:';
  const cookieSuffix = isSecure ? '; SameSite=None; Secure' : '';
  
  // Set basic path cookie
  document.cookie = `googtrans=/ar/${langCode}; path=/${cookieSuffix}`;
  
  // Also try root domain cookie if not localhost or direct IP
  if (window.location.hostname !== "localhost" && !/^\d+\.\d+\.\d+\.\d+$/.test(window.location.hostname)) {
    document.cookie = `googtrans=/ar/${langCode}; path=/; domain=${window.location.hostname}${cookieSuffix}`;
    const parts = window.location.hostname.split(".");
    if (parts.length >= 2) {
      const rootDomain = parts.slice(-2).join(".");
      document.cookie = `googtrans=/ar/${langCode}; path=/; domain=.${rootDomain}${cookieSuffix}`;
    }
  }
};

export const SystemTranslator: React.FC = () => {
  const { language, setLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeLang, setActiveLang] = useState("ar");
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Read from LanguageContext or localStorage
    const savedLang = localStorage.getItem('app_lang') || 'ar';
    
    const currentHash = window.location.hash;
    const expectedHash = `#googtrans(ar/${savedLang})`;
    
    if (savedLang !== 'ar' && !currentHash.includes("googtrans")) {
      // Set hash and reload once to trigger google translate
      window.location.hash = expectedHash;
      writeTranslateCookie(savedLang);
      window.location.reload();
      return;
    }

    // Read the current google translate cookie/hash if set
    const getTranslateCookie = () => {
      const match = document.cookie.match(/googtrans=\/ar\/([^;]+)/);
      if (match) return match[1];
      // Try hash
      const hashMatch = window.location.hash.match(/googtrans\(ar\/([^)]+)\)/);
      if (hashMatch) return hashMatch[1];
      return savedLang;
    };

    const active = getTranslateCookie();
    setActiveLang(active);
    if (active !== language) {
      setLanguage(active as any);
    }
    
    // Set cookie just in case
    if (active !== 'ar') {
      writeTranslateCookie(active);
    }

    // Define the global callback BEFORE appending the script
    (window as any).googleTranslateElementInit = () => {
      new (window as any).google.translate.TranslateElement(
        {
          pageLanguage: "ar",
          layout: (window as any).google.translate.TranslateElement.InlineLayout.SIMPLE,
          autoDisplay: false,
        },
        "google_translate_element"
      );
    };

    // Inject Google Translate script dynamically
    if (!document.getElementById("google-translate-script")) {
      const script = document.createElement("script");
      script.id = "google-translate-script";
      script.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      script.async = true;
      document.body.appendChild(script);
    }

    // Style overrides to hide the ugly Google Translate bar
    const style = document.createElement("style");
    style.id = "google-translate-overrides";
    style.innerHTML = `
      .skiptranslate, .goog-te-banner-frame, .goog-te-balloon-frame, #goog-gt-tt {
        display: none !important;
      }
      body {
        top: 0px !important;
      }
      #google_translate_element {
        display: none !important;
      }
      font {
        background-color: transparent !important;
        box-shadow: none !important;
      }
    `;
    document.head.appendChild(style);

    // Handle clicks outside dropdown to close it
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);

    // Periodically sync the Translate dropdown if Google Translate finishes loading
    const interval = setInterval(() => {
      const selectEl = document.querySelector(".goog-te-combo") as HTMLSelectElement;
      if (selectEl && selectEl.value !== active) {
        selectEl.value = active;
        selectEl.dispatchEvent(new Event("change"));
      }
    }, 1000);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      clearInterval(interval);
    };
  }, [language]);

  const changeLanguage = (langCode: string) => {
    setActiveLang(langCode);
    setIsOpen(false);

    // Sync with the native LanguageContext
    if (langCode === "ar") {
      setLanguage("ar");
    } else {
      setLanguage("en");
    }

    // Set cookie using our secure-aware helper
    writeTranslateCookie(langCode);
    
    // Set hash
    window.location.hash = `#googtrans(ar/${langCode})`;

    // Try to trigger the google translate combobox instantly
    const selectEl = document.querySelector(".goog-te-combo") as HTMLSelectElement;
    if (selectEl) {
      selectEl.value = langCode;
      selectEl.dispatchEvent(new Event("change"));
    } else {
      // Reload the page to let the script boot up with the new cookie/hash
      window.location.reload();
    }
  };

  const filteredLanguages = LANGUAGES.filter(
    (lang) =>
      lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedLanguage = LANGUAGES.find((l) => l.code === activeLang) || LANGUAGES[0];

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Hidden container for google translate widget to mount */}
      <div id="google_translate_element" className="hidden" />

      {/* Modern custom select trigger */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 hover:border-teal-300 transition-all text-xs font-semibold shadow-sm cursor-pointer select-none"
        title="ترجمة النظام لأي لغة / Translate System Language"
      >
        <Globe className="w-4 h-4 text-teal-600 animate-spin-slow" />
        <span className="hidden sm:inline-block font-medium">
          {selectedLanguage.flag} {selectedLanguage.nativeName}
        </span>
        <span className="sm:hidden font-medium">{selectedLanguage.flag}</span>
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {/* Language dropdown card */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 z-50 overflow-hidden animate-in fade-in slide-in-from-top-3 duration-200">
          <div className="p-3 bg-slate-50 border-b border-slate-100">
            <div className="flex items-center gap-1.5 text-slate-800 font-bold text-xs mb-2">
              <Sparkles className="w-4 h-4 text-teal-500" />
              <span>ترجمة فورية ذكية لكامل النظام</span>
            </div>
            
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute right-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="ابحث عن لغة... Search language"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-8 pl-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
                autoFocus
              />
            </div>
          </div>

          {/* Languages List */}
          <div className="max-h-60 overflow-y-auto divide-y divide-slate-50">
            {filteredLanguages.length === 0 ? (
              <p className="p-4 text-center text-xs text-slate-400">لا توجد نتائج مطابقة</p>
            ) : (
              filteredLanguages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => changeLanguage(lang.code)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 text-right text-xs hover:bg-teal-50/50 transition-colors cursor-pointer ${
                    activeLang === lang.code ? "bg-teal-50 text-teal-800 font-bold" : "text-slate-700"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{lang.flag}</span>
                    <div className="text-right">
                      <p className="font-semibold">{lang.nativeName}</p>
                      <p className="text-[10px] text-slate-400 font-normal">{lang.name}</p>
                    </div>
                  </div>
                  {activeLang === lang.code && <Check className="w-3.5 h-3.5 text-teal-600" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
