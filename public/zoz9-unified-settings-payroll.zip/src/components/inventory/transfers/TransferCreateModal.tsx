import React, { useState, useEffect, useMemo } from "react";
import { 
  X, 
  Plus, 
  Trash2, 
  AlertTriangle, 
  Check, 
  Boxes, 
  Truck, 
  ArrowRightLeft, 
  Calendar, 
  Search, 
  Barcode, 
  DollarSign, 
  HelpCircle,
  FileText,
  Building2,
  Tag
} from "lucide-react";
import { api } from "../../../utils/api";
import { TransferItem, TransferType, TransferPriority } from "./TransferTypes";

interface WarehouseOption {
  id: number;
  name: string;
  code: string;
  manager?: string;
  is_transit?: boolean;
}

interface IngredientOption {
  id: number;
  name: string;
  code: string;
  unit: string;
  barcode?: string;
  category?: string;
  avg_cost?: number;
  last_purchase_price?: number;
}

interface TransferCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<void>;
  warehouses: WarehouseOption[];
  ingredients: IngredientOption[];
  onNotify: (msg: string, type?: "success" | "error" | "info") => void;
}

export const TransferCreateModal: React.FC<TransferCreateModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  warehouses,
  ingredients,
  onNotify,
}) => {
  const [fromWarehouseId, setFromWarehouseId] = useState<string>("");
  const [toWarehouseId, setToWarehouseId] = useState<string>("");
  const [date, setDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [type, setType] = useState<TransferType>("standard");
  const [priority, setPriority] = useState<TransferPriority>("normal");
  const [department, setDepartment] = useState<string>("");
  const [purpose, setPurpose] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [driverName, setDriverName] = useState<string>("");
  const [vehicleNo, setVehicleNo] = useState<string>("");
  const [shippingCost, setShippingCost] = useState<number>(0);
  const [items, setItems] = useState<TransferItem[]>([]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [sourceStock, setSourceStock] = useState<Record<number, { available: number; quantity: number }>>({});
  const [loadingStock, setLoadingStock] = useState<boolean>(false);

  // Auto select first 2 warehouses if available
  useEffect(() => {
    if (isOpen && warehouses.length >= 2) {
      if (!fromWarehouseId) setFromWarehouseId(String(warehouses[0].id));
      if (!toWarehouseId) setToWarehouseId(String(warehouses[1].id));
    }
  }, [isOpen, warehouses]);

  // Fetch live stock for selected source warehouse
  useEffect(() => {
    if (!fromWarehouseId) return;

    const fetchStock = async () => {
      setLoadingStock(true);
      try {
        const res = await api.get(`/api/enterprise/warehouse-transfers/source-stock/${fromWarehouseId}`);
        const data = await res.json();
        if (data.success && Array.isArray(data.items)) {
          const map: Record<number, { available: number; quantity: number }> = {};
          data.items.forEach((it: any) => {
            map[Number(it.ingredient_id)] = {
              available: Number(it.available || it.quantity || 0),
              quantity: Number(it.quantity || 0),
            };
          });
          setSourceStock(map);
        }
      } catch (err) {
        console.error("Failed to load source warehouse stock:", err);
      } finally {
        setLoadingStock(false);
      }
    };

    fetchStock();
  }, [fromWarehouseId]);

  if (!isOpen) return null;

  const handleAddItem = (ingredientId?: number) => {
    let ing = ingredients[0];
    if (ingredientId) {
      const found = ingredients.find((i) => i.id === ingredientId);
      if (found) ing = found;
    }

    if (!ing) {
      onNotify("لا توجد أصناف مسجلة بالنظام", "info");
      return;
    }

    const avail = sourceStock[ing.id]?.available ?? 0;
    const total = sourceStock[ing.id]?.quantity ?? 0;

    const newItem: TransferItem = {
      ingredient_id: ing.id,
      name: ing.name,
      code: ing.code,
      unit: ing.unit || "قطعة",
      barcode: ing.barcode || "",
      requested_qty: 1,
      approved_qty: 1,
      unit_cost: ing.avg_cost || ing.last_purchase_price || 0,
      source_available_qty: avail,
      source_total_qty: total,
      batch_number: "",
      expiry_date: null,
      serial_number: "",
      source_location_code: "",
      target_location_code: "",
      notes: "",
    };

    setItems([...items, newItem]);
  };

  const handleItemChange = (index: number, field: keyof TransferItem, value: any) => {
    const updated = [...items];
    const item = { ...updated[index], [field]: value };

    if (field === "ingredient_id") {
      const ing = ingredients.find((i) => i.id === Number(value));
      if (ing) {
        item.name = ing.name;
        item.code = ing.code;
        item.unit = ing.unit || "قطعة";
        item.barcode = ing.barcode || "";
        item.unit_cost = ing.avg_cost || ing.last_purchase_price || 0;
        item.source_available_qty = sourceStock[ing.id]?.available ?? 0;
        item.source_total_qty = sourceStock[ing.id]?.quantity ?? 0;
      }
    }

    updated[index] = item;
    setItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const calculateTotals = () => {
    const totalQty = items.reduce((s, it) => s + Number(it.requested_qty || 0), 0);
    const totalValue = items.reduce((s, it) => s + (Number(it.requested_qty || 0) * Number(it.unit_cost || 0)), 0);
    return { totalQty, totalValue };
  };

  const { totalQty, totalValue } = calculateTotals();

  const handleSave = async (status: "draft" | "requested") => {
    if (!fromWarehouseId || !toWarehouseId) {
      onNotify("يرجى اختيار المخزن المصدر والمخزن المستهدف", "error");
      return;
    }

    if (Number(fromWarehouseId) === Number(toWarehouseId)) {
      onNotify("لا يمكن التحويل لنفس المخزن", "error");
      return;
    }

    if (items.length === 0) {
      onNotify("يرجى إضافة صنف واحد على الأقل للتحويل", "error");
      return;
    }

    // Check for 0 or negative quantities
    const invalidQty = items.some((it) => Number(it.requested_qty) <= 0);
    if (invalidQty) {
      onNotify("يجب أن تكون جميع الكميات المطلوبة أكبر من الصفر", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        from_warehouse_id: Number(fromWarehouseId),
        to_warehouse_id: Number(toWarehouseId),
        date,
        type,
        priority,
        department,
        purpose,
        notes,
        driver_name: driverName,
        vehicle_no: vehicleNo,
        shipping_cost: Number(shippingCost || 0),
        items,
        status,
      });
      onClose();
    } catch (err: any) {
      onNotify(err.message || "فشل في حفظ التحويل", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background overflow-y-auto" id="transfer-create-modal">
      <div className="bg-card border border-border/80 rounded-3xl shadow-2xl w-full max-w-5xl max-h-[95vh] flex flex-col overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-border/60 bg-muted/20">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-primary/10 text-primary border border-primary/20 shadow-sm">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-foreground tracking-tight">إنشاء طلب تحويل مخزني جديد</h2>
              <p className="text-xs text-muted-foreground mt-0.5">تسجيل أمر تحويل ونقل بضائع بين المستودعات</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2.5 text-muted-foreground hover:text-foreground hover:bg-muted/60 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-7 flex-1 text-right" dir="rtl">
          
          {/* Warehouse Selection & Core Info Card */}
          <div className="bg-muted/10 p-5 rounded-2xl border border-border/60 shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-5">
              {/* Source Warehouse */}
              <div>
                <label className="block text-[11px] font-bold text-foreground mb-1.5 flex items-center gap-1.5 tracking-tight">
                  <Building2 className="w-3.5 h-3.5 text-primary" />
                  <span>المخزن المصدر (الصرف) <span className="text-destructive">*</span></span>
                </label>
                <select
                  id="create-from-warehouse"
                  value={fromWarehouseId}
                  onChange={(e) => setFromWarehouseId(e.target.value)}
                  className="w-full h-10 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                >
                  <option value="">-- اختر المخزن المصدر --</option>
                  {warehouses.map((w) => (
                    <option key={`src-${w.id}`} value={String(w.id)}>
                      {w.name} ({w.code}) {w.manager ? `- مسؤول: ${w.manager}` : ""}
                    </option>
                  ))}
                </select>
              </div>

              {/* Destination Warehouse */}
              <div>
                <label className="block text-[11px] font-bold text-foreground mb-1.5 flex items-center gap-1.5 tracking-tight">
                  <Building2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                  <span>المخزن المستهدف (الاستلام) <span className="text-destructive">*</span></span>
                </label>
                <select
                  id="create-to-warehouse"
                  value={toWarehouseId}
                  onChange={(e) => setToWarehouseId(e.target.value)}
                  className="w-full h-10 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                >
                  <option value="">-- اختر المخزن المستهدف --</option>
                  {warehouses.map((w) => (
                    <option 
                      key={`dst-${w.id}`} 
                      value={String(w.id)}
                      disabled={String(w.id) === fromWarehouseId}
                    >
                      {w.name} ({w.code}) {w.is_transit ? " [مخزن ترانزيت]" : ""}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block text-[11px] font-bold text-foreground mb-1.5 flex items-center gap-1.5 tracking-tight">
                  <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                  <span>تاريخ التحويل</span>
                </label>
                <input
                  type="date"
                  id="create-date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full h-10 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-mono"
                />
              </div>

              {/* Transfer Type */}
              <div>
                <label className="block text-[11px] font-bold text-foreground mb-1.5 flex items-center gap-1.5 tracking-tight">
                  <Tag className="w-3.5 h-3.5 text-muted-foreground" />
                  <span>نوع التحويل</span>
                </label>
                <select
                  id="create-type"
                  value={type}
                  onChange={(e) => setType(e.target.value as TransferType)}
                  className="w-full h-10 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                >
                  <option value="standard">تحويل قياسي روتيني</option>
                  <option value="urgent">تحويل طارئ فوري</option>
                  <option value="replenishment">إعادة تموين دوري</option>
                  <option value="inter_branch">تحويل بين الفروع</option>
                  <option value="department_issue">صرف لقسم تشغيلي</option>
                  <option value="return_to_hub">إرجاع للمستودع المركزي</option>
                  <option value="damaged_transfer">نقل أصناف تالفة / عزل</option>
                </select>
              </div>
            </div>

            {/* Sub Row: Priority, Department, Purpose */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-4 border-t border-border/50">
              <div>
                <label className="block text-[11px] font-semibold text-muted-foreground mb-1">
                  درجة الأولوية
                </label>
                <select
                  id="create-priority"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as TransferPriority)}
                  className="w-full h-9 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                >
                  <option value="low">منخفضة (Low)</option>
                  <option value="normal">عادية (Normal)</option>
                  <option value="high">عالية (High)</option>
                  <option value="urgent">عاجلة وفورية (Urgent)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-muted-foreground mb-1">
                  القسم / الجهة الطالبة
                </label>
                <input
                  type="text"
                  id="create-department"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="مثال: قسم الصيانة، مطبخ الفندق، الإنتاج..."
                  className="w-full h-9 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-muted-foreground mb-1">
                  الغرض من التحويل
                </label>
                <input
                  type="text"
                  id="create-purpose"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="مثال: تغطية عجز مخزني، طلب تشغيل..."
                  className="w-full h-9 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                />
              </div>
            </div>
          </div>

          {/* Items Table Card */}
          <div className="border border-border/70 rounded-2xl overflow-hidden bg-card shadow-sm">
            <div className="flex items-center justify-between px-5 py-4 bg-muted/20 border-b border-border/70">
              <div className="flex items-center gap-2.5">
                <Boxes className="w-5 h-5 text-primary" />
                <h3 className="text-sm font-bold text-foreground">جدول الأصناف المحولة</h3>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">
                  {items.length} صنف
                </span>
              </div>

              <div className="flex items-center gap-3">
                {loadingStock && (
                  <span className="text-[11px] font-medium text-muted-foreground animate-pulse">
                    جاري تحميل أرصدة المخزن...
                  </span>
                )}
                <button
                  type="button"
                  id="btn-add-item-row"
                  onClick={() => handleAddItem()}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg text-xs font-bold shadow-md transition-transform active:scale-95 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة صنف</span>
                </button>
              </div>
            </div>

            {items.length === 0 ? (
              <div className="p-10 text-center text-muted-foreground flex flex-col items-center">
                <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mb-3">
                  <Boxes className="w-6 h-6 text-muted-foreground/60" />
                </div>
                <p className="text-sm font-bold text-foreground">لم يتم إضافة أي أصناف بعد</p>
                <p className="text-[11px] text-muted-foreground mt-1">اضغط على زر "إضافة صنف" لإدراج أصناف بالتحويل</p>
                <button
                  type="button"
                  onClick={() => handleAddItem()}
                  className="mt-4 px-5 py-2 bg-primary/10 text-primary hover:bg-primary/20 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  + إضافة أول صنف الآن
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right border-collapse">
                  <thead>
                    <tr className="bg-muted/40 text-muted-foreground border-b border-border/70 font-semibold tracking-tight">
                      <th className="py-3 px-4 w-12 text-center rounded-tr-lg">#</th>
                      <th className="py-3 px-4 min-w-[200px]">تحديد الصنف (الباركود / الاسم)</th>
                      <th className="py-3 px-4 w-28 text-center">الرصيد بالمصدر</th>
                      <th className="py-3 px-4 w-32 text-center">الكمية المطلوبة</th>
                      <th className="py-3 px-4 w-20 text-center">الوحدة</th>
                      <th className="py-3 px-4 w-28 text-center">التكلفة التقديرية</th>
                      <th className="py-3 px-4 w-28 text-center">الإجمالي</th>
                      <th className="py-3 px-4 min-w-[130px]">الباتش / الصلاحية (اختياري)</th>
                      <th className="py-3 px-4 min-w-[120px]">ملاحظات التشغيل</th>
                      <th className="py-3 px-4 w-12 text-center rounded-tl-lg">حذف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/60">
                    {items.map((item, idx) => {
                      const avail = item.source_available_qty ?? (sourceStock[item.ingredient_id]?.available ?? 0);
                      const isOverStock = Number(item.requested_qty) > avail;
                      const lineTotal = Number(item.requested_qty || 0) * Number(item.unit_cost || 0);

                      return (
                        <tr key={idx} className={`hover:bg-muted/30 transition-colors group ${isOverStock ? "bg-amber-500/5 hover:bg-amber-500/10" : ""}`}>
                          <td className="py-3 px-4 text-center text-muted-foreground font-mono font-medium">
                            {idx + 1}
                          </td>

                          {/* Ingredient Select */}
                          <td className="py-3 px-4">
                            <select
                              value={item.ingredient_id}
                              onChange={(e) => handleItemChange(idx, "ingredient_id", Number(e.target.value))}
                              className="w-full h-9 px-2.5 bg-background border border-border/80 rounded-lg text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                            >
                              {ingredients.map((ing) => (
                                <option key={ing.id} value={ing.id}>
                                  {ing.name} ({ing.code})
                                </option>
                              ))}
                            </select>
                            {item.barcode && (
                              <div className="flex items-center gap-1.5 mt-1.5 text-[10px] text-muted-foreground font-mono px-1">
                                <Barcode className="w-3.5 h-3.5 opacity-70" />
                                <span>{item.barcode}</span>
                              </div>
                            )}
                          </td>

                          {/* Available in Source */}
                          <td className="py-3 px-4 text-center">
                            <span className={`inline-flex items-center justify-center min-w-[3rem] px-2.5 py-1 rounded-md font-mono font-bold text-xs shadow-xs ${
                              avail <= 0
                                ? "bg-destructive/10 text-destructive border border-destructive/20"
                                : avail < 10
                                ? "bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30"
                                : "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20"
                            }`}>
                              {avail.toLocaleString("ar-EG")}
                            </span>
                          </td>

                          {/* Requested Qty */}
                          <td className="py-3 px-4 text-center">
                            <div className="relative">
                              <input
                                type="number"
                                min="0.01"
                                step="any"
                                value={item.requested_qty}
                                onChange={(e) => handleItemChange(idx, "requested_qty", parseFloat(e.target.value) || 0)}
                                className={`w-full h-9 px-2 text-center bg-background border rounded-lg text-sm font-black font-mono transition-all focus:outline-none focus:ring-2 ${
                                  isOverStock 
                                    ? "border-amber-500 text-amber-700 dark:text-amber-400 focus:ring-amber-500/30" 
                                    : "border-border/80 text-foreground focus:ring-primary/20 focus:border-primary"
                                }`}
                              />
                              {isOverStock && (
                                <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] text-amber-600 dark:text-amber-400 font-bold tracking-tight" title="الكمية المطلوبة تتجاوز الرصيد المتاح بالمخزن المصدر">
                                  تجاوز المتاح ({avail})
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Unit */}
                          <td className="py-3 px-4 text-center text-muted-foreground font-medium">
                            <span className="px-2 py-1 bg-muted/50 rounded-md text-[11px]">{item.unit}</span>
                          </td>

                          {/* Unit Cost */}
                          <td className="py-3 px-4 text-center">
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.unit_cost}
                              onChange={(e) => handleItemChange(idx, "unit_cost", parseFloat(e.target.value) || 0)}
                              className="w-full h-8 px-2 text-center bg-background/50 border border-border/60 rounded-md text-[11px] font-mono focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all text-muted-foreground hover:bg-background"
                            />
                          </td>

                          {/* Line Total */}
                          <td className="py-3 px-4 text-center">
                            <span className="font-mono font-bold text-foreground text-sm tracking-tight">
                              {lineTotal.toLocaleString("ar-EG", { minimumFractionDigits: 2 })}
                            </span>
                          </td>

                          {/* Batch / Expiry */}
                          <td className="py-3 px-4">
                            <div className="flex flex-col gap-1.5">
                              <input
                                type="text"
                                placeholder="الباتش / التشغيلة"
                                value={item.batch_number || ""}
                                onChange={(e) => handleItemChange(idx, "batch_number", e.target.value)}
                                className="w-full h-7 px-2 bg-background/50 border border-border/60 rounded-md text-[10px] focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all"
                              />
                              <input
                                type="date"
                                value={item.expiry_date || ""}
                                onChange={(e) => handleItemChange(idx, "expiry_date", e.target.value || null)}
                                className="w-full h-7 px-2 bg-background/50 border border-border/60 rounded-md text-[10px] text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all font-mono"
                              />
                            </div>
                          </td>

                          {/* Notes */}
                          <td className="py-3 px-4">
                            <textarea
                              placeholder="أضف ملاحظة..."
                              value={item.notes || ""}
                              onChange={(e) => handleItemChange(idx, "notes", e.target.value)}
                              rows={2}
                              className="w-full py-1.5 px-2 bg-background/50 border border-border/60 rounded-md text-[10px] focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all resize-none leading-relaxed"
                            />
                          </td>

                          {/* Delete Action */}
                          <td className="py-3 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(idx)}
                              className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors cursor-pointer opacity-50 group-hover:opacity-100"
                              title="إزالة الصنف من التحويل"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Summary Bar */}
            <div className="flex flex-wrap items-center justify-between p-4 bg-muted/20 border-t border-border/70 rounded-b-2xl">
              <div className="flex items-center gap-5 text-[11px] font-bold">
                <span className="text-muted-foreground flex items-center gap-1.5 bg-background px-3 py-1.5 rounded-lg border border-border/50 shadow-sm">
                  <span>إجمالي الكميات المحولة:</span>
                  <strong className="text-foreground font-mono text-sm">{totalQty.toLocaleString("ar-EG")}</strong>
                </span>
                <span className="text-muted-foreground flex items-center gap-1.5 bg-background px-3 py-1.5 rounded-lg border border-border/50 shadow-sm">
                  <span>القيمة التقديرية الإجمالية:</span>
                  <strong className="text-primary font-mono text-sm tracking-tight">{totalValue.toLocaleString("ar-EG", { minimumFractionDigits: 2 })} <span className="text-[10px]">ر.س</span></strong>
                </span>
              </div>

              <button
                type="button"
                onClick={() => handleAddItem()}
                className="text-[11px] text-primary hover:text-primary/80 font-bold cursor-pointer transition-colors"
              >
                + إضافة صنف إضافي
              </button>
            </div>
          </div>

          {/* Logistics & Shipping Section */}
          <div className="bg-muted/10 p-5 rounded-2xl border border-border/60 shadow-sm">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="p-1.5 rounded-lg bg-teal-500/10 text-teal-600">
                <Truck className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-foreground">بيانات الشحن والنقل الأولية</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-[11px] font-semibold text-muted-foreground mb-1.5">
                  اسم السائق / الناقل
                </label>
                <input
                  type="text"
                  id="create-driver"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  placeholder="مثال: أحمد محمود"
                  className="w-full h-9 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-muted-foreground mb-1.5">
                  رقم لوحة الشاحنة / المركبة
                </label>
                <input
                  type="text"
                  id="create-vehicle"
                  value={vehicleNo}
                  onChange={(e) => setVehicleNo(e.target.value)}
                  placeholder="مثال: أ ب ج 1234"
                  className="w-full h-9 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-muted-foreground mb-1.5">
                  تكلفة الشحن التقديرية (ر.س)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  id="create-shipping-cost"
                  value={shippingCost}
                  onChange={(e) => setShippingCost(parseFloat(e.target.value) || 0)}
                  className="w-full h-9 px-3 bg-background border border-border/80 rounded-xl text-sm font-bold font-mono text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                />
              </div>
            </div>

            {/* General Notes */}
            <div className="mt-4 pt-4 border-t border-border/50">
              <label className="block text-[11px] font-semibold text-muted-foreground mb-1.5">
                ملاحظات عامة وتوجيهات خاصة
              </label>
              <textarea
                rows={2}
                id="create-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="أضف أي تعليمات للنقل أو شروط خاصة بالتفريغ والتخزين..."
                className="w-full py-2.5 px-3 bg-background border border-border/80 rounded-xl text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none transition-all"
              />
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex flex-col-reverse sm:flex-row items-center justify-between px-6 py-4 border-t border-border/60 bg-muted/20 gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="w-full sm:w-auto px-5 py-2.5 border border-border/80 hover:bg-muted/80 text-foreground rounded-xl text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
          >
            إلغاء التراجع
          </button>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              id="btn-save-draft"
              onClick={() => handleSave("draft")}
              disabled={isSubmitting}
              className="flex-1 sm:flex-none px-5 py-2.5 bg-background border border-border/80 hover:bg-muted text-foreground rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50 hover:border-primary/30"
            >
              حفظ كمسودة
            </button>

            <button
              type="button"
              id="btn-submit-request"
              onClick={() => handleSave("requested")}
              disabled={isSubmitting}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer disabled:opacity-50 hover:scale-[1.02] active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? "جاري الإرسال..." : "تقديم طلب تحويل معتمد"}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
