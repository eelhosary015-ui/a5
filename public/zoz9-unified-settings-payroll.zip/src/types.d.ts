declare module "node-zklib";
declare module "arabic-reshaper";
