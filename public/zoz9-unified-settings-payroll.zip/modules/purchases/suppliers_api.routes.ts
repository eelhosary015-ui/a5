import { Router, Request, Response } from "express";
import { pool } from "../../server-db.js";
import { ERPEventBus } from "../../server-erp-core.js";

const router = Router();

// ─── Suppliers V1 API ───

router.get("/api/suppliers", async (req, res) => {
  try {
    const { search, status, group } = req.query;
    let query = "SELECT * FROM suppliers WHERE 1=1";
    const params: any[] = [];
    let idx = 1;
    if (search) { query += ` AND (name ILIKE $${idx} OR phone ILIKE $${idx} OR tax_number ILIKE $${idx} OR email ILIKE $${idx})`; params.push(`%${search}%`); idx++; }
    if (status) { query += ` AND status = $${idx}`; params.push(status); idx++; }
    if (group) { query += ` AND group_name = $${idx}`; params.push(group); idx++; }
    query += " ORDER BY created_at DESC";
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get("/api/suppliers/:id", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM suppliers WHERE id = $1", [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Supplier not found" });
    // Get stats
    const stats = await pool.query(`
      SELECT
        COALESCE((SELECT SUM(total_amount) FROM purchases WHERE supplier_id = $1), 0) as total_purchases,
        COALESCE((SELECT SUM(paid_amount) FROM purchases WHERE supplier_id = $1), 0) as total_paid,
        COALESCE((SELECT SUM(amount) FROM supplier_transactions WHERE supplier_id = $1 AND type = 'payment'), 0) as total_payments,
        COALESCE((SELECT SUM(amount) FROM supplier_transactions WHERE supplier_id = $1 AND type = 'return'), 0) as total_returns,
        (SELECT COUNT(*) FROM purchases WHERE supplier_id = $1) as purchase_count
    `, [req.params.id]);
    res.json({ ...result.rows[0], ...stats.rows[0] });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post("/api/suppliers", async (req, res) => {
  try {
    const { name, phone, phone_2, email, address, commercial_register, tax_number, group_name, payment_terms, credit_limit, opening_balance, notes, status } = req.body;
    if (!name) return res.status(400).json({ error: "Supplier name is required" });
    const result = await pool.query(
      `INSERT INTO suppliers (name, phone, phone_2, email, address, commercial_register, tax_number, group_name, payment_terms, credit_limit, balance, notes, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *`,
      [name, phone || null, phone_2 || null, email || null, address || null, commercial_register || null, tax_number || null, group_name || null, payment_terms || 'cash', credit_limit || 0, opening_balance || 0, notes || null, status || 'active']
    );
    // If opening_balance > 0, record as initial transaction
    if (opening_balance && opening_balance > 0) {
      await pool.query(
        `INSERT INTO supplier_transactions (supplier_id, type, amount, notes, reference_id) VALUES ($1, 'purchase', $2, 'رصيد افتتاحي', $3)`,
        [result.rows[0].id, opening_balance, result.rows[0].id]
      );
    }
    res.status(201).json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.put("/api/suppliers/:id", async (req, res) => {
  try {
    const { name, phone, phone_2, email, address, commercial_register, tax_number, group_name, payment_terms, credit_limit, notes, status } = req.body;
    const result = await pool.query(
      `UPDATE suppliers SET name = COALESCE($1, name), phone = COALESCE($2, phone), phone_2 = COALESCE($3, phone_2), email = COALESCE($4, email), address = COALESCE($5, address), commercial_register = COALESCE($6, commercial_register), tax_number = COALESCE($7, tax_number), group_name = COALESCE($8, group_name), payment_terms = COALESCE($9, payment_terms), credit_limit = COALESCE($10, credit_limit), notes = COALESCE($11, notes), status = COALESCE($12, status), updated_at = NOW() WHERE id = $13 RETURNING *`,
      [name, phone, phone_2, email, address, commercial_register, tax_number, group_name, payment_terms, credit_limit, notes, status, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Supplier not found" });
    res.json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete("/api/suppliers/:id", async (req, res) => {
  try {
    // Check if supplier has purchases
    const checkResult = await pool.query("SELECT COUNT(*) FROM purchases WHERE supplier_id = $1", [req.params.id]);
    if (parseInt(checkResult.rows[0].count) > 0) {
      return res.status(400).json({ error: "لا يمكن حذف مورد مرتبط بعمليات شراء" });
    }
    await pool.query("DELETE FROM supplier_transactions WHERE supplier_id = $1", [req.params.id]);
    const result = await pool.query("DELETE FROM suppliers WHERE id = $1 RETURNING *", [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Supplier not found" });
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post("/api/suppliers/:id/payments", async (req, res) => {
  try {
    const { amount, notes, payment_method } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ error: "Payment amount must be positive" });
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      // Record transaction
      const txResult = await client.query(
        `INSERT INTO supplier_transactions (supplier_id, type, amount, notes) VALUES ($1, 'payment', $2, $3) RETURNING *`,
        [req.params.id, amount, notes || `دفعة للمورد - ${payment_method || 'نقدي'}`]
      );
      // Update balance
      await client.query(
        `UPDATE suppliers SET balance = GREATEST(0, balance - $1) WHERE id = $2`,
        [amount, req.params.id]
      );
      await client.query("COMMIT");
      // Emit event for GL auto-posting
      try {
        const supplierResult = await pool.query("SELECT name FROM suppliers WHERE id = $1", [req.params.id]);
        ERPEventBus.getInstance().emitEvent("SupplierPaymentRecorded", {
          supplierId: parseInt(req.params.id),
          supplierName: supplierResult.rows[0]?.name,
          amount: amount,
          paymentMethod: payment_method || 'cash',
          transactionId: txResult.rows[0].id,
          timestamp: new Date()
        });
      } catch (e) { /* non-critical: GL posting failure shouldn't block payment */ }
      res.status(201).json(txResult.rows[0]);
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get("/api/suppliers/:id/transactions", async (req, res) => {
  try {
    const { from, to, type, limit = 50, offset = 0 } = req.query;
    let query = "SELECT * FROM supplier_transactions WHERE supplier_id = $1";
    const params: any[] = [req.params.id];
    let idx = 2;
    if (from) { query += ` AND timestamp >= $${idx}`; params.push(from); idx++; }
    if (to) { query += ` AND timestamp <= $${idx}`; params.push(to); idx++; }
    if (type) { query += ` AND type = $${idx}`; params.push(type); idx++; }
    query += ` ORDER BY timestamp DESC LIMIT $${idx} OFFSET $${idx+1}`;
    params.push(parseInt(limit as string), parseInt(offset as string));
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get("/api/suppliers/:id/statement", async (req, res) => {
  try {
    const { from, to } = req.query;
    let query = `SELECT st.*,
      CASE WHEN st.type = 'purchase' THEN st.amount WHEN st.type = 'payment' THEN -st.amount WHEN st.type = 'return' THEN -st.amount ELSE 0 END as effect,
      s.balance as current_balance
      FROM supplier_transactions st
      JOIN suppliers s ON s.id = st.supplier_id
      WHERE st.supplier_id = $1`;
    const params: any[] = [req.params.id];
    let idx = 2;
    if (from) { query += ` AND st.timestamp >= $${idx}`; params.push(from); idx++; }
    if (to) { query += ` AND st.timestamp <= $${idx}`; params.push(to); idx++; }
    query += " ORDER BY st.timestamp DESC";
    const result = await pool.query(query, params);
    // Calculate running balance
    const statement = result.rows.map((row: any, i: number, arr: any[]) => {
      if (i === 0) return { ...row, running_balance: parseFloat(row.current_balance || 0) };
      const prev = arr[i - 1];
      return { ...row, running_balance: (prev.running_balance || 0) - parseFloat(row.effect || 0) };
    });
    res.json(statement);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ═══════════════════════════════════════
// PURCHASE ORDERS V1 API
// ═══════════════════════════════════════
router.get("/api/purchase-orders", async (req: Request, res: Response) => {
  try {
    const { status, supplier_id, remaining_qty } = req.query;
    let query = `
      SELECT 
        po.*, 
        s.name as supplier_name,
        COALESCE((SELECT COUNT(*) FROM purchase_order_items poi WHERE poi.purchase_order_id = po.id AND (poi.quantity - COALESCE(poi.received_quantity, 0)) > 0), 0) as remaining_items_count,
        COALESCE((SELECT COUNT(*) FROM purchase_order_items poi WHERE poi.purchase_order_id = po.id), 0) as total_items_count,
        COALESCE((SELECT SUM(quantity) FROM purchase_order_items poi WHERE poi.purchase_order_id = po.id), 0) as total_ordered_qty,
        COALESCE((SELECT SUM(received_quantity) FROM purchase_order_items poi WHERE poi.purchase_order_id = po.id), 0) as total_received_qty
      FROM purchase_orders po 
      LEFT JOIN suppliers s ON po.supplier_id = s.id 
      WHERE 1=1
    `;
    const params: any[] = [];
    let idx = 1;
    if (status) {
      if (status === "approved") {
        query += ` AND po.status IN ('approved', 'partially_received')`;
      } else {
        query += ` AND po.status = $${idx}`;
        params.push(status);
        idx++;
      }
    }
    if (supplier_id) { query += ` AND po.supplier_id = $${idx}`; params.push(supplier_id); idx++; }
    if (remaining_qty) {
      query += ` AND EXISTS (SELECT 1 FROM purchase_order_items poi WHERE poi.purchase_order_id = po.id AND (poi.quantity - COALESCE(poi.received_quantity, 0)) > 0)`;
    }
    query += " ORDER BY po.date DESC, po.id DESC";
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get("/api/purchase-orders/:id", async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `SELECT po.*, s.name as supplier_name FROM purchase_orders po LEFT JOIN suppliers s ON po.supplier_id = s.id WHERE po.id = $1`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Purchase order not found" });
    const items = await pool.query(
      `SELECT poi.*, i.name as ingredient_name, i.unit FROM purchase_order_items poi LEFT JOIN ingredients i ON poi.ingredient_id = i.id WHERE poi.purchase_order_id = $1`,
      [req.params.id]
    );
    res.json({ ...result.rows[0], items: items.rows });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post("/api/purchase-orders", async (req: Request, res: Response) => {
  try {
    const { supplier_id, delivery_date, notes, items, requested_by } = req.body;
    if (!supplier_id || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "supplier_id and items are required" });
    }
    const total_amount = items.reduce((sum: number, i: any) => sum + (i.quantity * i.unit_price), 0);

    // Check if approval is required for this purchase order
    let requiresApproval = true;
    try {
      const setting = await pool.query("SELECT * FROM approval_settings WHERE module_type = 'purchase_order'");
      if (setting.rows.length > 0) {
        requiresApproval = setting.rows[0].requires_approval;
        // Auto-approve if below threshold
        if (requiresApproval && setting.rows[0].auto_approve_below > 0 && total_amount < parseFloat(setting.rows[0].auto_approve_below)) {
          requiresApproval = false;
        }
      }
    } catch (_e) { /* default: requires approval */ }

    const poStatus = requiresApproval ? 'pending_approval' : 'approved';
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const poResult = await client.query(
        `INSERT INTO purchase_orders (supplier_id, delivery_date, status, total_amount, notes, requested_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
        [supplier_id, delivery_date || null, poStatus, total_amount, notes || null, requested_by || null]
      );
      const poId = poResult.rows[0].id;
      for (const item of items) {
        await client.query(
          `INSERT INTO purchase_order_items (purchase_order_id, ingredient_id, quantity, unit_price, total_price) VALUES ($1, $2, $3, $4, $5)`,
          [poId, item.ingredient_id, item.quantity, item.unit_price, item.quantity * item.unit_price]
        );
      }

      // Auto-create approval request if needed
      if (requiresApproval) {
        // Get supplier name for title
        const supplierName = await client.query("SELECT name FROM suppliers WHERE id = $1", [supplier_id]);
        const sName = supplierName.rows[0]?.name || 'مورد';
        await client.query(
          `INSERT INTO approval_requests (module_type, reference_id, title, description, requested_by, metadata)
           VALUES ('purchase_order', $1, $2, $3, $4, $5)`,
          [poId, `أمر شراء #${poId} - ${sName}`, `إجمالي المبلغ: ${total_amount} جنيه`, requested_by || 'system', JSON.stringify({ total_amount, supplier_id, item_count: items.length })]
        );
      }

      await client.query("COMMIT");
      res.status(201).json({ ...poResult.rows[0], items, requires_approval: requiresApproval });
    } catch (e) { await client.query("ROLLBACK"); throw e; }
    finally { client.release(); }
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.put("/api/purchase-orders/:id", async (req: Request, res: Response) => {
  try {
    const { status, delivery_date, notes } = req.body;
    const result = await pool.query(
      `UPDATE purchase_orders SET status = COALESCE($1, status), delivery_date = COALESCE($2, delivery_date), notes = COALESCE($3, notes) WHERE id = $4 RETURNING *`,
      [status, delivery_date, notes, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Purchase order not found" });
    res.json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete("/api/purchase-orders/:id", async (req: Request, res: Response) => {
  try {
    await pool.query("DELETE FROM purchase_order_items WHERE purchase_order_id = $1", [req.params.id]);
    const result = await pool.query("DELETE FROM purchase_orders WHERE id = $1 AND status = 'pending' RETURNING *", [req.params.id]);
    if (result.rows.length === 0) return res.status(400).json({ error: "Can only delete pending orders" });
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ═══════════════════════════════════════
// PURCHASE REQUESTS V1 API
// ═══════════════════════════════════════
router.get("/api/purchase-requests", async (req: Request, res: Response) => {
  try {
    const { status } = req.query;
    let query = "SELECT * FROM purchase_requests WHERE 1=1";
    const params: any[] = [];
    let idx = 1;
    if (status) { query += ` AND status = $${idx}`; params.push(status); idx++; }
    query += " ORDER BY date DESC";
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get("/api/purchase-requests/:id", async (req: Request, res: Response) => {
  try {
    const result = await pool.query("SELECT * FROM purchase_requests WHERE id = $1", [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Purchase request not found" });
    const items = await pool.query("SELECT * FROM purchase_request_items WHERE purchase_request_id = $1", [req.params.id]);
    res.json({ ...result.rows[0], items: items.rows });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post("/api/purchase-requests", async (req: Request, res: Response) => {
  try {
    const { requested_by, notes, items } = req.body;
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: "items are required" });
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const prResult = await client.query(
        `INSERT INTO purchase_requests (requested_by, notes) VALUES ($1, $2) RETURNING *`,
        [requested_by || null, notes || null]
      );
      const prId = prResult.rows[0].id;
      for (const item of items) {
        await client.query(
          `INSERT INTO purchase_request_items (purchase_request_id, ingredient_id, name, unit, quantity, unit_price) VALUES ($1, $2, $3, $4, $5, $6)`,
          [prId, item.ingredient_id || null, item.name || null, item.unit || null, item.quantity, item.unit_price || 0]
        );
      }
      await client.query("COMMIT");
      res.status(201).json({ ...prResult.rows[0], items });
    } catch (e) { await client.query("ROLLBACK"); throw e; }
    finally { client.release(); }
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.put("/api/purchase-requests/:id", async (req: Request, res: Response) => {
  try {
    const { status, notes } = req.body;
    const result = await pool.query(
      `UPDATE purchase_requests SET status = COALESCE($1, status), notes = COALESCE($2, notes) WHERE id = $3 RETURNING *`,
      [status, notes, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Purchase request not found" });
    res.json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ═══════════════════════════════════════
// PURCHASES V1 API
// ═══════════════════════════════════════
router.get("/api/purchases", async (req: Request, res: Response) => {
  try {
    const { supplier_id, warehouse_id, status } = req.query;
    let query = `
      SELECT p.*, s.name as supplier_name, w.name as warehouse_name 
      FROM purchases p
      LEFT JOIN suppliers s ON p.supplier_id = s.id
      LEFT JOIN warehouses w ON p.warehouse_id = w.id
      WHERE 1=1
    `;
    const params: any[] = [];
    let idx = 1;
    if (supplier_id) { query += ` AND p.supplier_id = $${idx}`; params.push(supplier_id); idx++; }
    if (warehouse_id) { query += ` AND p.warehouse_id = $${idx}`; params.push(warehouse_id); idx++; }
    if (status) { query += ` AND p.status = $${idx}`; params.push(status); idx++; }
    query += " ORDER BY p.date DESC";
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get("/api/purchases/:id", async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `SELECT p.*, s.name as supplier_name, w.name as warehouse_name 
       FROM purchases p
       LEFT JOIN suppliers s ON p.supplier_id = s.id
       LEFT JOIN warehouses w ON p.warehouse_id = w.id
       WHERE p.id = $1`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Purchase not found" });
    const items = await pool.query(
      `SELECT pi.*, i.name as ingredient_name, i.unit 
       FROM purchase_items pi
       LEFT JOIN ingredients i ON pi.ingredient_id = i.id
       WHERE pi.purchase_id = $1`,
      [req.params.id]
    );
    res.json({ ...result.rows[0], items: items.rows });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post("/api/purchases", async (req: Request, res: Response) => {
  try {
    const { supplier_id, warehouse_id, invoice_number, total_amount, paid_amount, payment_status, notes, items, order_id } = req.body;
    if (!supplier_id || !warehouse_id || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "supplier_id, warehouse_id, and items are required" });
    }
    const invNum = invoice_number || `INV-${Date.now()}`;
    const totAmt = total_amount || items.reduce((sum: number, i: any) => sum + (i.quantity * i.unit_price), 0);
    const pdAmt = paid_amount || 0;
    const status = payment_status || (pdAmt >= totAmt ? 'paid' : pdAmt > 0 ? 'partially_paid' : 'received');

    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const pResult = await client.query(
        `INSERT INTO purchases (supplier_id, warehouse_id, invoice_number, total_amount, paid_amount, status, notes)
         VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
        [supplier_id, warehouse_id, invNum, totAmt, pdAmt, status, notes || null]
      );
      const purchaseId = pResult.rows[0].id;

      for (const item of items) {
        const itemTot = (item.quantity || 0) * (item.unit_price || 0);
        await client.query(
          `INSERT INTO purchase_items (purchase_id, ingredient_id, quantity, unit_price, total_price)
           VALUES ($1, $2, $3, $4, $5)`,
          [purchaseId, item.ingredient_id, item.quantity, item.unit_price, itemTot]
        );

        // Update warehouse item stock
        await client.query(
          `INSERT INTO inventory_items (warehouse_id, ingredient_id, quantity, min_quantity)
           VALUES ($1, $2, $3, 0)
           ON CONFLICT (warehouse_id, ingredient_id) 
           DO UPDATE SET quantity = inventory_items.quantity + EXCLUDED.quantity`,
          [warehouse_id, item.ingredient_id, item.quantity]
        );

        // Record stock transaction
        await client.query(
          `INSERT INTO inventory_transactions (warehouse_id, ingredient_id, quantity, type, reference_id, notes)
           VALUES ($1, $2, $3, 'purchase', $4, $5)`,
          [warehouse_id, item.ingredient_id, item.quantity, purchaseId, `شراء فاتورة رقم #${invNum}`]
        );
      }

      // Update supplier balance if unpaid amount exists
      const unpaid = totAmt - pdAmt;
      if (unpaid > 0) {
        await client.query(
          `UPDATE suppliers SET balance = balance + $1 WHERE id = $2`,
          [unpaid, supplier_id]
        );
        await client.query(
          `INSERT INTO supplier_transactions (supplier_id, type, amount, notes, reference_id)
           VALUES ($1, 'purchase', $2, $3, $4)`,
          [supplier_id, totAmt, `فاتورة شراء #${invNum}`, purchaseId]
        );
      }

      // If tied to purchase order, update purchase order status
      if (order_id) {
        await client.query(`UPDATE purchase_orders SET status = 'received' WHERE id = $1`, [order_id]);
      }

      await client.query("COMMIT");
      res.status(201).json({ ...pResult.rows[0], items });
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ═══════════════════════════════════════
// PURCHASE RETURNS V1 API
// ═══════════════════════════════════════
router.get("/api/returns/next-number", (_req: Request, res: Response) => {
  res.json({ next_number: `RET-${Date.now()}` });
});

router.get(["/api/returns", "/api/purchase-returns"], async (req: Request, res: Response) => {
  try {
    const { supplier_id, status } = req.query;
    let query = `SELECT pr.*, s.name as supplier_name, p.invoice_number FROM purchase_returns pr LEFT JOIN suppliers s ON pr.supplier_id = s.id LEFT JOIN purchases p ON pr.purchase_id = p.id WHERE 1=1`;
    const params: any[] = [];
    let idx = 1;
    if (supplier_id) { query += ` AND pr.supplier_id = $${idx}`; params.push(supplier_id); idx++; }
    if (status) { query += ` AND pr.status = $${idx}`; params.push(status); idx++; }
    query += " ORDER BY pr.date DESC";
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post(["/api/returns", "/api/purchase-returns"], async (req: Request, res: Response) => {
  try {
    const { supplier_id, purchase_id, total_amount, notes, items } = req.body;
    if (!supplier_id || !total_amount) return res.status(400).json({ error: "supplier_id and total_amount are required" });
    const return_number = `RET-${Date.now()}`;
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const retResult = await client.query(
        `INSERT INTO purchase_returns (return_number, supplier_id, purchase_id, total_amount, notes, status) VALUES ($1, $2, $3, $4, $5, 'pending') RETURNING *`,
        [return_number, supplier_id, purchase_id || null, total_amount, notes || null]
      );
      // Update supplier balance (reduce debt)
      await client.query(
        `UPDATE suppliers SET balance = GREATEST(0, balance - $1) WHERE id = $2`,
        [total_amount, supplier_id]
      );
      // Record transaction
      await client.query(
        `INSERT INTO supplier_transactions (supplier_id, type, amount, notes, reference_id) VALUES ($1, 'return', $2, $3, $4)`,
        [supplier_id, total_amount, notes || `مرتجع شراء ${return_number}`, retResult.rows[0].id]
      );
      // Return items to warehouse if items provided
      if (Array.isArray(items) && items.length > 0) {
        for (const item of items) {
          await client.query(
            `UPDATE inventory_items SET quantity = GREATEST(0, quantity - $1) WHERE warehouse_id = $2 AND ingredient_id = $3`,
            [item.quantity, item.warehouse_id, item.ingredient_id]
          );
        }
      }
      await client.query("COMMIT");
      res.status(201).json(retResult.rows[0]);
    } catch (e) { await client.query("ROLLBACK"); throw e; }
    finally { client.release(); }
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.put(["/api/returns/:id", "/api/purchase-returns/:id"], async (req: Request, res: Response) => {
  try {
    const { status, notes } = req.body;
    const result = await pool.query(
      `UPDATE purchase_returns SET status = COALESCE($1, status), notes = COALESCE($2, notes) WHERE id = $3 RETURNING *`,
      [status, notes, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Purchase return not found" });
    res.json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Initialize purchase_quotations table
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS purchase_quotations (
        id SERIAL PRIMARY KEY,
        quotation_number TEXT,
        request_id INTEGER,
        supplier_id INTEGER,
        supplier TEXT,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        delivery_date DATE,
        estimated_value DECIMAL(10,2) DEFAULT 0,
        status TEXT DEFAULT 'Draft',
        notes TEXT,
        items JSONB DEFAULT '[]'::jsonb,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
  } catch (err) {
    console.error("Error setting up purchase_quotations table:", err);
  }
})();

// ═══════════════════════════════════════
// PURCHASE QUOTATIONS V1 API
// ═══════════════════════════════════════
router.get(["/api/purchase-quotations", "/api/quotations"], async (req: Request, res: Response) => {
  try {
    const { status, supplier_id, request_id } = req.query;
    let query = "SELECT * FROM purchase_quotations WHERE 1=1";
    const params: any[] = [];
    let idx = 1;
    if (status) { query += ` AND status = $${idx}`; params.push(status); idx++; }
    if (supplier_id) { query += ` AND supplier_id = $${idx}`; params.push(supplier_id); idx++; }
    if (request_id) { query += ` AND request_id = $${idx}`; params.push(request_id); idx++; }
    query += " ORDER BY date DESC, id DESC";
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get(["/api/purchase-quotations/:id", "/api/quotations/:id"], async (req: Request, res: Response) => {
  try {
    const result = await pool.query("SELECT * FROM purchase_quotations WHERE id = $1", [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Quotation not found" });
    res.json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post(["/api/purchase-quotations", "/api/quotations"], async (req: Request, res: Response) => {
  try {
    const { quotation_number, request_id, supplier_id, supplier, delivery_date, estimated_value, status, notes, items } = req.body;
    const qNumber = quotation_number || `RFQ-${Date.now().toString().slice(-6)}`;
    const itemsJson = JSON.stringify(items || []);
    const result = await pool.query(
      `INSERT INTO purchase_quotations 
       (quotation_number, request_id, supplier_id, supplier, delivery_date, estimated_value, status, notes, items)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [
        qNumber,
        request_id ? Number(request_id) : null,
        supplier_id ? Number(supplier_id) : null,
        supplier || "مورد عام",
        delivery_date || null,
        Number(estimated_value || 0),
        status || "Draft",
        notes || "",
        itemsJson
      ]
    );
    res.status(201).json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.put(["/api/purchase-quotations/:id", "/api/quotations/:id"], async (req: Request, res: Response) => {
  try {
    const { quotation_number, request_id, supplier_id, supplier, delivery_date, estimated_value, status, notes, items } = req.body;
    const itemsJson = items !== undefined ? JSON.stringify(items) : null;
    const result = await pool.query(
      `UPDATE purchase_quotations SET 
        quotation_number = COALESCE($1, quotation_number),
        request_id = COALESCE($2, request_id),
        supplier_id = COALESCE($3, supplier_id),
        supplier = COALESCE($4, supplier),
        delivery_date = COALESCE($5, delivery_date),
        estimated_value = COALESCE($6, estimated_value),
        status = COALESCE($7, status),
        notes = COALESCE($8, notes),
        items = COALESCE($9, items),
        updated_at = CURRENT_TIMESTAMP
       WHERE id = $10 RETURNING *`,
      [
        quotation_number,
        request_id ? Number(request_id) : null,
        supplier_id ? Number(supplier_id) : null,
        supplier,
        delivery_date,
        estimated_value !== undefined ? Number(estimated_value) : null,
        status,
        notes,
        itemsJson,
        req.params.id
      ]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Quotation not found" });
    res.json(result.rows[0]);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete(["/api/purchase-quotations/:id", "/api/quotations/:id"], async (req: Request, res: Response) => {
  try {
    const result = await pool.query("DELETE FROM purchase_quotations WHERE id = $1 RETURNING *", [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Quotation not found" });
    res.json({ success: true, message: "Quotation deleted" });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ═══════════════════════════════════════
// SUPPLIER DASHBOARD / STATS V1 API
// ═══════════════════════════════════════
router.get("/api/suppliers-dashboard", async (req: Request, res: Response) => {
  try {
    const stats = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM suppliers WHERE status = 'active') as active_suppliers,
        (SELECT COUNT(*) FROM suppliers) as total_suppliers,
        (SELECT COALESCE(SUM(balance), 0) FROM suppliers WHERE balance > 0) as total_payable,
        (SELECT COALESCE(SUM(total_amount), 0) FROM purchases WHERE date >= CURRENT_DATE - INTERVAL '30 days') as purchases_30d,
        (SELECT COALESCE(SUM(amount), 0) FROM supplier_transactions WHERE type = 'payment' AND timestamp >= CURRENT_DATE - INTERVAL '30 days') as payments_30d,
        (SELECT COUNT(*) FROM purchase_orders WHERE status = 'pending') as pending_orders
    `);
    const topSuppliers = await pool.query(`
      SELECT s.id, s.name, s.phone, s.balance,
        COALESCE(SUM(p.total_amount), 0) as total_purchased
      FROM suppliers s
      LEFT JOIN purchases p ON p.supplier_id = s.id
      WHERE s.status = 'active'
      GROUP BY s.id ORDER BY total_purchased DESC LIMIT 5
    `);
    res.json({ stats: stats.rows[0], top_suppliers: topSuppliers.rows });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

export default router;