import { erpPool } from "../../../server-erp-core.js";
import { CreatePurchaseDTO } from "../dto/purchase.dto.js";

export class PurchaseRepository {
  async getAll(): Promise<any[]> {
    const query = `
      SELECT p.*, s.name as supplier_name, w.name as warehouse_name 
      FROM purchases p
      LEFT JOIN suppliers s ON p.supplier_id = s.id
      LEFT JOIN warehouses w ON p.warehouse_id = w.id
      ORDER BY p.date DESC
    `;
    const result = await erpPool.query(query);
    return result.rows;
  }

  async findById(id: number): Promise<any> {
    const query = `
      SELECT p.*, s.name as supplier_name, w.name as warehouse_name 
      FROM purchases p
      LEFT JOIN suppliers s ON p.supplier_id = s.id
      LEFT JOIN warehouses w ON p.warehouse_id = w.id
      WHERE p.id = $1
    `;
    const result = await erpPool.query(query, [id]);
    if (result.rows.length === 0) return null;

    const itemsQuery = `
      SELECT pi.*, i.name as ingredient_name, i.unit
      FROM purchase_items pi
      JOIN ingredients i ON pi.ingredient_id = i.id
      WHERE pi.purchase_id = $1
    `;
    const itemsResult = await erpPool.query(itemsQuery, [id]);
    
    return {
      ...result.rows[0],
      items: itemsResult.rows
    };
  }

  async create(purchase: CreatePurchaseDTO): Promise<any> {
    const client = await erpPool.connect();
    try {
      await client.query("BEGIN");

      // 1. Insert into purchases table
      const purchaseQuery = `
        INSERT INTO purchases (supplier_id, warehouse_id, invoice_number, total_amount, paid_amount, status, notes)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
      `;
      const purchaseResult = await client.query(purchaseQuery, [
        purchase.supplier_id,
        purchase.warehouse_id,
        purchase.invoice_number || null,
        purchase.total_amount,
        purchase.paid_amount || 0,
        "received",
        purchase.notes || null
      ]);
      const newPurchase = purchaseResult.rows[0];

      // 2. Loop and insert items & update stock
      for (const item of purchase.items) {
        const itemTotalPrice = item.quantity * item.unit_price;
        await client.query(
          `INSERT INTO purchase_items (purchase_id, ingredient_id, quantity, unit_price, total_price)
           VALUES ($1, $2, $3, $4, $5)`,
          [newPurchase.id, item.ingredient_id, item.quantity, item.unit_price, itemTotalPrice]
        );

        // Update warehouse item stock
        const stockQuery = `
          INSERT INTO inventory_items (warehouse_id, ingredient_id, quantity, min_quantity)
          VALUES ($1, $2, $3, 0)
          ON CONFLICT (warehouse_id, ingredient_id) 
          DO UPDATE SET quantity = inventory_items.quantity + EXCLUDED.quantity
        `;
        await client.query(stockQuery, [purchase.warehouse_id, item.ingredient_id, item.quantity]);

        // Record stock transaction log
        await client.query(
          `INSERT INTO inventory_transactions (warehouse_id, ingredient_id, quantity, type, reference_id, notes)
           VALUES ($1, $2, $3, 'purchase', $4, $5)`,
          [purchase.warehouse_id, item.ingredient_id, item.quantity, newPurchase.id, `شراء فاتورة رقم #${newPurchase.id}`]
        );
      }

      await client.query("COMMIT");
      return newPurchase;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
}
