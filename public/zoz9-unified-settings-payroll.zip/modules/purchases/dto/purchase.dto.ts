export interface CreatePurchaseItemDTO {
  ingredient_id: number;
  quantity: number;
  unit_price: number;
}

export interface CreatePurchaseDTO {
  supplier_id: number;
  warehouse_id: number;
  invoice_number?: string;
  total_amount: number;
  paid_amount?: number;
  notes?: string;
  items: CreatePurchaseItemDTO[];
}
