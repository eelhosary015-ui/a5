import { PurchaseRepository } from "../repositories/purchase.repository.js";
import { CreatePurchaseDTO } from "../dto/purchase.dto.js";
import { ERPCache, ERPEventBus } from "../../../server-erp-core.js";

export class PurchaseService {
  private repository: PurchaseRepository;

  constructor() {
    this.repository = new PurchaseRepository();
  }

  async getPurchases(): Promise<any[]> {
    const cacheKey = "purchases:all";
    const cached = ERPCache.get(cacheKey);
    if (cached) return cached;

    const purchases = await this.repository.getAll();
    ERPCache.set(cacheKey, purchases, 60); // cache for 1 minute
    return purchases;
  }

  async getPurchaseDetails(id: number): Promise<any> {
    const cacheKey = `purchase:${id}`;
    const cached = ERPCache.get(cacheKey);
    if (cached) return cached;

    const purchase = await this.repository.findById(id);
    if (purchase) {
      ERPCache.set(cacheKey, purchase, 300); // cache for 5 minutes
    }
    return purchase;
  }

  async createPurchase(dto: CreatePurchaseDTO): Promise<any> {
    const purchase = await this.repository.create(dto);
    ERPCache.delete("purchases:all");

    ERPEventBus.getInstance().emitEvent("PurchaseCreated", {
      purchaseId: purchase.id,
      supplierId: purchase.supplier_id,
      totalAmount: purchase.total_amount,
      warehouseId: purchase.warehouse_id,
      timestamp: new Date()
    });

    return purchase;
  }
}
