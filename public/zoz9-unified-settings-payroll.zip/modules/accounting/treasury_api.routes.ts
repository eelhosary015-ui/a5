import { Router } from "express";
import { pool } from "../../server-db.js";
import { authenticateToken } from "../system/system_api.routes.js";
import { upload } from "../../server.js";

const router = Router();

// Help Helper: Log Audit Trail
async function logAudit(client: any, transactionId: number | null, accountId: number | null, actionType: string, oldValues: any, newValues: any, userId: number, ip: string = "") {
  try {
    await client.query(
      `INSERT INTO treasury_audit_logs (transaction_id, account_id, action_type, old_values, new_values, user_id, ip_address) 
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [transactionId, accountId, actionType, JSON.stringify(oldValues), JSON.stringify(newValues), userId, ip]
    );
  } catch (err) {
    console.error("Audit log error:", err);
  }
}

// 1. DASHBOARD STATISTICS
router.get("/api/treasury/dashboard", authenticateToken, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Total balance, accounts stats
    const balanceRes = await pool.query(`
      SELECT 
        COALESCE(SUM(current_balance), 0)::float as total_balance,
        COALESCE(SUM(CASE WHEN type = 'cash' THEN current_balance ELSE 0 END), 0)::float as cash_balance,
        COALESCE(SUM(CASE WHEN type = 'bank' THEN current_balance ELSE 0 END), 0)::float as bank_balance,
        COALESCE(SUM(CASE WHEN type = 'petty_cash' THEN current_balance ELSE 0 END), 0)::float as petty_cash_balance
      FROM treasury_accounts
      WHERE status = 'active'
    `);
    
    // Daily flows
    const flowRes = await pool.query(`
      SELECT 
        COALESCE(SUM(CASE WHEN amount > 0 AND transaction_type != 'transfer' THEN amount ELSE 0 END), 0)::float as daily_receipts,
        COALESCE(SUM(CASE WHEN amount < 0 AND transaction_type != 'transfer' THEN ABS(amount) ELSE 0 END), 0)::float as daily_payments,
        COALESCE(SUM(CASE WHEN transaction_type = 'transfer' THEN ABS(amount)/2.0 ELSE 0 END), 0)::float as daily_transfers,
        COUNT(*)::integer as daily_count
      FROM treasury_transactions
      WHERE created_at::date = $1 AND status = 'approved'
    `, [today]);

    // High and Low accounts
    const limitsRes = await pool.query(`
      SELECT name, current_balance::float as balance, min_balance_limit::float as min_limit, max_balance_limit::float as max_limit
      FROM treasury_accounts
      WHERE status = 'active'
    `);

    let highestSafe = { name: "-", balance: 0 };
    let lowestSafe = { name: "-", balance: 0 };
    const alerts: any[] = [];

    if (limitsRes.rows.length > 0) {
      // Find highest/lowest
      const sorted = [...limitsRes.rows].sort((a, b) => b.balance - a.balance);
      highestSafe = { name: sorted[0].name, balance: sorted[0].balance };
      lowestSafe = { name: sorted[sorted.length - 1].name, balance: sorted[sorted.length - 1].balance };

      // Generate alerts
      for (const row of limitsRes.rows) {
        if (row.min_limit > 0 && row.balance < row.min_limit) {
          alerts.push({
            type: "warning_low",
            message: `تنبيه: رصيد الخزينة "${row.name}" (${row.balance.toLocaleString()} ج.م) أقل من الحد الأدنى المسموح به (${row.min_limit.toLocaleString()} ج.م)`
          });
        }
        if (row.max_limit > 0 && row.balance > row.max_limit) {
          alerts.push({
            type: "warning_high",
            message: `تنبيه: رصيد الخزينة "${row.name}" (${row.balance.toLocaleString()} ج.م) تجاوز الحد الأقصى المسموح به (${row.max_limit.toLocaleString()} ج.م)`
          });
        }
      }
    }

    // Last 5 transactions
    const lastTxRes = await pool.query(`
      SELECT t.*, a.name as account_name, u.username as user_name
      FROM treasury_transactions t
      JOIN treasury_accounts a ON t.account_id = a.id
      LEFT JOIN users u ON t.created_by = u.id
      ORDER BY t.created_at DESC
      LIMIT 5
    `);

    // Chart Data (Last 7 days flows)
    const chartRes = await pool.query(`
      SELECT 
        created_at::date as date_label,
        COALESCE(SUM(CASE WHEN amount > 0 AND transaction_type != 'transfer' THEN amount ELSE 0 END), 0)::float as inflows,
        COALESCE(SUM(CASE WHEN amount < 0 AND transaction_type != 'transfer' THEN ABS(amount) ELSE 0 END), 0)::float as outflows
      FROM treasury_transactions
      WHERE created_at >= NOW() - INTERVAL '7 days' AND status = 'approved'
      GROUP BY created_at::date
      ORDER BY created_at::date ASC
    `);

    res.json({
      summary: balanceRes.rows[0],
      daily: flowRes.rows[0],
      highestSafe,
      lowestSafe,
      alerts,
      latestTransactions: lastTxRes.rows,
      chartData: chartRes.rows
    });
  } catch (error) {
    console.error("Dashboard statistics error:", error);
    res.status(500).json({ error: "Failed to fetch dashboard statistics" });
  }
});

// 2. TREASURY ACCOUNTS CRUD & MANAGEMENT
router.get("/api/treasury/accounts", authenticateToken, async (req, res) => {
  try {
    const { status, search } = req.query;
    let query = `
      SELECT t.*, b.name as branch_name, u.username as responsible_user_name, p.name as parent_name
      FROM treasury_accounts t 
      LEFT JOIN branches b ON t.branch_id = b.id 
      LEFT JOIN users u ON t.responsible_user_id = u.id
      LEFT JOIN treasury_accounts p ON t.parent_id = p.id
      WHERE 1=1
    `;
    const params: any[] = [];
    if (status && status !== 'all') {
      params.push(status);
      query += ` AND t.status = $${params.length}`;
    }
    if (search) {
      params.push(`%${search}%`);
      query += ` AND (t.name ILIKE $${params.length})`;
    }
    query += ` ORDER BY t.is_main DESC, t.created_at DESC`;
    const accounts = (await pool.query(query, params)).rows;
    res.json(accounts);
  } catch (error) {
    console.error("Fetch accounts error:", error);
    res.status(500).json({ error: "Failed to fetch accounts" });
  }
});

router.post("/api/treasury/accounts", authenticateToken, async (req, res) => {
  const { name, type, currency, branch_id, opening_balance, min_balance_limit, max_balance_limit, responsible_user_id, is_main, parent_id, status } = req.body;
  const userId = (req as any).user?.id;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    const parsedOpening = parseFloat(opening_balance) || 0;
    const result = await client.query(
      `INSERT INTO treasury_accounts 
       (name, type, currency, current_balance, opening_balance, min_balance_limit, max_balance_limit, responsible_user_id, is_main, parent_id, branch_id, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *`,
      [
        name, 
        type, 
        currency || 'EGP', 
        parsedOpening, 
        parsedOpening, 
        parseFloat(min_balance_limit) || 0, 
        parseFloat(max_balance_limit) || 0, 
        responsible_user_id ? parseInt(responsible_user_id) : null,
        !!is_main,
        parent_id ? parseInt(parent_id) : null,
        branch_id ? parseInt(branch_id) : null,
        status || 'active'
      ]
    );

    const newAccount = result.rows[0];

    // Log Opening Transaction if greater than zero
    if (parsedOpening > 0) {
      await client.query(
        `INSERT INTO treasury_transactions 
         (account_id, amount, transaction_type, reference_type, notes, created_by, status, voucher_type, balance_before, balance_after) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [newAccount.id, parsedOpening, 'adjustment', 'general', 'رصيد افتتاحي عند التأسيس', userId, 'approved', 'receipt', 0, parsedOpening]
      );
    }

    await logAudit(client, null, newAccount.id, "create_account", null, newAccount, userId);
    await client.query("COMMIT");
    res.json(newAccount);
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create account error:", error);
    res.status(500).json({ error: "Failed to create treasury account" });
  } finally {
    client.release();
  }
});

router.put("/api/treasury/accounts/:id", authenticateToken, async (req, res) => {
  const { name, type, currency, min_balance_limit, max_balance_limit, responsible_user_id, is_main, parent_id, branch_id, status } = req.body;
  const userId = (req as any).user?.id;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    const oldAccount = (await client.query("SELECT * FROM treasury_accounts WHERE id = $1", [req.params.id])).rows[0];
    if (!oldAccount) throw new Error("Account not found");

    const result = await client.query(
      `UPDATE treasury_accounts 
       SET name = $1, type = $2, currency = $3, min_balance_limit = $4, max_balance_limit = $5, 
           responsible_user_id = $6, is_main = $7, parent_id = $8, branch_id = $9, status = $10 
       WHERE id = $11 RETURNING *`,
      [
        name, 
        type, 
        currency || 'EGP', 
        parseFloat(min_balance_limit) || 0, 
        parseFloat(max_balance_limit) || 0, 
        responsible_user_id ? parseInt(responsible_user_id) : null,
        !!is_main,
        parent_id ? parseInt(parent_id) : null,
        branch_id ? parseInt(branch_id) : null,
        status || 'active',
        req.params.id
      ]
    );

    const updated = result.rows[0];
    await logAudit(client, null, updated.id, "update_account", oldAccount, updated, userId);
    await client.query("COMMIT");
    res.json(updated);
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update account error:", error);
    res.status(500).json({ error: "Failed to update account" });
  } finally {
    client.release();
  }
});

router.post("/api/treasury/accounts/:id/reset", authenticateToken, async (req, res) => {
  const userId = (req as any).user?.id;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    const account = (await client.query("SELECT * FROM treasury_accounts WHERE id = $1", [req.params.id])).rows[0];
    if (!account) throw new Error("Account not found");

    const amount = Number(account.current_balance);
    if (amount !== 0) {
      // Create adjustment transaction to clear balance
      await client.query(
        `INSERT INTO treasury_transactions 
        (account_id, amount, transaction_type, reference_type, created_by, notes, status, balance_before, balance_after) 
        VALUES ($1, $2, 'adjustment', 'general', $3, 'تصفير وإعادة ضبط رصيد الخزينة', 'approved', $4, 0)`,
        [req.params.id, -amount, userId, amount]
      );
    }
    
    // Reset balance
    await client.query("UPDATE treasury_accounts SET current_balance = 0 WHERE id = $1", [req.params.id]);
    
    await logAudit(client, null, account.id, "reset_balance", { balance: amount }, { balance: 0 }, userId);
    await client.query("COMMIT");
    res.json({ success: true });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Reset account error:", error);
    res.status(500).json({ error: "Failed to reset account" });
  } finally {
    client.release();
  }
});

// 3. DETAILED REPORTS
router.get("/api/treasury/reports/detailed", authenticateToken, async (req, res) => {
  const { accountId, startDate, endDate, transactionType, status, branchId } = req.query;
  try {
    let query = `
      SELECT t.*, u.username as user_name, c.name as cost_center_name, a.name as account_name, a.type as account_type, b.name as branch_name
      FROM treasury_transactions t
      LEFT JOIN users u ON t.created_by = u.id
      LEFT JOIN cost_centers c ON t.cost_center_id = c.id
      LEFT JOIN treasury_accounts a ON t.account_id = a.id
      LEFT JOIN branches b ON a.branch_id = b.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (accountId && accountId !== 'all') {
      params.push(accountId);
      query += ` AND t.account_id = $${params.length}`;
    }
    if (startDate) {
      params.push(startDate);
      query += ` AND t.created_at >= $${params.length}`;
    }
    if (endDate) {
      params.push(`${endDate} 23:59:59`);
      query += ` AND t.created_at <= $${params.length}`;
    }
    if (transactionType && transactionType !== 'all') {
      params.push(transactionType);
      query += ` AND t.transaction_type = $${params.length}`;
    }
    if (status && status !== 'all') {
      params.push(status);
      query += ` AND t.status = $${params.length}`;
    }
    if (branchId && branchId !== 'all') {
      params.push(branchId);
      query += ` AND a.branch_id = $${params.length}`;
    }

    query += ` ORDER BY t.created_at DESC`;
    
    const transactions = (await pool.query(query, params)).rows;
    res.json(transactions);
  } catch (error) {
    console.error("Fetch detailed report error:", error);
    res.status(500).json({ error: "Failed to fetch report data" });
  }
});

// 4. TRANSACTION INDEX & DETAILED ACTIONS
router.get("/api/treasury/transactions/:accountId", authenticateToken, async (req, res) => {
  const { status, type, search } = req.query;
  try {
    let query = `
      SELECT t.*, u.username as user_name, c.name as cost_center_name, a.name as account_name
      FROM treasury_transactions t
      LEFT JOIN users u ON t.created_by = u.id
      LEFT JOIN cost_centers c ON t.cost_center_id = c.id
      LEFT JOIN treasury_accounts a ON t.account_id = a.id
      WHERE t.account_id = $1
    `;
    const params: any[] = [req.params.accountId];

    if (status && status !== 'all') {
      params.push(status);
      query += ` AND t.status = $${params.length}`;
    }
    if (type && type !== 'all') {
      params.push(type);
      query += ` AND t.transaction_type = $${params.length}`;
    }
    if (search) {
      params.push(`%${search}%`);
      query += ` AND (t.notes ILIKE $${params.length} OR t.voucher_number ILIKE $${params.length} OR t.client_name ILIKE $${params.length})`;
    }

    query += ` ORDER BY t.created_at DESC`;
    const transactions = (await pool.query(query, params)).rows;
    res.json(transactions);
  } catch (error) {
    console.error("Fetch transactions error:", error);
    res.status(500).json({ error: "Failed to fetch transactions" });
  }
});

// 5. TRANSACTION POSTING / VOUCHERS / TRANSFERS
router.post("/api/treasury/transactions", authenticateToken, upload.single('attachment'), async (req, res) => {
  const { 
    account_id, 
    amount, 
    transaction_type, 
    reference_type, 
    reference_id, 
    notes, 
    cost_center_id, 
    target_account_id,
    voucher_type, // 'receipt', 'payment'
    tax_amount,
    discount_amount,
    payment_method, // 'cash', 'bank', 'check', 'electronic'
    client_type,
    client_name
  } = req.body;
  
  const attachment_url = req.file ? `/uploads/${req.file.filename}` : null;
  const userId = (req as any).user?.id || null;
  const parsedAmount = parseFloat(amount);
  const parsedTax = parseFloat(tax_amount) || 0;
  const parsedDiscount = parseFloat(discount_amount) || 0;

  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return res.status(400).json({ error: "المبلغ غير صالح" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    // Check if Account exists
    const account = (await client.query("SELECT * FROM treasury_accounts WHERE id = $1", [account_id])).rows[0];
    if (!account) {
      throw new Error("الحساب المرسل غير موجود بالخلفية");
    }

    if (account.status !== 'active') {
      throw new Error("لا يمكن تنفيذ عمليات على خزينة موقوفة");
    }

    // Check if date is locked by daily closing
    const today = new Date().toISOString().split('T')[0];
    const isClosed = (await client.query(
      "SELECT id FROM treasury_daily_closings WHERE account_id = $1 AND created_at::date = $2 AND status = 'closed'", 
      [account_id, today]
    )).rows.length > 0;

    if (isClosed) {
      throw new Error("اليومية مغلقة بالفعل لهذه الخزينة اليوم. يجب إعادة فتحها أولاً بصلاحيات إدارية.");
    }

    // If transfer between accounts
    if (transaction_type === 'transfer' && target_account_id) {
      const targetAccount = (await client.query("SELECT * FROM treasury_accounts WHERE id = $1", [target_account_id])).rows[0];
      if (!targetAccount) {
        throw new Error("الحساب المستهدف غير موجود");
      }
      if (targetAccount.status !== 'active') {
        throw new Error("الحساب المستهدف موقوف حالياً");
      }

      // Check balance limit
      if (account.current_balance < parsedAmount) {
        // Query if negative is allowed (can look at settings)
        const negRes = await client.query("SELECT value FROM treasury_settings WHERE key = 'allow_negative_balance'");
        const allowNeg = negRes.rows.length > 0 && negRes.rows[0].value === 'true';
        if (!allowNeg) {
          throw new Error(`عذراً، رصيد الخزينة الحالية غير كافي لإجراء التحويل المالي (${account.current_balance} ج.م)`);
        }
      }

      // Sequential auto voucher number for Transfer
      const year = new Date().getFullYear();
      const seqRes = await client.query(
        "SELECT COUNT(*)::integer as count FROM treasury_transactions WHERE transaction_type = 'transfer' AND EXTRACT(YEAR FROM created_at) = $1",
        [year]
      );
      const voucherNum = `TRF-${year}-${(seqRes.rows[0].count + 1).toString().padStart(4, '0')}`;

      // Source Account Outflow (Negative Amount)
      const srcBalanceBefore = Number(account.current_balance);
      const srcBalanceAfter = srcBalanceBefore - parsedAmount;
      
      const srcTx = await client.query(
        `INSERT INTO treasury_transactions 
         (account_id, amount, transaction_type, reference_type, reference_id, notes, created_by, cost_center_id, attachment_url, 
          status, voucher_number, voucher_type, tax_amount, discount_amount, payment_method, client_type, client_name, balance_before, balance_after) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19) RETURNING *`,
        [
          account_id, -parsedAmount, 'transfer', reference_type || 'general', reference_id || null, 
          notes || `تحويل صادر إلى ${targetAccount.name}`, userId, cost_center_id || null, attachment_url,
          'approved', voucherNum, 'payment', parsedTax, parsedDiscount, payment_method || 'cash', client_type || 'other', client_name || targetAccount.name,
          srcBalanceBefore, srcBalanceAfter
        ]
      );

      await client.query(`UPDATE treasury_accounts SET current_balance = current_balance - $1 WHERE id = $2`, [parsedAmount, account_id]);

      // Target Account Inflow (Positive Amount)
      const tgtBalanceBefore = Number(targetAccount.current_balance);
      const tgtBalanceAfter = tgtBalanceBefore + parsedAmount;

      const tgtTx = await client.query(
        `INSERT INTO treasury_transactions 
         (account_id, amount, transaction_type, reference_type, reference_id, notes, created_by, cost_center_id, attachment_url, 
          status, voucher_number, voucher_type, tax_amount, discount_amount, payment_method, client_type, client_name, balance_before, balance_after) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19) RETURNING *`,
        [
          target_account_id, parsedAmount, 'transfer', reference_type || 'general', reference_id || null, 
          notes || `تحويل وارد من ${account.name}`, userId, cost_center_id || null, attachment_url,
          'approved', voucherNum, 'receipt', parsedTax, parsedDiscount, payment_method || 'cash', client_type || 'other', client_name || account.name,
          tgtBalanceBefore, tgtBalanceAfter
        ]
      );

      await client.query(`UPDATE treasury_accounts SET current_balance = current_balance + $1 WHERE id = $2`, [parsedAmount, target_account_id]);

      await logAudit(client, srcTx.rows[0].id, account_id, "transfer_out", null, srcTx.rows[0], userId);
      await logAudit(client, tgtTx.rows[0].id, target_account_id, "transfer_in", null, tgtTx.rows[0], userId);

    } else {
      // Standard transaction (Cash In, Cash Out, Adjustment)
      let sign = 1;
      let calculatedVType = voucher_type || (transaction_type === 'cash_in' ? 'receipt' : 'payment');

      if (transaction_type === 'cash_out') {
        sign = -1;
      }

      const netDelta = sign * parsedAmount;
      const balanceBefore = Number(account.current_balance);
      const balanceAfter = balanceBefore + netDelta;

      if (netDelta < 0 && account.current_balance < parsedAmount) {
        const negRes = await client.query("SELECT value FROM treasury_settings WHERE key = 'allow_negative_balance'");
        const allowNeg = negRes.rows.length > 0 && negRes.rows[0].value === 'true';
        if (!allowNeg) {
          throw new Error(`عذراً، رصيد الخزينة غير كافي لإجراء عملية الصرف الحالية (${account.current_balance} ج.م)`);
        }
      }

      // Generate Auto Sequential Voucher No
      const year = new Date().getFullYear();
      const prefix = calculatedVType === 'receipt' ? 'REC' : 'PAY';
      const seqRes = await client.query(
        "SELECT COUNT(*)::integer as count FROM treasury_transactions WHERE voucher_type = $1 AND EXTRACT(YEAR FROM created_at) = $2",
        [calculatedVType, year]
      );
      const voucherNum = `${prefix}-${year}-${(seqRes.rows[0].count + 1).toString().padStart(4, '0')}`;

      const txResult = await client.query(
        `INSERT INTO treasury_transactions 
         (account_id, amount, transaction_type, reference_type, reference_id, notes, created_by, cost_center_id, attachment_url,
          status, voucher_number, voucher_type, tax_amount, discount_amount, payment_method, client_type, client_name, balance_before, balance_after) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19) RETURNING *`,
        [
          account_id, netDelta, transaction_type, reference_type || 'general', reference_id || null, notes, userId, cost_center_id || null, attachment_url,
          'approved', voucherNum, calculatedVType, parsedTax, parsedDiscount, payment_method || 'cash', client_type || 'other', client_name || '-',
          balanceBefore, balanceAfter
        ]
      );

      // Update account balance
      await client.query(`UPDATE treasury_accounts SET current_balance = current_balance + $1 WHERE id = $2`, [netDelta, account_id]);

      const postedTx = txResult.rows[0];
      await logAudit(client, postedTx.id, account_id, transaction_type, null, postedTx, userId);
    }

    await client.query("COMMIT");
    res.json({ success: true });
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Create transaction error:", error);
    res.status(500).json({ error: error.message || "Failed to create transaction" });
  } finally {
    client.release();
  }
});

// Transaction Edit & Cancellation
router.put("/api/treasury/transactions/:id", authenticateToken, async (req, res) => {
  const { notes, cost_center_id, status } = req.body;
  const userId = (req as any).user?.id || null;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const oldTx = (await client.query("SELECT * FROM treasury_transactions WHERE id = $1", [req.params.id])).rows[0];
    if (!oldTx) throw new Error("Transaction not found");

    const result = await client.query(
      `UPDATE treasury_transactions SET notes = $1, cost_center_id = $2, status = $3 WHERE id = $4 RETURNING *`,
      [notes || oldTx.notes, cost_center_id ? parseInt(cost_center_id) : oldTx.cost_center_id, status || oldTx.status, req.params.id]
    );

    const updated = result.rows[0];
    await logAudit(client, updated.id, updated.account_id, "update_transaction", oldTx, updated, userId);
    
    await client.query("COMMIT");
    res.json(updated);
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update transaction error:", error);
    res.status(500).json({ error: "Failed to update transaction" });
  } finally {
    client.release();
  }
});

router.post("/api/treasury/transactions/:id/cancel", authenticateToken, async (req, res) => {
  const userId = (req as any).user?.id || null;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const tx = (await client.query("SELECT * FROM treasury_transactions WHERE id = $1", [req.params.id])).rows[0];
    if (!tx) throw new Error("Transaction not found");
    if (tx.status === 'canceled') throw new Error("العملية ملغاة بالفعل");

    // Reverse account balance effect
    const amountToReverse = -Number(tx.amount);
    
    const account = (await client.query("SELECT current_balance FROM treasury_accounts WHERE id = $1", [tx.account_id])).rows[0];
    if (!account) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'الحساب غير موجود' }); }
    const balanceBefore = Number(account.current_balance);
    const balanceAfter = balanceBefore + amountToReverse;

    // Update account
    await client.query("UPDATE treasury_accounts SET current_balance = current_balance + $1 WHERE id = $2", [amountToReverse, tx.account_id]);

    // Update original transaction status to canceled and document reversal
    const result = await client.query(
      `UPDATE treasury_transactions 
       SET status = 'canceled', notes = CONCAT(notes, ' - تم الإلغاء بواسطة المستخدم'), balance_after = $1
       WHERE id = $2 RETURNING *`,
      [balanceAfter, req.params.id]
    );

    await logAudit(client, tx.id, tx.account_id, "cancel_transaction", tx, result.rows[0], userId);
    await client.query("COMMIT");
    res.json({ success: true, transaction: result.rows[0] });
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Cancel transaction error:", error);
    res.status(500).json({ error: error.message || "Failed to cancel transaction" });
  } finally {
    client.release();
  }
});

// 6. DAILY CLOSINGS (إقفال اليومية)
router.get("/api/treasury/closings", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT dc.*, s.name as account_name, u.username as creator_name, app.username as approver_name
      FROM treasury_daily_closings dc
      JOIN treasury_accounts s ON dc.account_id = s.id
      JOIN users u ON dc.created_by = u.id
      LEFT JOIN users app ON dc.approved_by = app.id
      ORDER BY dc.created_at DESC
    `;
    const closings = (await pool.query(query)).rows;
    res.json(closings);
  } catch (error) {
    console.error("Fetch closings error:", error);
    res.status(500).json({ error: "Failed to fetch daily closings" });
  }
});

router.post("/api/treasury/closings", authenticateToken, async (req, res) => {
  const { account_id, actual_balance, notes } = req.body;
  const userId = (req as any).user?.id || null;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    const account = (await client.query("SELECT * FROM treasury_accounts WHERE id = $1", [account_id])).rows[0];
    if (!account) throw new Error("Treasury account not found");

    const today = new Date().toISOString().split('T')[0];

    // Calculate flows for today for this safe
    const flowsRes = await client.query(`
      SELECT 
        COALESCE(SUM(CASE WHEN amount > 0 AND transaction_type != 'transfer' THEN amount ELSE 0 END), 0)::float as receipts,
        COALESCE(SUM(CASE WHEN amount < 0 AND transaction_type != 'transfer' THEN ABS(amount) ELSE 0 END), 0)::float as payments,
        COALESCE(SUM(CASE WHEN amount > 0 AND transaction_type = 'transfer' THEN amount ELSE 0 END), 0)::float as transfers_in,
        COALESCE(SUM(CASE WHEN amount < 0 AND transaction_type = 'transfer' THEN ABS(amount) ELSE 0 END), 0)::float as transfers_out
      FROM treasury_transactions
      WHERE account_id = $1 AND created_at::date = $2 AND status = 'approved'
    `, [account_id, today]);

    const flow = flowsRes.rows[0];
    const openingBalance = Number(account.current_balance) - (flow.receipts + flow.transfers_in - flow.payments - flow.transfers_out);
    const expectedBalance = Number(account.current_balance);
    const difference = Number(actual_balance) - expectedBalance;

    const result = await client.query(`
      INSERT INTO treasury_daily_closings 
      (account_id, opening_balance, receipts, payments, transfers_in, transfers_out, expected_balance, actual_balance, difference, status, notes, created_by)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'closed', $10, $11) RETURNING *
    `, [
      account_id, 
      openingBalance, 
      flow.receipts, 
      flow.payments, 
      flow.transfers_in, 
      flow.transfers_out, 
      expectedBalance, 
      actual_balance, 
      difference, 
      notes || "إقفال اليومية التلقائي", 
      userId
    ]);

    // If there is discrepancy, post discrepancy cash transaction to treasury_transactions to reconcile
    if (difference !== 0) {
      const voucherType = difference > 0 ? 'receipt' : 'payment';
      const typeLabel = difference > 0 ? 'تسوية فروقات جرد (زيادة)' : 'تسوية فروقات جرد (عجز)';
      const year = new Date().getFullYear();
      const prefix = voucherType === 'receipt' ? 'REC' : 'PAY';
      
      const seqRes = await client.query(
        "SELECT COUNT(*)::integer as count FROM treasury_transactions WHERE voucher_type = $1 AND EXTRACT(YEAR FROM created_at) = $2",
        [voucherType, year]
      );
      const voucherNum = `${prefix}-${year}-${(seqRes.rows[0].count + 1).toString().padStart(4, '0')}`;

      await client.query(`
        INSERT INTO treasury_transactions 
        (account_id, amount, transaction_type, notes, created_by, status, voucher_number, voucher_type, balance_before, balance_after)
        VALUES ($1, $2, 'adjustment', $3, $4, 'approved', $5, $6, $7, $8)
      `, [
        account_id, 
        difference, 
        `${typeLabel} - إغلاق اليومية`, 
        userId, 
        voucherNum, 
        voucherType, 
        expectedBalance, 
        actual_balance
      ]);

      // Reconcile account balance to actual balance
      await client.query("UPDATE treasury_accounts SET current_balance = $1 WHERE id = $2", [actual_balance, account_id]);
    }

    const closing = result.rows[0];
    await logAudit(client, null, account_id, "close_day", null, closing, userId);

    await client.query("COMMIT");
    res.json(closing);
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Create closing error:", error);
    res.status(500).json({ error: error.message || "Failed to create closing" });
  } finally {
    client.release();
  }
});

router.post("/api/treasury/closings/:id/reopen", authenticateToken, async (req, res) => {
  const userId = (req as any).user?.id || null;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    const closing = (await client.query("SELECT * FROM treasury_daily_closings WHERE id = $1", [req.params.id])).rows[0];
    if (!closing) throw new Error("Closing record not found");

    // Check permissions inside standard flow or allow if role is admin
    const userRole = (req as any).user?.role;
    if (userRole !== 'admin') {
      throw new Error("عذراً، لا توجد لديك صلاحيات لإعادة فتح إقفال اليوميات. يرجى مراجعة المسؤول.");
    }

    const result = await client.query(
      `UPDATE treasury_daily_closings 
       SET status = 'reopened', approved_by = $1, approved_at = NOW() 
       WHERE id = $2 RETURNING *`,
      [userId, req.params.id]
    );

    await logAudit(client, null, closing.account_id, "reopen_day", closing, result.rows[0], userId);
    await client.query("COMMIT");
    res.json(result.rows[0]);
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Reopen closing error:", error);
    res.status(500).json({ error: error.message || "Failed to reopen closing" });
  } finally {
    client.release();
  }
});

// 7. CUSTODY / PETTY CASH ADVANCES (العهد)
router.get("/api/treasury/custodies", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT c.*, e.name as employee_name, a.name as account_name
      FROM treasury_custodies c
      JOIN employees e ON c.employee_id = e.id
      JOIN treasury_accounts a ON c.account_id = a.id
      ORDER BY c.created_at DESC
    `;
    const custodies = (await pool.query(query)).rows;
    res.json(custodies);
  } catch (error) {
    console.error("Fetch custodies error:", error);
    res.status(500).json({ error: "Failed to fetch custodies list" });
  }
});

router.post("/api/treasury/custodies", authenticateToken, async (req, res) => {
  const { employee_id, account_id, amount, purpose } = req.body;
  const userId = (req as any).user?.id || null;
  try {
    const result = await pool.query(`
      INSERT INTO treasury_custodies (employee_id, account_id, amount, status, purpose, created_by)
      VALUES ($1, $2, $3, 'pending', $4, $5) RETURNING *
    `, [employee_id, account_id, parseFloat(amount), purpose || "", userId]);
    res.json(result.rows[0]);
  } catch (error) {
    console.error("Create custody error:", error);
    res.status(500).json({ error: "Failed to record custody request" });
  }
});

router.post("/api/treasury/custodies/:id/pay", authenticateToken, async (req, res) => {
  const userId = (req as any).user?.id || null;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    const custody = (await client.query("SELECT * FROM treasury_custodies WHERE id = $1", [req.params.id])).rows[0];
    if (!custody) throw new Error("Custody record not found");
    if (custody.status !== 'pending') throw new Error("العهدة ليست قيد الانتظار لتسليمها");

    const account = (await client.query("SELECT current_balance, name FROM treasury_accounts WHERE id = $1", [custody.account_id])).rows[0];
    if (!account) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'الحساب غير موجود' }); }
    if (account.current_balance < custody.amount) {
      throw new Error("رصيد الخزينة المحددة غير كافي لتسليم العهدة");
    }

    // Generate Voucher No for Custody Outflow
    const year = new Date().getFullYear();
    const seqRes = await client.query(
      "SELECT COUNT(*)::integer as count FROM treasury_transactions WHERE voucher_type = 'payment' AND EXTRACT(YEAR FROM created_at) = $1",
      [year]
    );
    const voucherNum = `PAY-${year}-${(seqRes.rows[0].count + 1).toString().padStart(4, '0')}`;

    // Create standard payment transaction
    const balanceBefore = Number(account.current_balance);
    const balanceAfter = balanceBefore - Number(custody.amount);

    await client.query(`
      INSERT INTO treasury_transactions 
      (account_id, amount, transaction_type, notes, created_by, status, voucher_number, voucher_type, balance_before, balance_after)
      VALUES ($1, $2, 'cash_out', $3, $4, 'approved', $5, 'payment', $6, $7)
    `, [
      custody.account_id, 
      -Number(custody.amount), 
      `صرف عهدة مالية للموظف المستلم - غرض العهدة: ${custody.purpose}`, 
      userId, 
      voucherNum, 
      balanceBefore, 
      balanceAfter
    ]);

    // Update treasury account balance
    await client.query("UPDATE treasury_accounts SET current_balance = current_balance - $1 WHERE id = $2", [custody.amount, custody.account_id]);

    // Update custody status
    const result = await client.query(
      "UPDATE treasury_custodies SET status = 'paid' WHERE id = $1 RETURNING *",
      [req.params.id]
    );

    await logAudit(client, null, custody.account_id, "pay_custody", custody, result.rows[0], userId);
    await client.query("COMMIT");
    res.json(result.rows[0]);
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Pay custody error:", error);
    res.status(500).json({ error: error.message || "Failed to pay custody" });
  } finally {
    client.release();
  }
});

router.post("/api/treasury/custodies/:id/clear", authenticateToken, async (req, res) => {
  const { cleared_amount, returned_amount, clearance_notes } = req.body;
  const userId = (req as any).user?.id || null;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    
    const custody = (await client.query("SELECT * FROM treasury_custodies WHERE id = $1", [req.params.id])).rows[0];
    if (!custody) throw new Error("Custody record not found");
    if (custody.status !== 'paid') throw new Error("يمكن تصفية العهد المدفوعة والنشطة فقط");

    const parsedCleared = parseFloat(cleared_amount) || 0;
    const parsedReturned = parseFloat(returned_amount) || 0;

    if (parsedCleared + parsedReturned !== Number(custody.amount)) {
      throw new Error(`مجموع المبلغ المصروف والمسترجع (${parsedCleared + parsedReturned} ج.م) يجب أن يساوي قيمة العهدة الأصلية (${custody.amount} ج.م)`);
    }

    // Return unspent cash to Treasury
    if (parsedReturned > 0) {
      const account = (await client.query("SELECT current_balance FROM treasury_accounts WHERE id = $1", [custody.account_id])).rows[0];
      if (!account) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'الحساب غير موجود' }); }
      const balanceBefore = Number(account.current_balance);
      const balanceAfter = balanceBefore + parsedReturned;

      // Sequential receipt voucher
      const year = new Date().getFullYear();
      const seqRes = await client.query(
        "SELECT COUNT(*)::integer as count FROM treasury_transactions WHERE voucher_type = 'receipt' AND EXTRACT(YEAR FROM created_at) = $1",
        [year]
      );
      const voucherNum = `REC-${year}-${(seqRes.rows[0].count + 1).toString().padStart(4, '0')}`;

      await client.query(`
        INSERT INTO treasury_transactions 
        (account_id, amount, transaction_type, notes, created_by, status, voucher_number, voucher_type, balance_before, balance_after)
        VALUES ($1, $2, 'cash_in', $3, $4, 'approved', $5, 'receipt', $6, $7)
      `, [
        custody.account_id, 
        parsedReturned, 
        `استرداد المتبقي من العهدة المالية للموظف - تصفية العهدة رقم ${custody.id}`, 
        userId, 
        voucherNum, 
        balanceBefore, 
        balanceAfter
      ]);

      // Update balance
      await client.query("UPDATE treasury_accounts SET current_balance = current_balance + $1 WHERE id = $2", [parsedReturned, custody.account_id]);
    }

    // Update custody state
    const result = await client.query(
      `UPDATE treasury_custodies 
       SET status = 'cleared', cleared_amount = $1, returned_amount = $2, clearance_notes = $3, cleared_at = NOW() 
       WHERE id = $4 RETURNING *`,
      [parsedCleared, parsedReturned, clearance_notes || "", req.params.id]
    );

    await logAudit(client, null, custody.account_id, "clear_custody", custody, result.rows[0], userId);
    await client.query("COMMIT");
    res.json(result.rows[0]);
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Clear custody error:", error);
    res.status(500).json({ error: error.message || "Failed to clear custody" });
  } finally {
    client.release();
  }
});

// 8. TREASURY CONFIG SETTINGS (الإعدادات)
router.get("/api/treasury/settings", authenticateToken, async (req, res) => {
  try {
    const settings = (await pool.query("SELECT * FROM treasury_settings")).rows;
    res.json(settings);
  } catch (error) {
    console.error("Fetch settings error:", error);
    res.status(500).json({ error: "Failed to fetch settings" });
  }
});

router.post("/api/treasury/settings", authenticateToken, async (req, res) => {
  const { settings } = req.body; // Array of { key, value, description }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    for (const item of settings) {
      await client.query(
        `INSERT INTO treasury_settings (key, value, description) 
         VALUES ($1, $2, $3) 
         ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, description = EXCLUDED.description`,
        [item.key, item.value, item.description || ""]
      );
    }
    await client.query("COMMIT");
    res.json({ success: true });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Save settings error:", error);
    res.status(500).json({ error: "Failed to save settings" });
  } finally {
    client.release();
  }
});

// 9. AUDIT TRAIL LOGS (سجل كامل لجميع الحركات)
router.get("/api/treasury/audit-logs", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT l.*, u.username as user_name, a.name as account_name
      FROM treasury_audit_logs l
      LEFT JOIN users u ON l.user_id = u.id
      LEFT JOIN treasury_accounts a ON l.account_id = a.id
      ORDER BY l.created_at DESC
      LIMIT 100
    `;
    const logs = (await pool.query(query)).rows;
    res.json(logs);
  } catch (error) {
    console.error("Fetch audit logs error:", error);
    res.status(500).json({ error: "Failed to fetch audit logs" });
  }
});

export default router;
