import { Request, Response } from "express";
import { ReturnRepository } from "../repositories/return.repository.js";

export class ReturnController {
  private repository: ReturnRepository;

  constructor() {
    this.repository = new ReturnRepository();
  }

  getReturns = async (req: Request, res: Response): Promise<void> => {
    try {
      const returns = await this.repository.getAll();
      res.status(200).json({ success: true, data: returns });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to fetch returns" });
    }
  };

  createReturn = async (req: Request, res: Response): Promise<void> => {
    try {
      const returnDoc = await this.repository.create(req.body);
      res.status(201).json({ success: true, data: returnDoc });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to save return" });
    }
  };

  updateReturn = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        res.status(400).json({ error: "Invalid return ID" });
        return;
      }
      const returnDoc = await this.repository.update(id, req.body);
      res.status(200).json({ success: true, data: returnDoc });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to update return" });
    }
  };

  deleteReturn = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        res.status(400).json({ error: "Invalid return ID" });
        return;
      }
      await this.repository.delete(id);
      res.status(200).json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to delete return" });
    }
  };
}
