import { Request, Response } from "express";
import { QuotationRepository } from "../repositories/quotation.repository.js";

export class QuotationController {
  private repository: QuotationRepository;

  constructor() {
    this.repository = new QuotationRepository();
  }

  getQuotations = async (req: Request, res: Response): Promise<void> => {
    try {
      const quotations = await this.repository.getAll();
      res.status(200).json({ success: true, data: quotations });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to fetch quotations" });
    }
  };

  createQuotation = async (req: Request, res: Response): Promise<void> => {
    try {
      const quotation = await this.repository.create(req.body);
      res.status(201).json({ success: true, data: quotation });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to save quotation" });
    }
  };

  updateQuotation = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        res.status(400).json({ error: "Invalid quotation ID" });
        return;
      }
      const quotation = await this.repository.update(id, req.body);
      res.status(200).json({ success: true, data: quotation });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to update quotation" });
    }
  };

  deleteQuotation = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        res.status(400).json({ error: "Invalid quotation ID" });
        return;
      }
      await this.repository.delete(id);
      res.status(200).json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to delete quotation" });
    }
  };
}
