import { Request, Response } from "express";
import { SalesOrderRepository } from "../repositories/sales_order.repository.js";

export class SalesOrderController {
  private repository: SalesOrderRepository;

  constructor() {
    this.repository = new SalesOrderRepository();
  }

  getSalesOrders = async (req: Request, res: Response): Promise<void> => {
    try {
      const orders = await this.repository.getAll();
      res.status(200).json({ success: true, data: orders });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to fetch sales orders" });
    }
  };

  createSalesOrder = async (req: Request, res: Response): Promise<void> => {
    try {
      const order = await this.repository.create(req.body);
      res.status(201).json({ success: true, data: order });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to save sales order" });
    }
  };

  updateSalesOrder = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        res.status(400).json({ error: "Invalid sales order ID" });
        return;
      }
      const order = await this.repository.update(id, req.body);
      res.status(200).json({ success: true, data: order });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to update sales order" });
    }
  };

  deleteSalesOrder = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        res.status(400).json({ error: "Invalid sales order ID" });
        return;
      }
      await this.repository.delete(id);
      res.status(200).json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to delete sales order" });
    }
  };
}
