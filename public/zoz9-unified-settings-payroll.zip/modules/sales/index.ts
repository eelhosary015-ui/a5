import { Router } from "express";
import { QuotationController } from "./controllers/quotation.controller.js";
import { SalesOrderController } from "./controllers/sales_order.controller.js";
import { ReturnController } from "./controllers/return.controller.js";

const salesRoutes = Router();
const quotationController = new QuotationController();
const orderController = new SalesOrderController();
const returnController = new ReturnController();

// Quotations
salesRoutes.get("/quotations", quotationController.getQuotations);
salesRoutes.post("/quotations", quotationController.createQuotation);
salesRoutes.put("/quotations/:id", quotationController.updateQuotation);
salesRoutes.delete("/quotations/:id", quotationController.deleteQuotation);

// Sales Orders
salesRoutes.get("/orders", orderController.getSalesOrders);
salesRoutes.post("/orders", orderController.createSalesOrder);
salesRoutes.put("/orders/:id", orderController.updateSalesOrder);
salesRoutes.delete("/orders/:id", orderController.deleteSalesOrder);

// Sales Returns
salesRoutes.get("/returns", returnController.getReturns);
salesRoutes.post("/returns", returnController.createReturn);
salesRoutes.put("/returns/:id", returnController.updateReturn);
salesRoutes.delete("/returns/:id", returnController.deleteReturn);

export function bootstrapSalesModule() {
  console.log("⚡ Bootstrapping Sales (Quotations, Sales Orders & Returns) Module...");
}

export { salesRoutes };
